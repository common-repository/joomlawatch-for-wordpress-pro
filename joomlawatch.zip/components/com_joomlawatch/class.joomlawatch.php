<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version 1.2.18 BETA
 * @revision 507
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) 2011 by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/

/** ensure this file is being included by a parent file */
if (!defined('_JEXEC') && !defined('_VALID_MOS'))
    die('Restricted access');

class JoomlaWatch {

    var $env;
    var $database;

    var $visit;
    var $stat;
    var $config;
    var $helper;
    var $goal;
    var $block;
    var $cache;
	var $sizes;
    var $flow;


    function JoomlaWatch() {
        $this->env = JoomlaWatchEnvFactory::getEnvironment();
        $this->database = & $this->env->getDatabase();
        $this->stat = new JoomlaWatchStat($this->database);
        $this->config = new JoomlaWatchConfig($this->database);
        $this->helper = new JoomlaWatchHelper($this->database);
        $this->goal = new JoomlaWatchGoal($this->database);
        $this->block = new JoomlaWatchBlock($this->database);
        $this->visit = new JoomlaWatchVisit($this->database);
        $this->cache = new JoomlaWatchCache($this->database);
		$this->sizes = new JoomlaWatchSizes($this->database);
        $this->flow = new JoomlaWatchFlow($this->visit, $this->database);

    }





}
?>