<?php

require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "env" . DS . "interface.joomlawatch.env.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "env" . DS . "interface.joomlawatch.dbwrap.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "env" . DS . "interface.joomlawatch.setup.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "env" . DS . "class.joomlawatch.env.request.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "env" . DS . "class.joomlawatch.env.factory.php");

require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "env" . DS . "joomla".DS."class.joomlawatch.env.joomla.php");

require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "env" . DS . "wordpress".DS."class.joomlawatch.env.wordpress.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "env" . DS . "wordpress".DS."class.joomlawatch.db.wordpress.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "env" . DS . "wordpress".DS."class.joomlawatch.setup.wordpress.php");

require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "env" . DS . "nocms".DS."class.joomlawatch.db.nocms.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "env" . DS . "nocms".DS."class.joomlawatch.env.nocms.php");

?>
