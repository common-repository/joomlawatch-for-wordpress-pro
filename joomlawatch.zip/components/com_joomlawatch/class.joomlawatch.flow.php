<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version 1.2.18 BETA
 * @revision 507
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) 2011 by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/

/** ensure this file is being included by a parent file */
if (!defined('_JEXEC') && !defined('_VALID_MOS'))
    die('Restricted access');

class JoomlaWatchFlow {

    var $visit;
    var $database;
    var $config;


    function JoomlaWatchFlow($visit, $database) {
        $this->visit = $visit;
        $this->database = $database;
        $this->config = new JoomlaWatchConfig($this->database);
    }

    function insertFlow($from, $to) {
        $fromId = $this->visit->getUriIdByUriName($from);
        if (!$fromId) {
            $this->visit->addUri2Title($from, "");
            $fromId = $this->visit->getUriIdByUriName($from);
        }
        $toId = $this->visit->getUriIdByUriName($to);
        if (!$toId) {
            $this->visit->addUri2Title($to, "");
            $toId = $this->visit->getUriIdByUriName($to);
        }

        $query = sprintf("select count(id) as `count` from #__joomlawatch_flow where `from` = '%d' and `to` = '%d'", (int) $fromId, (int) $toId);
        $count = $this->database->resultQuery($query);

        if ($count) {
            $query = sprintf("update #__joomlawatch_flow set count = count+1  where `from` = '%d' and `to` = '%d' ", (int) $fromId, (int) $toId);
            $this->database->executeQuery($query);
        } else {
            $query = sprintf("insert into #__joomlawatch_flow values ('', '%d', '%d', 1) ", (int) $fromId, (int) $toId);
            $this->database->executeQuery($query);
        }

    }

    function getOutputPages($fromUriId, $limit) {
        $query = sprintf("select * from #__joomlawatch_flow where `from` != `to` and `from` = '%d' order by `count` desc limit %d", (int) $fromUriId, $limit + 1);
        $rows = $this->database->objectListQuery($query);
        return $rows;
    }

    function getFlowById($flowId) {
        $query = sprintf("select `from`,`to`,`count`  from #__joomlawatch_flow where `id` = %d limit 1", (int) $flowId);
        $rows = $this->database->objectListQuery($query);
        return $rows[0];
    }


    function retrieveFlow($uriId = 0, &$nodeArray, &$edgeArray, $outgoingLinksCount, $nestingLevelCount) {

        $nestingLevel = 0;

        if ($uriId == 0) {
            $uriId = $this->visit->getMaxCountUriId();
        }
        $this->getOutgoingLinks($uriId, $nodeArray, $edgeArray, $nestingLevel, $nestingLevelCount, $outgoingLinksCount, true);

    }

    function getOutgoingLinks($fromId, &$nodeArray, &$edgeArray, $nestingLevel, &$nestingLevelCount, $outgoingLinksCount, $root = false) {

        if ($nestingLevel > $nestingLevelCount) {
            $nestingLevel--;
            return;
        }

        $nestingLevel++;

        $rows = $this->getOutputPages($fromId, $outgoingLinksCount);

        $outgoingLinks = 0;
        foreach ($rows as $row) {
            if ($row->from && $row->to) {
                if ($root) {
                    $outgoingLinksCountModified = $outgoingLinksCount;
                } else {
                    $outgoingLinksCountModified = 1;
                }
                if ($outgoingLinks > $outgoingLinksCountModified) {
                    break;
                }
                $outgoingLinks++;
                $this->addEdgeToArray($edgeArray, $row->id);
                $this->addNodeToArray($nodeArray, $row->from);
                $this->addNodeToArray($nodeArray, $row->to);
                $this->getOutgoingLinks($row->to, $nodeArray, $edgeArray, $nestingLevel, $nestingLevelCount, $outgoingLinksCount, false);
            }
        }

        $nestingLevel--;
    }

    function addNodeToArray(& $nodeArray, $nodeId) {
        if (!in_array($nodeId, $nodeArray)) {
            $nodeArray[] = $nodeId;
        }
    }

    function addEdgeToArray(& $edgeArray, $flowId) {
        if (!in_array($flowId, $edgeArray)) {
            $edgeArray[] = $flowId;
        }
    }


    function getSumOfOutgoingFlow($fromId, $limit) {
        $query = sprintf("select `count` from #__joomlawatch_flow where `from` != `to` and `from` = '%d' order by `count` desc limit %d", (int) $fromId, (int) $limit);
        $rows = $this->database->objectListQuery($query);
        $count = 0;
        foreach($rows as $row) {
            $count += $row->count;
        }
        return @ $count;
    }

    function HSV_TO_RGB ($H, $S, $V) // HSV Values:Number 0-1
    { // RGB Results:Number 0-255
        $RGB = array();

        if($S == 0)
        {
            $R = $G = $B = $V * 255;
        }
        else
        {
            $var_H = $H * 6;
            $var_i = floor( $var_H );
            $var_1 = $V * ( 1 - $S );
            $var_2 = $V * ( 1 - $S * ( $var_H - $var_i ) );
            $var_3 = $V * ( 1 - $S * (1 - ( $var_H - $var_i ) ) );

            if ($var_i == 0) { $var_R = $V ; $var_G = $var_3 ; $var_B = $var_1 ; }
            else if ($var_i == 1) { $var_R = $var_2 ; $var_G = $V ; $var_B = $var_1 ; }
            else if ($var_i == 2) { $var_R = $var_1 ; $var_G = $V ; $var_B = $var_3 ; }
            else if ($var_i == 3) { $var_R = $var_1 ; $var_G = $var_2 ; $var_B = $V ; }
            else if ($var_i == 4) { $var_R = $var_3 ; $var_G = $var_1 ; $var_B = $V ; }
            else { $var_R = $V ; $var_G = $var_1 ; $var_B = $var_2 ; }

            $R = $var_R * 255;
            $G = $var_G * 255;
            $B = $var_B * 255;
        }

        $RGB['R'] = $R;
        $RGB['G'] = $G;
        $RGB['B'] = $B;

        return $RGB;
    }

    function getMostPopularUriIdsAndTitles() {
        $query = sprintf("SELECT DISTINCT (uri2title.id)
                            FROM #__joomlawatch_uri2title AS uri2title
                            JOIN #__joomlawatch_flow AS flow ON uri2title.id = flow.`from`
                            ORDER BY `uri2title`.`count` DESC
                            LIMIT 100");
        return $this->database->objectListQuery($query);
    }

    function getDefaultOutgoingLinks($outgoingLinks) {
        if (!$outgoingLinks) {
            $outgoingLinks = $this->config->getConfigValue("JOOMLAWATCH_FLOW_DEFAULT_OUTGOING_LINKS_COUNT");
            return $outgoingLinks;
        }
        return $outgoingLinks;
    }

    /*
    function getDefaultNestingLevel($nestingLevel) {
        if (isset($nestingLevel) && $nestingLevel != 0) {
            $nestingLevel = $this->config->getConfigValue("JOOMLAWATCH_FLOW_DEFAULT_NESTING_LEVEL");
            return $nestingLevel;
        }
        return $nestingLevel;
    }
     */

}
?>