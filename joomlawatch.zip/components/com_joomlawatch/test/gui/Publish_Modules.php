<?php
class Publish_Modules extends PHPUnit_Extensions_SeleniumTestCase
{
  protected function setUp()
  {
    $this->setBrowser("*chrome");
    $this->setBrowserUrl("http://www.codegravitydemo.com/");
  }

  public function testMyTestCase()
  {
    $this->open("/administrator/index.php");
    try {
        $this->assertTrue($this->isElementPresent("link=Log out"));
    } catch (PHPUnit_Framework_AssertionFailedError $e) {
        array_push($this->verificationErrors, $e->toString());
    }
    $this->click("link=Extensions");
    $this->click("link=Module Manager");
    $this->waitForPageToLoad("30000");
    $this->select("filter_state", "label=Unpublished");
    $this->waitForPageToLoad("30000");
    // Search for JoomlaWatch Agent
    $this->type("filter_search", "JoomlaWatch Agent");
    $this->click("css=button[type=submit]");
    $this->waitForPageToLoad("30000");
    try {
        $this->assertTrue($this->isElementPresent("link=JoomlaWatch Agent"));
    } catch (PHPUnit_Framework_AssertionFailedError $e) {
        array_push($this->verificationErrors, $e->toString());
    }
    // Publishing JoomlaWatch Agent
    $this->click("link=JoomlaWatch Agent");
    $this->waitForPageToLoad("30000");
    $this->type("jform_position", "position-11");
    $this->select("jform_published", "label=Published");
    // Set Start publishing date
    $this->type("jform_publish_up", "2011-01-01 00:01:00");
    $this->select("jform_assignment", "label=On all pages");
    $this->click("css=span.icon-32-apply");
    $this->verifyTextPresent("Module successfully saved");
    $this->click("css=span.icon-32-save");
    $this->click("css=button[type=button]");
    $this->waitForPageToLoad("30000");
    $this->type("filter_search", "JoomlaWatch Users");
    $this->click("css=button[type=submit]");
    $this->waitForPageToLoad("30000");
    try {
        $this->assertTrue($this->isElementPresent("link=JoomlaWatch Users"));
    } catch (PHPUnit_Framework_AssertionFailedError $e) {
        array_push($this->verificationErrors, $e->toString());
    }
    $this->click("link=JoomlaWatch Users");
    $this->waitForPageToLoad("30000");
    // Publishing JoomlaWatch Users
    $this->type("jform_position", "position-11");
    $this->select("jform_published", "label=Published");
    // Set Start publishing date
    $this->type("jform_publish_up", "2011-01-01 00:01:00");
    $this->select("jform_assignment", "label=On all pages");
    $this->click("css=span.icon-32-save");
    $this->verifyTextPresent("Module successfully saved");
    $this->click("css=button[type=button]");
    $this->waitForPageToLoad("30000");
    $this->type("filter_search", "JoomlaWatch Visitors");
    $this->click("css=button[type=submit]");
    $this->waitForPageToLoad("30000");
    try {
        $this->assertTrue($this->isElementPresent("link=JoomlaWatch Visitors"));
    } catch (PHPUnit_Framework_AssertionFailedError $e) {
        array_push($this->verificationErrors, $e->toString());
    }
    $this->click("link=JoomlaWatch Visitors");
    $this->waitForPageToLoad("30000");
    // Publishing JoomlaWatch Visitors
    $this->type("jform_position", "position-11");
    $this->select("jform_published", "label=Published");
    // Set Start publishing date
    $this->type("jform_publish_up", "2011-01-01 00:01:00");
    $this->select("jform_assignment", "label=On all pages");
    $this->click("link=Save & Close");
    $this->verifyTextPresent("Module successfully saved");
    $this->click("css=button[type=button]");
    $this->waitForPageToLoad("30000");
  }
}
?>