<?php
/**
 * Created by JetBrains PhpStorm.
 * User: batman
 * Date: 9/10/11
 * Time: 7:52 AM
 * To change this template use File | Settings | File Templates.
 */
?>

<a href='<?php echo $this->joomlaWatch->config->renderLink();?>' ><img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/map_icon.gif'/>&nbsp;<?php echo _JW_MENU_STATS;?></a> |
<a href='<?php echo $this->joomlaWatch->config->renderLink('flow');?>'><img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/flow.png'/>&nbsp;<?php echo _JW_ADMINHEADER_FLOW;?></a> |
<a href='<?php echo $this->joomlaWatch->config->renderLink('seo');?>'><img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/seo.png'/>&nbsp;SEO</a> |
<a href='<?php echo $this->joomlaWatch->config->renderLink('graphs');?>'><img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/trend_icon.gif'/>&nbsp;<?php echo _JW_ADMINHEADER_GRAPHS;?></a> |
<a href='<?php echo $this->joomlaWatch->config->renderLink('goals');?>'><img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/goal.gif'/>&nbsp;<?php echo _JW_MENU_GOALS;?></a> |
<a href='<?php echo $this->joomlaWatch->config->renderLink('history');?>'><img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/history.png'/>&nbsp;<?php echo _JW_MENU_HISTORY;?></a> |
<a href='<?php echo $this->joomlaWatch->config->renderLink('antiSpam');?>'><img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/antispam.gif'/>&nbsp;<?php echo _JW_SETTINGS_ANTI_SPAM;?></a> |
<a href='<?php echo $this->joomlaWatch->config->renderLink('emails');?>'><img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/emails.png'/>&nbsp;<?php echo _JW_MENU_EMAILS;?></a> |
<a href='<?php echo $this->joomlaWatch->config->renderLink('license');?>'><img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/license.png'/>&nbsp;<?php echo _JW_MENU_LICENSE;?></a> |
<a href='<?php echo $this->joomlaWatch->config->renderLink('status');?>'><img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/status.png'/>&nbsp;<?php echo _JW_MENU_STATUS;?></a> |
<a href='<?php echo $this->joomlaWatch->config->renderLink('sizes');?>'><img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/sizes.png'/>&nbsp;<?php echo _JW_ADMINHEADER_COMPONENTS;?></a> |
<a href='<?php echo $this->joomlaWatch->config->renderLink('settings');?>'><img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/settings.gif'/>&nbsp;<?php echo _JW_MENU_SETTINGS;?></a> |
<a href='<?php echo $this->joomlaWatch->config->renderLink('credits');?>'><img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/credits.png'/>&nbsp;<?php echo _JW_MENU_CREDITS;?></a> |
<?php
if ($this->joomlaWatch->config->getEnvironment() == "JoomlaWatchJoomlaEnv") {
    ?>
<a href='<?php echo $this->joomlaWatch->config->renderLink('update');?>'><img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/update.png'/>&nbsp;<?php echo _JW_MENU_UPDATE;?></a>
<?php
}
?>
