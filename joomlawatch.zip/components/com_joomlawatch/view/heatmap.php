<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version 1.2.18 BETA
 * @revision 507
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) 2011 by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/
defined( '_JEXEC' ) or die( 'Restricted access' );
?>
<script type="text/javascript" src="<?php echo $this->joomlaWatch->config->getLiveSiteWithSuffix(); ?>components/com_joomlawatch/js/heatmap/heatmap.js"></script>
<script type="text/javascript" src="<?php echo $this->joomlaWatch->config->getLiveSiteWithSuffix(); ?>components/com_joomlawatch/js/jdownloadurl.js"></script>
<script type="text/javascript">
    window.onload = function(){

        var urlBase = "components/com_joomlawatch/heatmap.php";
        w = document.clientWidth || window.innerWidth;
        h = document.clientHeight || window.innerHeight;

        window.document.onclick = function(ev) {
            var screenHeight = window.screen.height;
            var screenWidth = window.screen.width;

            var pos = h337.util.mousePosition(ev);
            x = pos[0];
            y = pos[1];
            scrollx = window.pageXOffset;
            scrolly = window.pageYOffset;
            winw = Math.max(document.scrollWidth, document.offsetWidth, w);
            winh = Math.max(document.scrollHeight, document.offsetHeight, h);

            /* Is the click in the viewing area? Not on scrollbars. The problem still exists for FF on the horizontal scrollbar */
            var url = urlBase + "?action=click&uri2titleId=<?php echo($id);?>&x="+x + "&y=" + y + "&w=" + w ;
            downloadUrl(url, function (e) {}, true);
        }

<?php
    $userObject = $this->joomlaWatch->visit->getUser();
    if ($userObject->getUsername() == "matto") {
        ?>
        var xx = h337.create({"element":document.body, "radius":25, "visible":true});

        document.onkeypress = returnKey;

        function returnKey(evt)
        {
            var evt  = (evt) ? evt : ((event) ? event : null);
            var key = (evt) ? evt.which : event.keyCode;

            if (evt.altKey && evt.ctrlKey && String.fromCharCode(key)=="t"){
                xx.toggleDisplay();
            }

        }


        var urlGetData = urlBase + "?action=getHeatMap" + "&uri2titleId=<?php echo($id);?>" + "&w=" + w + "&h=" + h;
        //alert(urlGetData);
        downloadUrl(urlGetData, function (data) {
            var obj = eval('('+data+')');
            xx.store.setDataSet(obj);

        }, true);
        <?php } ?>
    }
</script>

