<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version 1.2.18 BETA
 * @revision 507
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) 2011 by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/
defined( '_JEXEC' ) or die( 'Restricted access' );
?>
<script type="text/javascript" src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/js/jquery.js'></script>
<script type="text/javascript" src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/js/jquery-easing.1.2.js'></script>
<script type="text/javascript" src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/js/jquery-easing-compatibility.1.2.js'></script>

<table>
    <tr>
        <td>
            <h2><?php echo _JW_SIZES_FILES;?></h2>
        <?php
        $lastCheckDate = $this->joomlaWatch->sizes->findLatestCheckDayByComOrModGroup();
        if ($lastCheckDate) {
            echo _JW_SIZES_LAST_CHECK."&nbsp;";
            echo $this->joomlaWatch->helper->getDateByDay($lastCheckDate);
        }
        ?>

            <br/><br/>
            <span style='color: #5AA1D3'><?php echo _JW_SIZES_ADMINISTRATOR; ?></span>
            <br/><br/>
        </td>
    </tr>
    <tr><td valign="top" width="50%">
    <?php include("sizecomponents.php"); ?>

    </td>
        <td valign="top" width="50%">
        <?php include("sizemodules.php"); ?>
        </td>
    </tr>
</table>
