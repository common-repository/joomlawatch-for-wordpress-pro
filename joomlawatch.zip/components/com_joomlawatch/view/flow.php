<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version 1.2.18 BETA
 * @revision 507
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) 2011 by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/
defined( '_JEXEC' ) or die( 'Restricted access' );

$joomlaWatchFlowHTML = new JoomlaWatchFlowHTML($this->joomlaWatch->flow);
?>

<script src="<?php echo $this->joomlaWatch->config->getLiveSiteWithSuffix();?>components/com_joomlawatch/js/jquery-1.4.2.min.js"></script>
<script src="<?php echo $this->joomlaWatch->config->getLiveSiteWithSuffix();?>components/com_joomlawatch/js/springy/springy.js"></script>
<script src="<?php echo $this->joomlaWatch->config->getLiveSiteWithSuffix();?>components/com_joomlawatch/js/springy/springyui.js"></script>
<link rel="stylesheet" href="<?php echo $this->joomlaWatch->config->getLiveSiteWithSuffix();?>components/com_joomlawatch/css/joomlawatch.css">

<script>
    var graph = new Graph();
    <?php

        $outgoingLinksCount = $this->joomlaWatch->flow->getDefaultOutgoingLinks(@JoomlaWatchHelper::requestPost('outgoingLinksCount'));
        $nestingLevel = @JoomlaWatchHelper::requestPost('nestingLevel');
                    
        echo $joomlaWatchFlowHTML->renderGraph(@JoomlaWatchHelper::requestPost('uriId'), $outgoingLinksCount, $nestingLevel);
    ?>

    jQuery(document).ready(function(){
        jQuery('#trafficflow').springy(graph);
    });

</script>

<h2><?php echo _JW_FLOW_TRAFFIC;?></h2>
<form action="" method="POST">
    <table width="1024">
        <tr>
            <td>
                <?php echo _JW_FLOW_SELECT_PAGE;?>
            </td>
            <td>
                <?php echo _JW_FLOW_OUTG_LINKS;?>
            </td>
            <td>
                <?php echo _JW_FLOW_NESTING;?>
            </td>
            <td align="center">
                <?php echo _JW_FLOW_SCALE;?>
            </td>
        </tr>
        <tr>
            <td valign="top">
            <?php echo $joomlaWatchFlowHTML->renderPagesCombobox(@JoomlaWatchHelper::requestPost('uriId')); ?>
            </td>
            <td valign="top">
            <?php echo $joomlaWatchFlowHTML->renderOutgoingLinksCountCombobox($outgoingLinksCount); ?>
            </td>
            <td valign="top">
            <?php echo $joomlaWatchFlowHTML->renderNestingLevelCombobox($nestingLevel); ?>
            </td>
            <td align="center" valign="top">
                <img src="<?php echo $this->joomlaWatch->config->getLiveSiteWithSuffix();?>components/com_joomlawatch/icons/hsv.png" alt="" /><br/>
            </td>
        </tr>
        <tr><td colspan="5">
            <canvas id="trafficflow" width="1024" height="400" />

        </td></tr>
        <tr>
            <td colspan="5">
            <?php echo $joomlaWatchFlowHTML->renderFlowTable(@JoomlaWatchHelper::requestPost('uriId'), $outgoingLinksCount, $nestingLevel); ?>
            </td>
        </tr>
    </table>
</form>

