<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version 1.2.18 BETA
 * @revision 507
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) 2011 by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/
defined( '_JEXEC' ) or die( 'Restricted access' );
?>

<table id='license'>
    <tr>

        <td valign='top'>
    <img src='<?php echo $this->joomlaWatch->config->getLiveSiteWithSuffix();?>components/com_joomlawatch/icons/joomlawatch-logo.png' />
        </td>
        <td align='left' valign='top'>
        <h3>PRO version</h3>

        <h4>Thank you very much for your donation!</h4>

        Registration key for your domain <b/><?php echo $this->joomlaWatch->config->getDomainFromLiveSite(); ?></b> is: <br/><br/>
        <input name='key' value='<?php echo($this->joomlaWatch->config->getConfigValue('JOOMLAWATCH_ADFREE'));?>' size="50" readonly="true" style='text-align: center'/>
            <br/><br/>
    </td></tr></table>

<script type="text/javascript">
    showEffect("license", "scale", 1500);
</script>
