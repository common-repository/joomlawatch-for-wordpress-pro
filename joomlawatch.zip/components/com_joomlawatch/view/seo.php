<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version 1.2.18 BETA
 * @revision 507
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) 2011 by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/
defined( '_JEXEC' ) or die( 'Restricted access' );
?>


<?php
$day = JoomlaWatchHelper::requestGet('day');
if (!$day) {
    $day = $this->joomlaWatch->helper->jwDateToday() -1 ; // yesterday by default, because it contains
}
$rows = $this->joomlaWatch->visit->retrieveTopUrisReferedByKeyphrase($day);
?>

<h2>Top referred pages by keyphrases for <?php echo $this->joomlaWatch->helper->getDateByDay($day); ?></h2>

<table width='700px' border="0">
    <tr><td colspan="5">
        <?php echo $this->renderDateControlGet($day); ?>
    </td></tr>
    <tr>
        <th align="left">keyphrase</th><th>value</th><th>perc.</th><th>1-day</th><th>7-days</th><th>28-days</th>
    </tr>
<?php
foreach ($rows as $row) {
    $totalIntValuesForDay = $this->joomlaWatch->stat->getCountByKeyAndDate(DB_KEY_UNIQUE, $day);
    $percentOfHitsPerDay = sprintf("%.2f%%", ($row->total / $totalIntValuesForDay)*100);
    ?>
    <tr><td colspan="2"><h4><a href='<?php echo($row->uri);?>' target="_blank"><?php echo($row->title);?></a></h4></td><td align="left"><b>Hits: <?php echo($row->total);?></b></td><td align="left" colspan="3"><?php echo($percentOfHitsPerDay);?> of traffic</td></tr>

    <?php
                            $keyphrases = $this->joomlaWatch->visit->retrieveKeyphrasesForUri($day, $row->uriId);
    $group = DB_KEY_URI2KEYPHRASE;
    foreach ($keyphrases as $keyphrase) {
        if (is_numeric($keyphrase->value)) {
            $percent = sprintf("(%.2f%%)", ($keyphrase->value/$row->total)*100);
        } else {
            $percent = $keyphrase->value;
        }
        $oneDayDiff = $this->joomlaWatch->stat->getRelDiffOfTwoDays($day-1, $day, DB_KEY_URI2KEYPHRASE, $keyphrase->uri2keyphraseId);
        $sevenDayDiff = $this->joomlaWatch->stat->getRelDiffOfTwoDays($day-7, $day, DB_KEY_URI2KEYPHRASE, $keyphrase->uri2keyphraseId);
        $twentyEightDayDiff = $this->joomlaWatch->stat->getRelDiffOfTwoDays($day-28, $day, DB_KEY_URI2KEYPHRASE, $keyphrase->uri2keyphraseId);
        $oneDayDiffRendered = $joomlaWatchStatHTML->renderPercentage($oneDayDiff);
        $sevenDayDiffRendered = $joomlaWatchStatHTML->renderPercentage($sevenDayDiff);
        $twentyEightDayDiffRendered = $joomlaWatchStatHTML->renderPercentage($twentyEightDayDiff);
        $origName=$keyphrase->uri2keyphraseId;

        $trendsIcon = "<img src='".$this->joomlaWatch->config->getLiveSiteWithSuffix()."components/com_joomlawatch/icons/trend_icon.gif' border='0'  " . $this->joomlaWatch->helper->getTooltipOnEvent() . "=\"ajax_showTooltip('" . $this->joomlaWatch->config->getLiveSiteWithSuffix() . "components/com_joomlawatch/trendtooltip.php?rand=" . $this->joomlaWatch->config->getRand() . "&group=$group&name=$origName&date=$day',this);return false\"/>";

        echo("<tr><td title='".$keyphrase->name."'><a href='http://www.google.com/search?q=".urlencode($keyphrase->name)."'>".JoomlaWatchHelper::truncate($keyphrase->name, 100)."</a></td>
                <td style='width: 30px;' align='right'>".$keyphrase->value."</td><td style='width: 20px' align='right'>$percent</td><td  align='center'>$oneDayDiffRendered</td><td align='center'>$sevenDayDiffRendered</td><td align='center'>$twentyEightDayDiffRendered</td>
                <td>".$trendsIcon."</td>
                </tr>");
    }
    ?>
    <?php
                    };
    ?>
    <tr><td>
        &nbsp;
    </td></tr>
    <tr><td colspan="5">
        <?php echo $this->renderDateControlGet(); ?>
    </td></tr>
</table>
