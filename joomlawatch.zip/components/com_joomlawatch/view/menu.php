<?php
/**
 * Created by JetBrains PhpStorm.
 * User: batman
 * Date: 9/10/11
 * Time: 8:02 AM
 * To change this template use File | Settings | File Templates.
 */
?>
<a href='http://www.codegravity.com/faq/joomlawatch' target='_blank'><?php echo _JW_MENU_FAQ;?> <img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/external.gif' border='0'/></a> |
<a href='http://www.codegravity.com/support/' target='_blank' title='<?php echo _JW_MENU_BUG;?>'><?php echo _JW_MENU_BUG;?></a> <img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/external.gif' border='0'/></a> |
<a href='http://www.codegravity.com/feature/' target='_blank' title='<?php echo _JW_MENU_FEATURE;?>'><?php echo _JW_MENU_FEATURE;?></a> <img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/external.gif' border='0'/></a> |
<a href='http://www.codegravity.com/demo/joomlawatch/1.2.17' target='_blank' title='Demo'>Demo</a> <img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/external.gif' border='0'/></a> |
<a href='http://extensions.joomla.org/extensions/site-management/visitors/3940/review' target='_blank'><?php echo _JW_ADMINHEADER_WRITE;?> <?php echo _JW_ADMINHEADER_REVIEW;?> <img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/external.gif' border='0'/> </a>  |
<a href='http://extensions.joomla.org/extensions/site-management/visitors/3940' target='_blank'><?php echo _JW_HEADER_CAST_YOUR;?> <?php echo _JW_HEADER_VOTE;?> <img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/external.gif' border='0'/> </a>

