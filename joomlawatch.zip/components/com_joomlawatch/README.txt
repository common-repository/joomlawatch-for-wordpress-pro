JoomlaWatch - A real-time joomla monitor and live stats
=======================================================
by Matej Koval http://www.codegravity.com 

Released under the GNU General Public License v3 

		JoomlaWatch is an AJAX component and module for Joomla CMS that allows you to watch
		your website visitors and bots in real-time from the administration menu. Specially 
		their IP addresses, countries they come from, geographical location on a map, which 
		pages they are viewing, their browser and operating system, it creates daily and 
		all-time stats from these information plus unique, pageload and total hits statistics. 
		Furthermore, you can block harmful IP addresses, see blocked attempts stats, evaluate 
		the trend charts, and create goals based on many parameters. In the frontend, it can 
		show the top countries information and visit counts for certain periods of time.

for more information about updates please visit: http://www.codegravity.com/projects/joomlawatch


Enjoy,

Matej Koval
www.codegravity.com