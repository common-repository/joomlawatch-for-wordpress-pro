﻿<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version @VERSION@
 * @revision @REVISION@
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) @YEAR@ by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/
defined( '_JEXEC' ) or die( 'Restricted access' );

#JoomlaWatch language file - to create a new language file, just copy the english.php to eg. german.php and place into /components/com_joomlawatch/lang/

# Main Menu
DEFINE('_JW_MENU_STATS', "Statistici în timp real");
DEFINE('_JW_MENU_GOALS', "Obiective");
DEFINE('_JW_MENU_SETTINGS', "Setări");
DEFINE('_JW_MENU_CREDITS', "Atribuire");
DEFINE('_JW_MENU_FAQ', "Întrebări frecvente");
DEFINE('_JW_MENU_DOCUMENTATION', "Documentaţie");
DEFINE('_JW_MENU_LICENSE', "Licenţă");
DEFINE('_JW_MENU_DONATORS', "Suporteri");
DEFINE('_JW_MENU_SUPPORT', "Deveniţi suporter JoomlaWatch şi scăpaţi de reclamele din interfaţa de administrare.");


# Left visitors real-time window
DEFINE('_JW_VISITS_VISITORS', "Ultimii vizitatori");
DEFINE('_JW_VISITS_BOTS', "Roboţi");
DEFINE('_JW_VISITS_CAME_FROM', "Venit de la");
DEFINE('_JW_VISITS_MODULE_NOT_PUBLISHED', "Modulul dvs. JoomlaWatch nu este publicat! Noile statistici nu se înregistrează. Pentru a-l publica, mergeţi la secţiunea Module şi activaţi-l pentru toate paginile");
DEFINE('_JW_VISITS_PANE_LOADING', "Încărcare vizite...");

# Right stats window
DEFINE('_JW_STATS_TITLE', "Statisticile vizitelor pe săptămână");
DEFINE('_JW_STATS_WEEK', "Săptămână");
DEFINE('_JW_STATS_THIS_WEEK', "săptămâna aceasta");
DEFINE('_JW_STATS_UNIQUE', "unice");
DEFINE('_JW_STATS_LOADS', "încărcări");
DEFINE('_JW_STATS_HITS', "afişări");
DEFINE('_JW_STATS_TODAY', "astăzi");
DEFINE('_JW_STATS_FOR', "pentru");
DEFINE('_JW_STATS_ALL_TIME', "Toate intervalele de timp");
DEFINE('_JW_STATS_EXPAND', "mai mult");
DEFINE('_JW_STATS_COLLAPSE', "mai puţin");
DEFINE('_JW_STATS_URI', "Pagini");
DEFINE('_JW_STATS_COUNTRY', "Ţări");
DEFINE('_JW_STATS_USERS', "Utilizatori");
DEFINE('_JW_STATS_REFERERS', "Refereri");
DEFINE('_JW_STATS_IP', "IP-uri");
DEFINE('_JW_STATS_BROWSER', "Browsere");
DEFINE('_JW_STATS_OS', "Sisteme de operare");
DEFINE('_JW_STATS_KEYWORDS', "Cuvinte-cheie");
DEFINE('_JW_STATS_GOALS', "Obiective");
DEFINE('_JW_STATS_TOTAL', "Total");
DEFINE('_JW_STATS_DAILY', "Zilnic");
DEFINE('_JW_STATS_DAILY_TITLE', "Statistici zilnice");
DEFINE('_JW_STATS_ALL_TIME_TITLE', "Statistici din toate intervalele de timp");
DEFINE('_JW_STATS_LOADING', "încărcare...");
DEFINE('_JW_STATS_LOADING_WAIT', "se încarcă... vă rugăm aşteptaţi");
DEFINE('_JW_STATS_IP_BLOCKING_TITLE', "Blocare IP");
DEFINE('_JW_STATS_IP_BLOCKING_ENTER', "Introduceţi manual IP-ul");
DEFINE('_JW_STATS_IP_BLOCKING_MANUALLY', "Introduceţi adresa IP pe care doriţi să o blocaţi (de exemplu 217.242.11.54 sau 217.* sau 217.242.* pentru a bloca toate IP-urile din categoria respectivă).");
DEFINE('_JW_STATS_IP_BLOCKING_TOGGLE', "Blocarea schimbării IP-ului pentru ");
DEFINE('_JW_STATS_PANE_LOADING', "Încărcare statistici...");

# Settings
DEFINE('_JW_SETTINGS_TITLE', "Setări");
DEFINE('_JW_SETTINGS_DEFAULT', "Standard");
DEFINE('_JW_SETTINGS_SAVE', "Salvare");
DEFINE('_JW_SETTINGS_APPEARANCE', "Aspect");
DEFINE('_JW_SETTINGS_FRONTEND', "Interfaţa de vizualizare");
DEFINE('_JW_SETTINGS_HISTORY_PERFORMANCE', "Istoric &amp; Performanţă");
DEFINE('_JW_SETTINGS_ADVANCED', "Avansat");
DEFINE('_JW_SETTINGS_IGNORE', "Ignorare");
DEFINE('_JW_SETTINGS_BLOCKING', "Blocare");
DEFINE('_JW_SETTINGS_EXPERT', "Expert");
DEFINE('_JW_SETTINGS_RESET_CONFIRM', "Sunteţi sigur că doriţi resetarea tuturor informaţiilor despre statistici şi vizitatori?");
DEFINE('_JW_SETTINGS_RESET_ALL', "Resetare generală");
DEFINE('_JW_SETTINGS_RESET_ALL_LINK', "Resetarea tuturor informaţiilor despre statistici şi vizitatori");
DEFINE('_JW_SETTINGS_LANGUAGE', "Limbă");
DEFINE('_JW_SETTINGS_SAVED', "Setările au fost salvate");
DEFINE('_JW_SETTINGS_ADD_YOUR_IP', "Adăugaţi IP-ul dvs.");
DEFINE('_JW_SETTINGS_TO_THE_LIST', "în listă.");

# Other / mostly general
DEFINE('_JW_TITLE', "Monitorizare AJAX în timp real pentru joomla");
DEFINE('_JW_BACK', "Înapoi");
DEFINE('_JW_ACCESS_DENIED', "Nu aveţi permisiunea să vizualizaţi aceste informaţii!");
DEFINE('_JW_LICENSE_AGREE', "Sunt de acord cu termenii şi condiţiile de mai sus");
DEFINE('_JW_LICENSE_CONTINUE', "Continuare");
DEFINE('_JW_SUCCESS', "Acţiune realizată cu succes");
DEFINE('_JW_RESET_SUCCESS', "Toate informaţiile despre statistici şi vizitatori au fost şterse cu succes");
DEFINE('_JW_RESET_ERROR', "Informaţiile NU au fost şterse, undeva a apărut o eroare");
DEFINE('_JW_CREDITS_TITLE', "Atribuire");
DEFINE('_JW_TRENDS_DAILY_WEEKLY', "Statisticile zilnice şi săptămânale ale");
DEFINE('_JW_AJAX_PERMISSION_DENIED_1', "Permisiune AJAX refuzată: Vă rugăm să vizualizaţi aceste statistici pentru domeniul specificat în configuration.php din joomla - ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_2', "Poate aţi uitat să scrieţi www. în faţa numelui de domeniu. Javascript încearcă să acceseze ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_3', "de la");
DEFINE('_JW_AJAX_PERMISSION_DENIED_4', "care este tratat ca un domeniu diferit.");

# Header
DEFINE('_JW_HEADER_DOWNLOAD', "Descărcaţi cea mai recentă versiune a extensiei de la");
DEFINE('_JW_HEADER_CAST_YOUR', "Vă rugăm să vă înregistraţi");
DEFINE('_JW_HEADER_VOTE', "votul");

# Tooltips
DEFINE('_JW_TOOLTIP_CLICK', "Click pentru a afişa informaţii ajutătoare");
DEFINE('_JW_TOOLTIP_MOUSE_OVER', "Plasaţi mouse-ul deasupra pentru a afişa informaţii ajutătoare");
DEFINE('_JW_TOOLTIP_YESTERDAY_INCREASE', "creşterea de ieri");
DEFINE('_JW_TOOLTIP_HELP', "Deschide ajutor online pentru");
DEFINE('_JW_TOOLTIP_WINDOW_CLOSE', "Închideţi această fereastră");
DEFINE('_JW_TOOLTIP_PRINT', "Printează");

# Goals
DEFINE('_JW_GOALS_INSERT', "Introduceţi un nou obiectiv");
DEFINE('_JW_GOALS_UPDATE', "Actualizaţi numărul unui obiectiv");
DEFINE('_JW_GOALS_ACTION', "Acţiune");
DEFINE('_JW_GOALS_TITLE', "Obiectiv nou");
DEFINE('_JW_GOALS_NEW', "Obiectiv nou");
DEFINE('_JW_GOALS_RELOAD', "Reîncărcare");
DEFINE('_JW_GOALS_ADVANCED', "Avansat");
DEFINE('_JW_GOALS_NAME', "Nume");
DEFINE('_JW_GOALS_ID', "id");
DEFINE('_JW_GOALS_URI_CONDITION', "condiţie URI");
DEFINE('_JW_GOALS_URI_INVERSED', "condiţie inversată URI");
DEFINE('_JW_GOALS_GET_VAR', "Variabila GET");
DEFINE('_JW_GOALS_GET_CONDITION', "Condiţie GET");
DEFINE('_JW_GOALS_POST_VAR', "Variabila POST");
DEFINE('_JW_GOALS_POST_CONDITION', "Condiţie POST");
DEFINE('_JW_GOALS_TITLE_CONDITION', "Condiţie titlu");
DEFINE('_JW_GOALS_USERNAME_CONDITION', "Condiţie nume de utilizator");
DEFINE('_JW_GOALS_IP_CONDITION', "Condiţie IP");
DEFINE('_JW_GOALS_IP_INVERSED', "Condiţie inversată IP");
DEFINE('_JW_GOALS_CAME_FROM_CONDITION', "Venit de la condiţia");
DEFINE('_JW_GOALS_BLOCK', "Blocare");
DEFINE('_JW_GOALS_REDIRECT', "Redirecţionare către URL");
DEFINE('_JW_GOALS_HITS', "Afişări");
DEFINE('_JW_GOALS_ENABLED', "Activat");
DEFINE('_JW_GOALS_EDIT', "Editare");
DEFINE('_JW_GOALS_DELETE', "Ştergere");
DEFINE('_JW_GOALS_DELETE_CONFIRM', "Veţi pierde toate statisticile recente pentru acest obiectiv. Sunteţi sigur că doriţi ştergerea?");

# Frontend
DEFINE('_JW_FRONTEND_COUNTRIES', "Ţări");
DEFINE('_JW_FRONTEND_VISITORS', "Vizitatori");
DEFINE('_JW_FRONTEND_TODAY', "Astăzi");
DEFINE('_JW_FRONTEND_YESTERDAY', "Ieri");
DEFINE('_JW_FRONTEND_THIS_WEEK', "Săptămâna aceasta");
DEFINE('_JW_FRONTEND_LAST_WEEK', "Săptămâna trecută");
DEFINE('_JW_FRONTEND_THIS_MONTH', "Luna aceasta");
DEFINE('_JW_FRONTEND_LAST_MONTH', "Luna trecută");
DEFINE('_JW_FRONTEND_TOTAL', "Total");

# Settings description - quite long
DEFINE('_JW_DESC_DEBUG', "JoomlaWatch este în modul de depanare. În acest fel puteţi descoperi cauzele erorilor. Pentru a-l opri, vă rugăm să schimbaţi valoarea JOOMLAWATCH_DEBUG din /components/com_joomlawatch/config.php de la 1 la 0");
DEFINE('_JW_DESC_STATS_MAX_ROWS', "Numărul maxim de rânduri afişate atunci când statisticile sunt în modul extins.");
DEFINE('_JW_DESC_STATS_IP_HITS', "Toate adresele IP care înregistrează în zilele anterioare mai puţine afişări decât această valoare vor fi şterse din istoricul IP.");
DEFINE('_JW_DESC_STATS_URL_HITS', "Toate URL-urile care înregistrează în zilele anterioare mai puţine afişări decât această valoare vor fi şterse din istoricul IP.");
DEFINE('_JW_DESC_IGNORE_IP', "Excluderea anumitor IP-uri din statistici. Separaţi-le printr-o nouă linie. Puteţi introduce aici şi categorii de IP-uri. <br/>De exemplu 192.* va ignora 192.168.51.31, 192.168.16.2, etc..");
DEFINE('_JW_DESC_UPDATE_TIME_VISITS', "Timpul de reactualizare a vizitatorilor în milisecunde - valoarea standard este de 2000, aveţi grijă. Apoi reîncărcaţi interfaţa de administrare JoomlaWatch.");
DEFINE('_JW_DESC_UPDATE_TIME_STATS', "Timpul de reactualizare a statisticilor în milisecunde - valoarea standard este de 4000, aveţi grijă. Apoi reîncărcaţi interfaţa de administrare JoomlaWatch.");
DEFINE('_JW_DESC_MAXID_BOTS', "Numărul de vizite ale roboţilor păstrate în baza de date.");
DEFINE('_JW_DESC_MAXID_VISITORS', "Numărul de vizite reale păstrate în baza de date.");
DEFINE('_JW_DESC_LIMIT_BOTS', "Numărul de roboţi afişaţi în interfaţa de administrare.");
DEFINE('_JW_DESC_LIMIT_VISITORS', "Numărul de vizitatori reali afişaţi în interfaţa de administrare.");
DEFINE('_JW_DESC_TRUNCATE_VISITS', "Numărul maxim de caractere afişate în titlurile lungi şi în URI-uri.");
DEFINE('_JW_DESC_TRUNCATE_STATS', "Numărul maxim de caractere afişate în secţiunea de statistici din partea dreaptă.");
DEFINE('_JW_DESC_STATS_KEEP_DAYS', "Numărul de zile pentru păstrarea statisticilor în baza de date, 0 = infinit.");
DEFINE('_JW_DESC_TIMEZONE_OFFSET', "Când vă aflaţi într-un fus orar diferit decât cel al serverului de găzduire. (valoare pozitivă sau negativă în ore)");
DEFINE('_JW_DESC_WEEK_OFFSET', "Corectare săptămână - marcajul temporal/(3600*24*7) oferă numărul săptămânii de la 1.1.1970, aceasta este o corecţie pentru ca săptămâna să înceapă cu ziua de luni ");
DEFINE('_JW_DESC_DAY_OFFSET', "Corectare zi - marcajul temporal/(3600*24) oferă numărul zilei de la 1.1.1970, aceasta este o corecţie pentru ca ziua să înceapă la ora 00:00 ");
DEFINE('_JW_DESC_FRONTEND_HIDE_LOGO', "<b>(funcţional în versiunea PRO)</b> Pentru a utiliza o iconiţă goală de 1x1px în interfaţa de vizualizare");
DEFINE('_JW_DESC_IP_STATS', "Pentru a activa statisticile adresei IP. În unele ţări este interzisă prin lege păstrarea IP-ului în baza de date pentru mai mult timp. Utilizaţi pe propriul dvs. risc.");
DEFINE('_JW_DESC_HIDE_ADS', "Această setare ascunde reclamele din interfaţa de administrare, dacă vă într-adevăr vă deranjează. Prin menţinerea lor, sprijiniţi dezvoltarea ulterioară a acestui modul. Vă mulţumim.");
DEFINE('_JW_DESC_TOOLTIP_ONCLICK', "Debifaţi, dacă doriţi să afişaţi informaţiile ajutătoare la poziţionarea mouse-ului deasupra, nu la click.");
DEFINE('_JW_DESC_SERVER_URI_KEY', "Valoarea implicită este 'REDIRECT_URL', care este standard dacă utilizaţi rescrierea url-urilor, poate fi schimbată în 'SCRIPT_URL' dacă se înregistrează doar index.php");
DEFINE('_JW_DESC_BLOCKING_MESSAGE', "Mesajul care este afişat utilizatorului blocat sau informaţii suplimentare despre motivul blocării respectivului utilizator.");
DEFINE('_JW_DESC_TOOLTIP_WIDTH', "Lăţimea secţiunii de informaţii ajutătoare");
DEFINE('_JW_DESC_TOOLTIP_HEIGHT', "Înălţimea secţiunii de informaţii ajutătoare");
DEFINE('_JW_DESC_TOOLTIP_URL', "Puteţi introduce orice URL aici, pentru a vizualiza IP-ul vizitatorului. Câmpul {ip} va fi înlocuit cu IP-ul vizitatorului. De exemplu http://somewebsite.com/query?iplookup={ip}");
DEFINE('_JW_DESC_IGNORE_URI', "Puteţi introduce orice URI care doriţi să fie ignorat din statistici. Puteţi utiliza wildcard-uri (* and ?). De exemplu: /freel?n* ");
DEFINE('_JW_DESC_GOALS_NAME', "Specificaţi un nume de obiectiv. Acest nume îl veţi vedea în statistici.");
DEFINE('_JW_DESC_GOALS_URI_CONDITION', "Orice se află după numele domeniului dvs. Pentru http://www.codegravity.com/projects/ URI-ul este: /projects/ (Exemplu de utilizat: <b>/projects*</b>)");
DEFINE('_JW_DESC_GOALS_GET_VAR', "Variabila GET este o variabilă pe care o puteţi vedea în URL de obicei după un semn ? sau &amp;. De exemplu http://www.codegravity.com/index.php?<u>name</u>=peter&amp;<u>surname</u>=smith. De asemenea puteţi utiliza <u>*</u> în acest câmp pentru a scana toate valorile get. (Exemplu de utilizat: <b>n*me</b>)");
DEFINE('_JW_DESC_GOALS_GET_CONDITION', "Aici trebuie să specificaţi o corespondenţă pentru o valoare din câmpul anterior. (Exemplu de utilizat: <b>p?t*r</b>) ");
DEFINE('_JW_DESC_GOALS_POST_VAR', "Oarecum asemănător, dar verificăm valorile trimise prin formulare. Deci când aveţi un formular pe site-ul dvs., acesta are un câmp &lt;input type='text' name='<u>experiences</u>' /&gt;. (Exemplu de utilizat: <b>exper*ces</b>)");
DEFINE('_JW_DESC_GOALS_POST_CONDITION', "O corespondenţă pentru valoarea din acest câmp POST. De exemplu dorim să verificăm dacă utilizatorul are sau nu experienţe de lucru în java. (Exemplu de utilizat: <b>*java*</b>)");
DEFINE('_JW_DESC_GOALS_TITLE_CONDITION', "Titlul unei pagini care trebuie să corespundă. (Exemplu de utilizat: <b>*freelance programmers*</b>)");
DEFINE('_JW_DESC_GOALS_USERNAME_CONDITION', "Numele unui utilizator logat. (Exemplu de utilizat: <b>psmith*</b>)");
DEFINE('_JW_DESC_GOALS_IP_CONDITION', "IP-ul de la care provine un utilizator: (Exemplu de utilizat: <b>201.9?.*.*</b>)");
DEFINE('_JW_DESC_GOALS_CAME_FROM_CONDITION', "URL-ul de la care utilizatorul a venit. (Exemplu de utilizat: <b>*www.google.*</b>)");
DEFINE('_JW_DESC_GOALS_REDIRECT', "Utilizatorul este redirecţionat către un URL specificat de dvs. Are o prioritate mai mare decât 'blocking': (Exemplu de utilizat: <b>http://www.codegravity.com/goaway.html</b>)");
DEFINE('_JW_DESC_TRUNCATE_GOALS', "Numărul de caractere trunchiate în tabelul cu obiective");
DEFINE('_JW_DESC_FRONTEND_NO_BACKLINK', "<b>(funcţional în versiunea PRO)</b> Backlink către codegravity.com, puteţi să îl dezactivaţi, dar vom aprecia dacă îl veţi păstra aici. Vă mulţumim.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES', "Afişarea statisticilor totale de ţări în modulul interfeţei de vizualizare. Dacă este schimbată, această setare va funcţiona în interfaţa de vizualizare după timpul setat în CACHE_FRONTEND_ ");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FIRST', "Dacă doriţi schimbarea ordinii pentru Vizitatori/Ţări în interfaţa de vizualizare. Prin debifare, Vizitatorii vor apărea primii.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NUM', "Numărul de ţări afişate în interfaţa de vizualizare");
DEFINE('_JW_DESC_FRONTEND_VISITORS', "Afişarea ţărilor vizitatorilor în modulul interfeţei de vizualizare. Dacă este schimbată, această setare va funcţiona în interfaţa de vizualizare după timpul setat în CACHE_FRONTEND_");
DEFINE('_JW_DESC_CACHE_FRONTEND_COUNTRIES', "Timpul în secunde pentru a stoca extragerea totalului ţărilor în interfaţa de vizualizare");
DEFINE('_JW_DESC_CACHE_FRONTEND_VISITORS', "Timpul în secunde pentru a stoca extragerea vizitatorilor în interfaţa de vizualizare");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TODAY', "Pentru a afişa vizitatorii în interfaţa de vizualizare pentru: astăzi. Dacă este schimbată, această setare va funcţiona în interfaţa de vizualizare după timpul setat în CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_YESTERDAY', "Pentru a afişa vizitatorii în interfaţa de vizualizare pentru: ieri. Dacă este schimbată, această setare va funcţiona în interfaţa de vizualizare după timpul setat în CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_WEEK', "Pentru a afişa vizitatorii în interfaţa de vizualizare pentru: săptămâna aceasta. Dacă este schimbată, această setare va funcţiona în interfaţa de vizualizare după timpul setat în CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_WEEK', "Pentru a afişa vizitatorii în interfaţa de vizualizare pentru: săptămâna trecută. Dacă este schimbată, această setare va funcţiona în interfaţa de vizualizare după timpul setat în CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_MONTH', "Pentru a afişa vizitatorii în interfaţa de vizualizare pentru: luna aceasta. Dacă este schimbată, această setare va funcţiona în interfaţa de vizualizare după timpul setat în CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_MONTH', "Pentru a afişa vizitatorii în interfaţa de vizualizare pentru: luna trecută. Dacă este schimbată, această setare va funcţiona în interfaţa de vizualizare după timpul setat în CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL', "Pentru a afişa numărul total de vizitatori de la instalarea JoomlaWatch. Dacă este schimbată, această setare va funcţiona în interfaţa de vizualizare după timpul setat în CACHE_FRONTEND_...");
DEFINE('_JW_DESC_LANGUAGE', "Fişierul de limbă care va fi utilizat. Aceste fişiere pot fi găsite în /components/com_joomlawatch/lang/. Dacă doriţi creearea unui fişier nou de limbă, verificaţi mai întâi site-ul proiectului, iar dacă nu îl puteţi găsi nici aici, pur şi simplu copiaţi english.php în german.php de exemplu şi plasaţi-l în acest folder. Apoi traduceţi toate textele din partea dreaptă.");
DEFINE('_JW_DESC_GOALS', "Obiectivele vă permit să specificaţi parametri speciali. Când aceşti parametri corespund, contorul obiectivului este incrementat. Astfel puteţi monitoriza dacă utilizatorul a vizitat un URL specific, dacă a postat o anume valoare, dacă are un nume de utilizator specific sau dacă a venit de la o anume adresă. Puteţi de asemenea bloca sau redirecţiona aceşti utilizatori către un alt URL.");
DEFINE('_JW_DESC_GOALS_INSERT', "În toate câmpurile, cu excepţia numelui, puteţi utiliza * şi ? drept wildcard-uri. De exemplu: ?ear (va corespunde cu: near, tear, ..),  p*r (va corespunde cu: pr, peer, pear ..) ");
DEFINE('_JW_DESC_GOALS_BLOCK', "Setaţi-l la 1, dacă doriţi ca vizitatorul să fie blocat. Acesta nu va vedea restul conţinutului, ci doar mesajul că a fost blocat, fără nici o altă redirecţionare, iar IP-ul său va fi adăugat la statisticile 'blocked' (Exemplu de utilizat: <b>1</b>)");

/* new translations */
DEFINE('_JW_GOALS_COUNTRY_CONDITION', "Condiţie ţară");
DEFINE('_JW_GOALS_CONTRY_INVERSED', "Condiţie inversată ţară");
DEFINE('_JW_DESC_GOALS_COUNTRY_CONDITION', "Codul de două litere al ţării scris cu majuscule (exemplu: <b>TH</b>)");
DEFINE('_JW_STATS_INTERNAL',"Intern");
DEFINE('_JW_STATS_FROM',"De la");
DEFINE('_JW_STATS_TO',"La");
DEFINE('_JW_STATS_ADD_TO_GOALS',"Adăugare la obiective");
DEFINE('_JW_VISITS_ADD_GOAL_COUNTRY',"Adăugare obiectiv pentru această ţară");
DEFINE('_JW_MENU_REPORT_BUG',"Raportare bug sau caracteristică");
DEFINE('_JW_GOALS_COUNTRY',"Ţară");


/* translations 1.2.8b_12 */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_UPPERCASE',"Dacă doriţi ca numele ţărilor din interfaţa de vizualizare să fie scrise cu majuscule (exemplu: GERMANIA, MAREA BRITANIE în loc de Germania, Marea Britanie)");
DEFINE('_JW_DESC_CACHE_FRONTEND_USERS',"Timpul în secunde pentru a stoca extragerea utilizatorilor în interfaţa de vizualizare");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL_INITIAL', "Valoarea iniţială afişată în Total: în interfaţa de vizualizare. Utilă dacă aţi migrat de la alt modul statistic (exemplu: 20000). Setaţi înapoi la 0 dacă nu doriţi să utilizaţi această caracteristică.");
DEFINE('_JW_DESC_IGNORE_USER', "Ignorarea utilizatorilor listaţi în această casetă de text. Câte unul pe fiecare linie (exemplu: myself {line break} mark_*) ");
DEFINE('_JW_FRONTEND_USERS_MOST', "Cei mai activi utilizatori de astăzi dintr-un total de");
DEFINE('_JW_DESC_SPAMWORD_BANS_ENABLED',"Activaţi interzicerile pe baza cuvintelor din lista de spam de mai jos?");
DEFINE('_JW_DESC_SPAMWORD_LIST',"Cele mai comune cuvinte utilizate de roboţii spam. Puteţi utiliza wildcard-uri aici, (exemplu: ph?rmac*). Dacă setarea de mai sus este activată, JoomlaWatch va verifica dacă atacatorul a trimis un formular (cererea HTTP POST) pe site-ul dvs. cu câteva dintre aceste cuvinte spam. (Se aplică dacă formularul încarcă doar site-ul bazat pe Joomla - forum, comentarii, dar este destul de eficient pentru a bloca roboţii spam care încearcă să trimită orice formular posibil)");
DEFINE('_JW_SETTINGS_ANTI_SPAM',"Anti-Spam");
DEFINE('_JW_DESC_FRONTEND_USER_LINK',"Un link pentru utilizatori în interfaţa de vizualizare - vă permite să specificaţi un URL, care se deschide când utilizatorul dă click pe numele de utilizator. Trebuie să conţină şirul de caractere {user}, care va fi înlocuit de numele propriu-zis al utilizatorului. (exemplu: index.php?option=com_comprofiler&task=userProfile&user={user}) ");

/* translations 1.2.11b */
DEFINE('_JW_STATS_KEYPHRASE', "Fraze-cheie");
DEFINE('_JW_DESC_HISTORY_MAX_VALUES', "Numărul maxim de valori în istoric (exemplu: <i>100</i>)");

DEFINE('_JW_DESC_ONLY_LAST_URI', "În vizite arată doar ultima pagină accesată, nu toate");
DEFINE('_JW_DESC_HIDE_REPETITIVE_TITLE', "În vizite ascunde numele repetitiv de site în titlul paginii vizitate");
DEFINE('_JW_DESC_HISTORY_MAX_DB_RECORDS', "Numărul maxim de vizitatori păstraţi în baza de date pentru Istoricul vizitelor. Aveţi grijă cu această setare, dacă aveţi mult trafic, poate creşte rapid. Verificaţi întotdeauna câte informaţii conţine tabelul de istoric din Status");
DEFINE('_JW_DESC_UNINSTALL_KEEP_DATA', "Keep Database Tables on uninstall. Check this option before uninstall if you are doing an upgrade and want to keep your data.");

/* email reports */
DEFINE('_JW_DESC_EMAIL_REPORTS_ENABLED', "Noaptea veţi primi emailuri cu rapoartele din ziua anterioară, pe care le puteţi citi dimineaţa");
DEFINE('_JW_DESC_EMAIL_REPORTS_ADDRESS', "Adresa de email la care veţi primi aceste rapoarte");
DEFINE('_JW_DESC_EMAIL_PERCENT_HIGHER_THAN', "În rapoartele prin email includeţi doar rânduri când procentul este mai mare decât {value}. Setaţi la 0 dacă nu doriţi să utilizaţi această caracteristică <i>(exemplu: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_POSITIVE', "În rapoartele prin email includeţi doar schimbările <b>pozitive pe o zi</b> ale valorilor când procentul este mai mare decât {value}. Setaţi la 0 dacă nu doriţi să utilizaţi această caracteristică <i>(exemplu: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_NEGATIVE', "În rapoartele prin email includeţi doar schimbările <b>negative pe o zi</b> ale valorilor când procentul este mai mic decât {value}. Setaţi la 0 dacă nu doriţi să utilizaţi această caracteristică <i>(exemplu: -10)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_POSITIVE', "În rapoartele prin email includeţi doar schimbările <b>pozitive pe şapte zile</b> ale valorilor când procentul este mai mare decât {value}. Setaţi la 0 dacă nu doriţi să utilizaţi această caracteristică <i>(exemplu: 2)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_NEGATIVE', "În rapoartele prin email includeţi doar schimbările <b>negative pe şapte zile</b> ale valorilor când procentul este mai mic decât {value}. Setaţi la 0 dacă nu doriţi să utilizaţi această caracteristică <i>(exemplu: -13)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_POSITIVE', "În rapoartele prin email includeţi doar schimbările <b>pozitive pe 28 de zile</b>ale valorilor când procentul este mai mare decât {value}. Setaţi la 0 dacă nu doriţi să utilizaţi această caracteristică <i>(exemplu: 2)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_NEGATIVE', "În rapoartele prin email includeţi doar schimbările <b>negative pe 28 de zile</b> ale valorilor când procentul este mai mic decât {value}. Setaţi la 0 dacă nu doriţi să utilizaţi această caracteristică <i>(exemplu: -13)</i>");

DEFINE('_JW_DESC_FRONTEND_NOFOLLOW', "<b>(funcţional în versiunea PRO)</b> Activaţi această setare dacă doriţi ca linkul de la logo să aibă atributul rel='nofollow' ");
DEFINE('_JW_DESC_EMAIL_NAME_TRUNCATE', "Numărul maxim de caractere ale numelui rândului de email. Schimbaţi această valoare dacă fereastra clientului dvs. de email este prea mică");

DEFINE('_JW_MENU_HISTORY', "Istoric");
DEFINE('_JW_MENU_EMAILS', "Emailuri");
DEFINE('_JW_MENU_STATUS', "Status bază de date");
DEFINE('_JW_DESC_BLOCKED',"Aceste IP-uri au fost blocate de anti-spam");


DEFINE('_JW_HISTORY_VISITORS',"Istoric vizitatori");
DEFINE('_JW_HISTORY_SHOWING_ONLY', "Afişează doar ultimele %d înregistrări.
                Pentru a schimba această valoare, mergeţi la Setări -&gt; Istoric &amp; Performanţă -&gt; HISTORY_MAX_DB_RECORDS . Aveţi grijă, această setare afectează timpii de încărcare a datelor de mai jos.  ");
DEFINE('_JW_MENU_BUG', "Raportare bug");
DEFINE('_JW_MENU_FEATURE', "Solicitare caracteristică");

DEFINE('_JW_VISITS_CAME_FROM_KEYWORDS',"Cuvinte-cheie");

DEFINE('_JW_BLOCKING_UNBLOCK',"deblocare");
DEFINE('_JW_STATS_KEYPHRASE ',"Fraze-cheie");

DEFINE('_JW_STATUS_DATABASE_TABLE_NAME',"nume tabel");
DEFINE('_JW_STATUS_DATABASE_ROWS',"rânduri");
DEFINE('_JW_STATUS_DATABASE_DATA',"date");
DEFINE('_JW_STATUS_DATABASE_TOTAL',"total");

DEFINE('_JW_EMAIL_REPORTS',"Rapoarte prin email");
DEFINE('_JW_EMAIL_REPORT_GENERATED',"Raportul prin email generat şi filtrat de ieri");
DEFINE('_JW_EMAIL_REPORTS_VALUE_FILTERS',"Filtre valoare email");
DEFINE('_JW_EMAIL_REPORTS_VALUE',"valoare");
DEFINE('_JW_EMAIL_REPORTS_PERCENT',"procent");
DEFINE('_JW_EMAIL_REPORTS_1DAY_CHANGE',"schimbare pe o zi");
DEFINE('_JW_EMAIL_REPORTS_7DAY_CHANGE',"schimbare pe şapte zile");
DEFINE('_JW_EMAIL_REPORTS_28DAY_CHANGE',"schimbare pe 28 de zile");
DEFINE('_JW_ANTISPAM_BLOCKED',"Astăzi JoomlaWatch a blocat %d afişări spam, total: %d");
DEFINE('_JW_ANTISPAM_ADDRESSES',"Adrese IP blocate");
DEFINE('_JW_ANTISPAM_SETTINGS',"Setări Anti-Spam");
DEFINE('_JW_TRAFFIC_AJAX',"AJAX actualizează traficul (cu excepţia hărţilor)");


DEFINE('_JW_HISTORY_PREVIOUS',"înapoi");
DEFINE('_JW_HISTORY_NEXT',"înainte");

/** additional translation for 1.2.11 for countries in more rows */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_COLUMNS',"Numărul de coloane pentru ţări");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_ROWS',"Numărul de rânduri pentru ţări");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NAMES',"Afişaţi sau nu numele ţărilor");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FLAGS_FIRST',"Afişaţi mai întâi steagurile, apoi procentele");

/* JoomlaWatch 1.2.14 translations */

DEFINE('_JW_GOALS_GET_INVERSED', "Condiţie inversată GET");
DEFINE('_JW_GOALS_POST_INVERSED', "Condiţie inversată POST");
DEFINE('_JW_GOALS_TITLE_INVERSED', "Condiţie inversată titlu");
DEFINE('_JW_GOALS_USERNAME_INVERSED', "Condiţie inversată nume de utilizator");
DEFINE('_JW_GOALS_CAME_FROM_INVERSED', "Venit de la condiţia inversată");

DEFINE('_JW_STATS_MAP', "Harta ultimelor vizite");
DEFINE('_JW_STATS_MAP_ENTER_KEY',"Vă rugăm să introduceţi cheia <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a> pentru a afişa harta ultimelor vizite:");
DEFINE('_JW_STATS_MAP_STORE_KEY',"salvare cheie");
DEFINE('_JW_STATS_MAP_INVALID_KEY',"Vă rugăm să introduceţi o cheie ipinfodb validă obţinută de la: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");

DEFINE('_JW_SIZEQUERY_BAD_REQUEST',"CERERE GREŞITĂ: ");

DEFINE('_JW_VISIT_SUBMITED_FIELDS',"Câmpuri de formular trimise:");
DEFINE('_JW_VISIT_URL_PARAMETERS',"Parametri URL:");
DEFINE('_JW_VISIT_ADD_PAGE'," Adaugare pagină ca obiectiv");
DEFINE('_JW_VISIT_BLOCK_IP'," Blocarea acestei adrese IP");
DEFINE('_JW_VISIT_SUBMITED_FROM_VARIABLE'," Adăugarea acestei variabile din formular ca obiectiv");
DEFINE('_JW_VISIT_URL_PARAMETER_GOAL'," Adăugarea acestui parametru URL ca obiectiv");

DEFINE('_JW_TREND_EMPTY',"Empty");

DEFINE('_JW_NOT_NUMBER'," ATENŢIE: Valoarea introdusă nu este un număr. JoomlaWatch nu va funcţiona corespunzător!");
DEFINE('_JW_EVALUATION_LEFT',"&nbsp; Aceasta este o versiune de evaluare pentru 15 zile. Zile rămase: <b>%d</b>. Vă rugăm să cumpăraţi <a href='http://www.codegravity.com/donate/joomlawatch/' target='_blank'>licenţa nelimitată JoomlaWatch pentru domeniul dvs.</a> a acestei versiuni şi a celor următoare.");
DEFINE('_JW_TRIAL_VERSION_EXPIRED'," Versiunea dvs. de evaluare a expirat. Vă rugăm să cumpăraţi JoomlaWatch");

DEFINE('_JW_CONFIG_LICENSE_ACTIVATED',"Licenţă activată cu succes. Vă mulţumim.");
DEFINE('_JW_CONFIG_LICENCE_DONT_MATCH',"<b>Eroare: cheia de licenţă nu corespunde cu domeniul dvs.</b><br/>Aţi introdus acelaşi nume de domeniu în formularul de donaţie ca şi cel pe care îl vedeţi mai jos? <br/>Click pe '<b>request the correct activation key</b>' de mai jos, sau contactaţi-ne la: info@codegravity.com<br/>");

DEFINE('_JW_VIEW_ADMINBODY_LONG_MESSAGE',"Dacă mesajul de mai sus este afişat prea mult, statisticile dvs. în timp real ar putea fi greşite.
                    Deschideţi components/com_joomlawatch/config.php
                    decomentaţi şi setaţi site-ul dvs. propriu-zis. De exemplu:
                    define('JOOMLAWATCH_LIVE_SITE', 'http://www.codegravity.com');");

DEFINE('_JW_ADMINBODY_LIVE_SITE',"Atenţie: site-ul din browser şi site-ul din configurare: %s şi %s nu corespund.");
DEFINE('_JW_ADMINBODY_SET_LIVE_SITE',"Setaţi site-ul către: %s şi continuaţi...");

DEFINE('_JW_ADMINHEADER_JW',"JoomlaWatch ");
DEFINE('_JW_ADMINHEADER_REMOVE_BACKLINK',"Ştergeţi backlink");
DEFINE('_JW_ADMINHEADER_KNOWLEDGE_BASE',"Baza de date cu informaţii ajutătoare");
DEFINE('_JW_ADMINHEADER_FLOW',"Flux");
DEFINE('_JW_ADMINHEADER_GRAPHS',"Grafice");
DEFINE('_JW_ADMINHEADER_COMPONENTS',"Componente");
DEFINE('_JW_ADMINHEADER_REVIEW',"Recenzie");
DEFINE('_JW_ADMINHEADER_WRITE',"Scrieţi o ");

DEFINE('_JW_FLOW_TRAFFIC',"Flux de trafic");
DEFINE('_JW_FLOW_SELECT_PAGE',"Selectare pagină:");
DEFINE('_JW_FLOW_OUTG_LINKS',"Contor linkuri externe:");
DEFINE('_JW_FLOW_NESTING',"Nivel nesting:");
DEFINE('_JW_FLOW_SCALE',"Scală:");

DEFINE('_JW_COMERCIAL_AD_FREE',"Versiunea fără reclame");
DEFINE('_JW_COMERCIAL_THANK_DONATION',"Vă mulţumim mult pentru donaţia făcută!");
DEFINE('_JW_COMERCIAL_REGISTRATION_KEY',"Cheia de înregistrare pentru domeniul dvs. %s este: ");
DEFINE('_JW_COMERCIAL_BACKLINKS_REMOVE',"Acum puteţi şterge backlink-ul sau ascunde logo-ul JoomlaWatch în interfaţa de vizualizare din Setări ");


DEFINE('_JW_SIZES_LAST_CHECK',"Ultima verificare a fost făcută pe:");
DEFINE('_JW_SIZES_ADMINISTRATOR',"BLUE = Mărimea componentei/modulului în folderul /administrator");

DEFINE('_JW_SIZECOMPONENTS_COMPONENT',"Componentă");
DEFINE('_JW_SIZECOMPONENTS_TOTAL',"Total:");
DEFINE('_JW_SIZECOMPONENTS_SIZE',"Mărime");
DEFINE('_JW_SIZECOMPONENTS_REFRESH_ALL',"Reactualizarea tuturor");

DEFINE('_JW_SIZEDATABASE_TABLE',"Tabel");
DEFINE('_JW_SIZEDATABASE_SIZE',"Mărime");
DEFINE('_JW_SIZEDATABASE_1DAY',"schimbare pe o zi");
DEFINE('_JW_SIZEDATABASE_7DAY',"schimbare pe şapte zile");
DEFINE('_JW_SIZEDATABASE_28DAY',"schimbare pe 28 de zile");
DEFINE('_JW_SIZEDATABASE_NO_DATA',"nu există date");
DEFINE('_JW_SIZEDATABASE_TOTAL',"Total:");

DEFINE('_JW_SIZEMODULES_REFRESH_ALL',"Reactualizarea tuturor");
DEFINE('_JW_SIZEMODULES_TOTAL',"Total:");
DEFINE('_JW_SIZEMODULES_MODULE',"Modul");
DEFINE('_JW_SIZEMODULES_SIZE',"Mărime");

DEFINE('_JW_SIZES_FILES',"Fişiere &amp; Foldere");
DEFINE('_JW_SIZES_BYTES',"bytes");
DEFINE('_JW_SIZES_KB',"KB");
DEFINE('_JW_SIZES_MB',"MB");
DEFINE('_JW_SIZES_GB',"GB");
DEFINE('_JW_SIZES_REFRESH',"Reactualizare");

DEFINE('_JW_STATS_FOOTER',"JoomlaWatch &copy;2006-@YEAR@ by Matej Koval");

DEFINE('_JW_STATUS_MB',"MB");
DEFINE('_JW_STATUS_DATABASE',"Mărimile tabelelor din baza de date");


DEFINE('_JW_DESC_IPINFODB_KEY',"Ultima cheie ipinfodb.com pentru harta vizitelor de la: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");
DEFINE('_JW_SETTINGS_FORCE_TIMEZONE_OFFSET',"Forţarea corectării fusului orar");


/* JoomlaWatch 1.2.17 translations */

DEFINE('_JW_MENU_UPDATE', "Actualizare");
DEFINE('_JW_MENU_UPDATE_TITLE', "Backup & Actualizare");
DEFINE('_JW_ADMINHEADER_NA_IN_THIS_VERSION',"Nu este disponibil în versiunea gratuită, vă rugăm să verificaţi secţiunea de licenţă");
DEFINE('_JW_SPAMWORD_BANS_ENABLED', "Activarea banării cuvintelor spam");
DEFINE('_JW_SPAMWORD_LIST', "Lista cuvintelor spam");
DEFINE('_JW_HIDE_REPETITIVE_TITLE', "Ascunderea titlului repetitiv");
DEFINE('_JW_TRUNCATE_VISITS', "Trunchiere vizite");
DEFINE('_JW_TRUNCATE_STATS', "Trunchiere statistici");
DEFINE('_JW_TRUNCATE_GOALS', "Trunchiere obiective");
DEFINE('_JW_LIMIT_BOTS', "Limitare roboţi");
DEFINE('_JW_LIMIT_VISITORS', "Limitare vizitatori");
DEFINE('_JW_TOOLTIP_WIDTH', "Lăţimea secţiunii de informaţii ajutătoare");
DEFINE('_JW_TOOLTIP_HEIGHT', "Înălţimea secţiunii de informaţii ajutătoare");
DEFINE('_JW_TOOLTIP_URL', "URL-ul secţiunii de informaţii ajutătoare");
DEFINE('_JW_TOOLTIP_ONCLICK', "Secţiune de informaţii ajutătoare de tip OnClick");
DEFINE('_JW_IP_STATS', "Statistici IP");
DEFINE('_JW_IPINFODB_KEY', "Cheie IP Info DB ");
DEFINE('_JW_ONLY_LAST_URI', "Doar ultimul URI ");

DEFINE('_JW_FRONTEND_HIDE_LOGO', "Ascundere logo în interfaţa de vizualizare ");
DEFINE('_JW_FRONTEND_NOFOLLOW', "No Follow în interfaţa de vizualizare");
DEFINE('_JW_FRONTEND_NO_BACKLINK', "Fără Back Link în interfaţa de vizualizare");
DEFINE('_JW_FRONTEND_USER_LINK', "Linkuri utilizator în interfaţa de vizualizare");
DEFINE('_JW_FRONTEND_COUNTRIES_FIRST', "Mai întâi ţările în interfaţa de vizualizare");
DEFINE('_JW_FRONTEND_COUNTRIES_NAMES', "Nume ţări în interfaţa de vizualizare");
DEFINE('_JW_FRONTEND_COUNTRIES_UPPERCASE', "Majuscule ţări în interfaţa de vizualizare");
DEFINE('_JW_FRONTEND_COUNTRIES_FLAGS_FIRST', "Mai întâi steagul ţărilor în interfaţa de vizualizare ");
DEFINE('_JW_FRONTEND_COUNTRIES_NUM', "Număr ţări în interfaţa de vizualizare");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_COLUMNS', "Numărul maxim de coloane pentru ţări în interfaţa de vizualizare");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_ROWS', "Numărul maxim de rânduri pentru ţări în interfaţa de vizualizare");
DEFINE('_JW_FRONTEND_VISITORS_TODAY', "Vizitatorii de astăzi în interfaţa de vizualizare ");
DEFINE('_JW_FRONTEND_VISITORS_YESTERDAY', "Vizitatorii de ieri în interfaţa de vizualizare ");
DEFINE('_JW_FRONTEND_VISITORS_THIS_WEEK', "Vizitatorii de săptămâna aceasta în interfaţa de vizualizare ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_WEEK', "Vizitatorii de săptămâna trecută în interfaţa de vizualizare ");

DEFINE('_JW_FRONTEND_VISITORS_THIS_MONTH', "Vizitatorii de luna aceasta în interfaţa de vizualizare ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_MONTH', "Vizitatorii de luna trecută în interfaţa de vizualizare");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL', "Ascundere total vizitatori în interfaţa de vizualizare");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL	', "Total iniţial în interfaţa de vizualizare");
DEFINE('_JW_HISTORY_MAX_VALUES', "Numărul maxim de valori din istoric");
DEFINE('_JW_HISTORY_MAX_DB_RECORDS', "Numărul maxim de înregistrări din istoric");
DEFINE('_JW_UPDATE_TIME_VISITS', "Actualizare timp vizite");
DEFINE('_JW_UPDATE_TIME_STATS', "Actualizare statistici de timp");
DEFINE('_JW_STATS_MAX_ROWS', "Numărul maxim de rânduri ale statisticilor");
DEFINE('_JW_STATS_IP_HITS', "Statistici afişări IP");
DEFINE('_JW_MAXID_BOTS', "Numărul maxim de ID-uri roboţi");
DEFINE('_JW_MAXID_VISITORS', "Numărum maxim de ID-uri vizitatori");
DEFINE('_JW_STATS_KEEP_DAYS', "Numărul de zile pentru păstrarea statisticilor ");
DEFINE('_JW_CACHE_FRONTEND_COUNTRIES', "Stocare ţări în interfaţa de vizualizare ");
DEFINE('_JW_CACHE_FRONTEND_VISITORS', "Stocare vizitatori în interfaţa de vizualizare ");

DEFINE('_JW_UNINSTALL_KEEP_DATA	', "Dezinstalare păstrare date ");
DEFINE('_JW_IGNORE_IP', "Ignorare IP");
DEFINE('_JW_IGNORE_URI', "Ignorare URI");
DEFINE('_JW_IGNORE_USER', "Ignorare utilizator");
DEFINE('_JW_BLOCKING_MESSAGE', "Blocare mesaj");
DEFINE('_JW_SERVER_URI_KEY', "Cheie server URI");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL', "Total iniţial vizitatori în interfaţa de vizualizare");
DEFINE('_JW_SIZEDATABASE_RECORDS', "Înregistrări");
/***********EDITs******************/
DEFINE('_JW_ANTISPAM_BLOCKING_TEXT'," Pentru ca blocarea să aibă efect, trebuie să publicaţi agentul JoomlaWatch ÎNAINTE de orice conţinut sau formulare. De exemplu în partea stângă a template-ului dvs.
                    <br/>
                    Mergeţi la Module Manager -> JoomlaWatch agent -> selectaţi poziţia la stânga");

DEFINE('_JW_EMAIL_SEO_REPORTS', "Rapoarte SEO");
DEFINE('_JW_DESC_EMAIL_SEO_REPORTS_ENABLED',"Rapoarte SEO prin email trimis noaptea, activate");
DEFINE('_JW_WATCH_INSTALLATION_DEMO',"Vizualizaţi demo instalare");

?>