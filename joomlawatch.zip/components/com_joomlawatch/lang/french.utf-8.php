<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version @VERSION@
 * @revision @REVISION@
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) @YEAR@ by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/
defined( '_JEXEC' ) or die( 'Restricted access' );

#JoomlaWatch - fichier de langue : Français - Version 1.1 - 06/08/2011 par Lalit MOUTAL

# Main Menu
DEFINE('_JW_MENU_STATS', "Visites &amp; Statistiques");
DEFINE('_JW_MENU_GOALS', "Cibles");
DEFINE('_JW_MENU_SETTINGS', "Réglages");
DEFINE('_JW_MENU_CREDITS', "Crédits");
DEFINE('_JW_MENU_FAQ', "Foire aux questions");
DEFINE('_JW_MENU_DOCUMENTATION', "Documentation");
DEFINE('_JW_MENU_LICENSE', "Licence");
DEFINE('_JW_MENU_DONATORS', "Faire un don");
DEFINE('_JW_MENU_SUPP', "Soutenez JoomlaWatch pour masquer les publicités dans le Back-end !");

# Left visitors real-time window
DEFINE('_JW_VISITS_VISITORS', "Derniers visiteurs");
DEFINE('_JW_VISITS_BOTS', "Derniers bots");
DEFINE('_JW_VISITS_CAME_FROM', "Provenance&nbsp;");
DEFINE('_JW_VISITS_MODULE_NOT_PUBLISHED', "Le module de JoomlaWatch n'est pas publié ! Par conséquent, aucune statistique ne sera enregistrée. Pour le publier, allez dans le menu Modules, activez-le puis affectez-le à tous les menus.");
DEFINE('_JW_VISITS_PANE_LOADING', "Chargement des visites en cours...  Veuillez patienter !");

# Right stats window
DEFINE('_JW_STATS_TITLE', "Statistiques des visites hebdomadaires pour la semaine&nbsp;");
DEFINE('_JW_STATS_WEEK', "Semaine");
DEFINE('_JW_STATS_THIS_WEEK', "Cette semaine");
DEFINE('_JW_STATS_UNIQUE', "visiteurs");
DEFINE('_JW_STATS_LOADS', "pages vues");
DEFINE('_JW_STATS_HITS', "hits");
DEFINE('_JW_STATS_TODAY', "aujourd'hui");
DEFINE('_JW_STATS_FOR', "au");
DEFINE('_JW_STATS_ALL_TIME', "Stats globales :");
DEFINE('_JW_STATS_EXPAND', "développer la liste des");
DEFINE('_JW_STATS_COLLAPSE', "condenser la liste des");
DEFINE('_JW_STATS_URI', "Pages");
DEFINE('_JW_STATS_COUNTRY', "Pays");
DEFINE('_JW_STATS_USERS', "Utilisateurs");
DEFINE('_JW_STATS_REFERERS', "Référenceurs");
DEFINE('_JW_STATS_IP', "Adresses IP");
DEFINE('_JW_STATS_BROWSER', "Navigateurs");
DEFINE('_JW_STATS_OS', "Systèmes d'exploitations");
DEFINE('_JW_STATS_KEYWORDS', "Mots-clés");
DEFINE('_JW_STATS_GOALS', "Cibles");
DEFINE('_JW_STATS_TOTAL', "Total&nbsp;");
DEFINE('_JW_STATS_DAILY', "Stats journalières :");
DEFINE('_JW_STATS_DAILY_TITLE', "Statistiques journalières du&nbsp;");
DEFINE('_JW_STATS_ALL_TIME_TITLE', "Statistiques globales");
DEFINE('_JW_STATS_LOADING', "Chargement...");
DEFINE('_JW_STATS_LOADING_WAIT', "Chargement en cours... Veuillez patienter !");
DEFINE('_JW_STATS_IP_BLOCKING_TITLE', "Bloquer les IP");
DEFINE('_JW_STATS_IP_BLOCKING_ENTER', "Entrer une IP manuellement");
DEFINE('_JW_STATS_IP_BLOCKING_MANUALLY', "Entrez l'adresse IP que vous voulez bloquer. Par exemple : 217.242.11.54 ou 217.* ou 217.242.* pour bloquer toutes les adresses qui débutent par les valeurs qui précèdent l'étoile.");
DEFINE('_JW_STATS_IP_BLOCKING_TOGGLE', "Voulez-vous basculer l'état de l'adresse IP ");
DEFINE('_JW_STATS_PANE_LOADING', "Chargement des statistiques en cours...");

# Settings
DEFINE('_JW_SETTINGS_TITLE', "Réglages");
DEFINE('_JW_SETTINGS_DEFAULT', "Par défaut&nbsp;");
DEFINE('_JW_SETTINGS_SAVE', "Enregistrer");
DEFINE('_JW_SETTINGS_APPEARANCE', "Apparences");
DEFINE('_JW_SETTINGS_FRONTEND', "Front-end");
DEFINE('_JW_SETTINGS_HISTORY_PERFORMANCE', "Historique &amp; Performance");
DEFINE('_JW_SETTINGS_ADVANCED', "Mode avancé");
DEFINE('_JW_SETTINGS_IGNORE', "Ignorer");
DEFINE('_JW_SETTINGS_BLOCKING', "Bloquer");
DEFINE('_JW_SETTINGS_EXPERT', "Mode expert");
DEFINE('_JW_SETTINGS_RESET_CONFIRM', "Voulez-vous réellement réinitialiser toutes les statistiques et les informations sur les visiteurs ?");
DEFINE('_JW_SETTINGS_RESET_ALL', "Réinitialiser");
DEFINE('_JW_SETTINGS_RESET_ALL_LINK', "Réinitialisation des statistiques et des informations sur les visiteurs");
DEFINE('_JW_SETTINGS_LANGUAGE', "Langue");
DEFINE('_JW_SETTINGS_SAVED', "Les réglages ont été sauvegardés");
DEFINE('_JW_SETTINGS_ADD_YOUR_IP', "Ajouter votre adresse IP");
DEFINE('_JW_SETTINGS_TO_THE_LIST', "à la liste.");

# Other / mostly general
DEFINE('_JW_TITLE', "<i>Moniteur AJAX en temps réel</i>");
DEFINE('_JW_BACK', "Retour");
DEFINE('_JW_ACCESS_DENIED', "Vous n'avez pas l'autorisation pour voir ceci !");
DEFINE('_JW_LICENSE_AGREE', "J'accepte les termes &amp; les conditions générales ci-dessus");
DEFINE('_JW_LICENSE_CONTINUE', "Continuer");
DEFINE('_JW_SUCCESS', "Opération effectuée !");
DEFINE('_JW_RESET_SUCCESS', "Toutes les statistiques et les informations sur les visiteurs ont été effacées !");
DEFINE('_JW_RESET_ERROR', "Une erreur est survenue ! Les données n'ont pas été effacées.");
DEFINE('_JW_CREDITS_TITLE', "Crédits");
DEFINE('_JW_TRENDS_DAILY_WEEKLY', "Statistiques quotidennes et hebdomadaires pour les");
DEFINE('_JW_AJAX_PERMISSION_DENIED_1', "L'autorisation via AJAX a été refusée ! Vous devez afficher les statistiques à partir du domaine spécifié dans le fichier config.php de Joomla! - ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_2', "Vous avez peut-être oublié les 'www' au début de votre nom de domaine. Votre Javascript tente d'y accéder ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_3', "de");
DEFINE('_JW_AJAX_PERMISSION_DENIED_4', "c'est pourquoi il pense que c'est un nom de domaine différent.");

# Header
DEFINE('_JW_HEADER_DOWNLOAD', "<br />Téléchargez la dernière version sur ");
DEFINE('_JW_HEADER_CAST_YOUR', "Vous aimez JoomlaWatch ?<br />Dans ce cas, pensez à");
DEFINE('_JW_HEADER_VOTE', "voter");

# Tooltips
DEFINE('_JW_TOOLTIP_CLICK', "Cliquez pour afficher les informations");
DEFINE('_JW_TOOLTIP_MOUSE_OVER', "Survolez pour afficher les informations");
DEFINE('_JW_TOOLTIP_YESTERDAY_INCREASE', "Variation depuis la veille");
DEFINE('_JW_TOOLTIP_HELP', "Ouvre une fenêtre d'aide");
DEFINE('_JW_TOOLTIP_WINDOW_CLOSE', "Fermer cette fenêtre");
DEFINE('_JW_TOOLTIP_PRINT', "Imprimer");

# Goals
DEFINE('_JW_GOALS_INSERT', "Nouvelle cible");
DEFINE('_JW_GOALS_UPDATE', "Mettre à jour la cible n°");
DEFINE('_JW_GOALS_ACTION', "Actions");
DEFINE('_JW_GOALS_TITLE', "Cibles");
DEFINE('_JW_GOALS_NEW', "Créer une nouvelle cible");
DEFINE('_JW_GOALS_RELOAD', "Rafraîchir");
DEFINE('_JW_GOALS_ADVANCED', "Conditions avancées");
DEFINE('_JW_GOALS_NAME', "Nom");
DEFINE('_JW_GOALS_ID', "ID");
DEFINE('_JW_GOALS_URI_CONDITION', "URI");
DEFINE('_JW_GOALS_URI_INVERSED', "Condition inversée");
DEFINE('_JW_GOALS_GET_VAR', "GET variable");
DEFINE('_JW_GOALS_GET_CONDITION', "Valeur pour GET");
DEFINE('_JW_GOALS_POST_VAR', "POST variable");
DEFINE('_JW_GOALS_POST_CONDITION', "Valeur pour POST");
DEFINE('_JW_GOALS_TITLE_CONDITION', "Titre");
DEFINE('_JW_GOALS_USERNAME_CONDITION', "Identifiant");
DEFINE('_JW_GOALS_IP_CONDITION', "IP");
DEFINE('_JW_GOALS_IP_INVERSED', "Condition inversée");
DEFINE('_JW_GOALS_CAME_FROM_CONDITION', "Provenance");
DEFINE('_JW_GOALS_BLOCK', "Bloquer le visiteur");
DEFINE('_JW_GOALS_REDIRECT', "Rediriger vers l'URL");
DEFINE('_JW_GOALS_HITS', "Hits");
DEFINE('_JW_GOALS_ENABLED', "Activé");
DEFINE('_JW_GOALS_EDIT', "Éditer");
DEFINE('_JW_GOALS_DELETE', "Effacer");
DEFINE('_JW_GOALS_DELETE_CONFIRM', "Vous allez perdre toutes les données récentes de statistiques pour cette cible. Voulez-vous vraiment effacer la cible n°");

# Frontend
DEFINE('_JW_FRONTEND_COUNTRIES', "Pays&nbsp;");
DEFINE('_JW_FRONTEND_VISITORS', "Visiteurs&nbsp;");
DEFINE('_JW_FRONTEND_TODAY', "Aujourd'hui&nbsp;");
DEFINE('_JW_FRONTEND_YESTERDAY', "Hier&nbsp;");
DEFINE('_JW_FRONTEND_THIS_WEEK', "Cette semaine&nbsp;");
DEFINE('_JW_FRONTEND_LAST_WEEK', "La semaine dernière&nbsp;");
DEFINE('_JW_FRONTEND_THIS_MONTH', "Ce mois-ci&nbsp;");
DEFINE('_JW_FRONTEND_LAST_MONTH', "Le mois dernier&nbsp;");
DEFINE('_JW_FRONTEND_TOTAL', "Total des visiteurs&nbsp;");

# Settings description - quite long
DEFINE('_JW_DESC_DEBUG', "JoomlaWatch est en mode débuggage. Grâce à ce mode, vous pouvez découvrir les causes d'erreurs. Pour le désactiver, veuillez changer la valeur de JOOMLAWATCH_DEBUG de 1 à 0 dans le fichier /components/com_joomlawatch/config.php.");
DEFINE('_JW_DESC_STATS_MAX_ROWS', "Nombre de lignes maximum affichées quand une liste de l'onglet Stats (journalières ou globales) est développée.");
DEFINE('_JW_DESC_STATS_IP_HITS', "Toutes les adresses IP qui ont effectué un nombre de hits inférieur à cette valeur la veille seront supprimées de l'historique des IP.");
DEFINE('_JW_DESC_STATS_URL_HITS', "Toutes les adresses URL qui ont eu un nombre de hits inférieur à cette valeur la veille seront supprimées de l'historique des IP.");
DEFINE('_JW_DESC_IGNORE_IP', "Entrez les adresses IP que vous souhaitez ignorer dans les statistiques. Par exemple, en rentrant votre adresse IP, l'intérêt est de ne pas fausser les statistiques lorsque vous surfez sur votre propre site. Vous devez saisir une adresse IP par ligne. Vous pouvez aussi utiliser des jokers *. Par exemple : 192.* va ignorer 192.168.51.31, 192.168.16.2, etc...");
DEFINE('_JW_DESC_UPDATE_TIME_VISITS', "<i>(Par défaut : 2000)</i>&nbsp;&nbsp;Temps de rafraîchissement des visiteurs en millisecondes. Maniez ces valeurs avec précaution (gourmand en ressources) puis rechargez la page de JoomlaWatch.");
DEFINE('_JW_DESC_UPDATE_TIME_STATS', "<i>(Par défaut : 4000)</i>&nbsp;&nbsp;Temps de rafraîchissement des statistiques en millisecondes. Maniez ces valeurs avec précaution (gourmand en ressources) puis rechargez la page de JoomlaWatch.");
DEFINE('_JW_DESC_MAXID_BOTS', "Nombre de visites de bots à conserver.");
DEFINE('_JW_DESC_MAXID_VISITORS', "Nombre de visiteurs uniques à conserver.");
DEFINE('_JW_DESC_LIMIT_BOTS', "Nombre de bots visibles dans le Back-end.");
DEFINE('_JW_DESC_LIMIT_VISITORS', "Nombre de visiteurs uniques visibles dans le Back-end.");
DEFINE('_JW_DESC_TRUNCATE_VISITS', "Nombre de caractères maximum qui seront affichés pour les titres longs et les URL.");
DEFINE('_JW_DESC_TRUNCATE_STATS', "Nombre de caractères maximum qui seront affichés dans le panneau de statistiques à droite.");
DEFINE('_JW_DESC_STATS_KEEP_DAYS', "Nombre de jours pendant lesquels les statistiques sont conservées. Saisir 0 pour une durée illimitée.");
DEFINE('_JW_DESC_TIMEZONE_OFFSET', "Lorsque vous vous trouvez dans un fuseau horaire différent de celui de votre serveur (ajoutez ou supprimez des heures).");
DEFINE('_JW_DESC_WEEK_OFFSET', "Réglage de la semaine : l'horodatage /(3600x24x7) donne la date du 1.1.1970. Ce réglage permet de faire débuter les semaines le lundi ");
DEFINE('_JW_DESC_DAY_OFFSET', "Réglage du jour : l'horodatage/(3600x24) donne la date du 1.1.1970. Ce réglage permet de faire débuter les jours à 00:00 ");
DEFINE('_JW_DESC_FRONTEND_HIDE_LOGO', "<b><i>(Version Pro uniquement)</i></b>&nbsp;&nbsp;Cochez pour utiliser une icône de 1px par 1px invisible dans le Front-end à la place du logo de JoomlaWatch (module JoomlaWatch Agent).");
DEFINE('_JW_DESC_IP_STATS', "Cochez pour enregister les statistiques des adresses IP. Attention, dans certains pays conserver une adresse IP en mémoire est interdit par la loi. Vous utilisez cette fonction à vos risques et périls !");
DEFINE('_JW_DESC_HIDE_ADS', "Ce réglage permet de masquer les publicités dans le Back-end. En les conservant, vous nous aidez à développer ce composant. Merci !");
DEFINE('_JW_DESC_TOOLTIP_ONCLICK', "Cochez pour faire apparaître la fenêtre de géolocalisation en cliquant sur l'icône plutôt qu'en passant la souris au-dessus.");
DEFINE('_JW_DESC_SERVER_URI_KEY', "La valeur par défaut est 'REDIRECT_URL' qui est le standard si vous avez activé la reécriture des URL (SEF). La valeur peut être réglée sur 'SCRIPT_URL' qui renvoie vers index.php.");
DEFINE('_JW_DESC_BLOCKING_MESSAGE', "Message qui s'affiche lorsqu'une personne tente de se connecter sur le site alors que son adresse IP est bloquée.");
DEFINE('_JW_DESC_TOOLTIP_WIDTH', "Largeur de la fenêtre de géolocalisation (l'icône pour ouvrir cette fenêtre est à gauche de l'adresse IP).");
DEFINE('_JW_DESC_TOOLTIP_HEIGHT', "Hauteur de la fenêtre de géolocalisation (l'icône pour ouvrir cette fenêtre est à gauche de l'adresse IP).");
DEFINE('_JW_DESC_TOOLTIP_URL', "URL du site pour effectuer une recherche sur l'IP de l'utilisateur. L'expression {ip} sera remplacée par l'adresse IP du visiteur dans l'URL. Par exemple : http://siteweb.com/query?iplookup=<b>{ip}</b>.");
DEFINE('_JW_DESC_IGNORE_URI', "Entrez toutes les portions d'URL qui suivent le nom de domaine (URI) que vous souhaitez ignorer dans les statistiques. Vous devez saisir une adresse URI par ligne. Vous pouvez aussi utiliser des jokers * et ?. Par exemple : /freel?n*.");
DEFINE('_JW_DESC_GOALS_NAME', "Entrez un nom pour la cible. Ce nom apparaîtra dans l'onglet Visites &amp; Statistiques.");
DEFINE('_JW_DESC_GOALS_URI_CONDITION', "Portion d'une URL qui suit le nom de domaine. Par exemple : pour l'URL http://www.codegravity.com/projets/, l'URI est : /projets/. Vous devez donc saisir <b>/projets*</b>. Si vous cochez 'Condition inversée', cela signifie : lorsque l'URI n'est pas la valeur saisie.");
DEFINE('_JW_DESC_GOALS_GET_VAR', "GET variable est une variable que l'on trouve dans une URL généralement après un ? ou une *. Par exemple : http://www.codegravity.com/index.php?<b>prenom</b>=patrick&amp;<b>nom</b>=smith. Vous pouvez aussi utiliser un joker * dans ce champ pour obtenir toutes les variables correspondantes, par exemple : <b>pren*m</b>.");
DEFINE('_JW_DESC_GOALS_GET_CONDITION', "Entrez une valeur à rechercher pour la variable du champ précédent. Par exemple : si la variable est 'prenom', dans ce cas on peut effectuer une recherche sur <b>p?tr*ck</b>. Si vous cochez 'Condition inversée', cela signifie : lorsque le résultat n'est pas la valeur saisie.");
DEFINE('_JW_DESC_GOALS_POST_VAR', "POST variable est une variable que l'on trouve dans les formulaires. Cette variable fonctionne si vous avez des formulaires dans votre site qui ont des champs avec la syntaxe &lt;input type='text' name='<b>experience</b>' /&gt;. Vous pouvez aussi utiliser un joker * dans ce champ pour obtenir toutes les variables correspondantes, par exemple : <b>exper*ce</b>.");
DEFINE('_JW_DESC_GOALS_POST_CONDITION', "Entrez une valeur à rechercher pour la variable du champ précédent. Par exemple : si la variable est 'experience', on peut effectuer une recherche pour savoir si la personne a des connaissances en Java, dans ce cas saisir <b>*java*</b>. Si vous cochez 'Condition inversée', cela signifie : lorsque le résultat n'est pas la valeur saisie.");
DEFINE('_JW_DESC_GOALS_TITLE_CONDITION', "Titre d'une page. Par exemple : <b>*designer freelance*</b>. Si vous cochez 'Condition inversée', cela signifie : lorsque le titre n'est pas la valeur saisie.");
DEFINE('_JW_DESC_GOALS_USERNAME_CONDITION', "Identifiant de l'utilisateur enregistré. Par exemple : <b>pdupond*</b>. Si vous cochez 'Condition inversée', cela signifie : lorsque l'identifiant n'est pas la valeur saisie.");
DEFINE('_JW_DESC_GOALS_IP_CONDITION', "Adresse IP d'un utilisateur. Par exemple : <b>201.9?.*.*</b>. Si vous cochez 'Condition inversée', cela signifie : lorsque l'adresse IP n'est pas la valeur saisie.");
DEFINE('_JW_DESC_GOALS_CAME_FROM_CONDITION', "URL d'où provient l'utilisateur. Par exemple : <b>*www.google.*</b>. Si vous cochez 'Condition inversée', cela signifie : lorsque la provenance n'est pas la valeur saisie.");
DEFINE('_JW_DESC_GOALS_REDIRECT', "Rediriger l'utilisateur vers l'URL que vous avez spécifiée au lieu de le bloquer. Par exemple : <b>http://www.codegravity.com/aurevoir.html</b>.");
DEFINE('_JW_DESC_TRUNCATE_GOALS', "Nombre de caractères maximum de la table des Cibles.");
DEFINE('_JW_DESC_FRONTEND_NO_BACKLINK', "<b><i>(Version Pro uniquement)</i></b>&nbsp;&nbsp;Cochez pour désactiver le lien retour vers codegravity.com. Cependant, nous vous serions reconnaissants de le conserver !");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES', "Cochez pour afficher l'ensemble des statistiques pour les pays dans le module en Front-end. En cas de modification, cette option sera affichée sur le site après le temps spécifié dans 'Durée du cache pour les pays'.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FIRST', "Cochez pour afficher les pays avant les statistiques des visiteurs dans le module en Front-end.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NUM', "Nombre de pays maximum affichés  dans le module en Front-end.");
DEFINE('_JW_DESC_FRONTEND_VISITORS', "Cochez pour afficher les pays des visiteurs dans le module en Front-end. En cas de modification, cette option sera affichée sur le site après le temps spécifié dans 'Durée du cache pour les pays'.");
DEFINE('_JW_DESC_CACHE_FRONTEND_COUNTRIES', "Durée du cache, en secondes, pour les pays dans le module en Front-end.");
DEFINE('_JW_DESC_CACHE_FRONTEND_VISITORS', "Durée du cache, en secondes, pour les visiteurs dans le module en Front-end.");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TODAY', "Cochez pour afficher le nombre de visiteurs d'aujourd'hui dans le module en Front-end. En cas de modification, ce paramètre sera affiché en Front-end après le temps spécifié dans 'Durée du cache pour les visiteurs'.");
DEFINE('_JW_DESC_FRONTEND_VISITORS_YESTERDAY', "Cochez pour afficher le  nombre de visiteurs de la veille dans le module en Front-end. En cas de modification, ce paramètre sera affiché en Front-end après le temps spécifié dans 'Durée du cache pour les visiteurs'.");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_WEEK', "Cochez pour afficher le nombre de visiteurs de la semaine dans le module en Front-end. En cas de modification, ce paramètre sera affiché en Front-end après le temps spécifié dans 'Durée du cache pour les visiteurs'.");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_WEEK', "Cochez pour afficher le nombre de visiteurs de la semaine dernière dans le module en Front-end. En cas de modification, ce paramètre sera affiché en Front-end après le temps spécifié dans 'Durée du cache pour les visiteurs'.");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_MONTH', "Cochez pour afficher le nombre de visiteurs du mois en cours dans le module en Front-end. En cas de modification, ce paramètre sera affiché en Front-end après le temps spécifié dans 'Durée du cache pour les visiteurs'.");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_MONTH', "Cochez pour afficher le nombre de visiteurs du mois dernier dans le module en Front-end. En cas de modification, ce paramètre sera affiché en Front-end après le temps spécifié dans 'Durée du cache pour les visiteurs'.");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL', "Cochez pour afficher le nombre total de visiteurs depuis l'installation de JoomlaWatch dans le module en Front-end. En cas de modification, ce paramètre sera affiché en Front-end après le temps spécifié dans 'Durée du cache pour les visiteurs'.");
DEFINE('_JW_DESC_LANGUAGE', "Choisissez la langue de JoomlaWatch.");
DEFINE('_JW_DESC_GOALS', "Les cibles vous permettent de spécifier des paramètres spéciaux. Par exemple : vous pouvez contrôler si un visiteur a ouvert une URL spécifique, a affiché une valeur, a un identifiant ou provient d'une URL spécifiques. Vous avez également la possibilité de bloquer ou de rédiriger vers une autre URL ces utilisateurs.");
DEFINE('_JW_DESC_GOALS_INSERT', "Vous pouvez utiliser des jokers * et ? pour tous les champs, excepté celui du nom. Le joker * est utilisé pour remplacer une chaîne de caractères tandis que le joker ? n'est utilisé que pour un seul caractère.<br />Par exemple : p*r (va cibler : pr, pour, pair, etc...) et ?anger (va cibler : manger, ranger, etc...).");
DEFINE('_JW_DESC_GOALS_BLOCK', "Saisir 1 pour bloquer le visiteur. Il ne pourra accéder au contenu de la page et un message lui signalant qu'il a été bloqué s'affichera. Il n'y aura pas de redirection vers une autre URL et son adresse IP sera ajoutée à la liste des Adresses IP bloquées (dans l'onglet IP bloquées &amp; Anti-spam). Par exemple : <b>1</b>.");

/* new translations */
DEFINE('_JW_GOALS_COUNTRY_CONDITION', "Pays");
DEFINE('_JW_GOALS_CONTRY_INVERSED', "Condition inversée");
DEFINE('_JW_DESC_GOALS_COUNTRY_CONDITION', "Code du pays à 2 lettres en majuscules. Par exemple : <b>FR</b>. Si vous cochez 'Condition inversée', cela signifie : lorsque le pays n'est pas la valeur saisie.");
DEFINE('_JW_STATS_INTERNAL',"Liens internes (navigation)");
DEFINE('_JW_STATS_FROM',"De&nbsp;");
DEFINE('_JW_STATS_TO',"Vers&nbsp;");
DEFINE('_JW_STATS_ADD_TO_GOALS',"Ajouter cette URL comme cible");
DEFINE('_JW_VISITS_ADD_GOAL_COUNTRY',"Ajouter ce pays comme cible");
DEFINE('_JW_MENU_REPORT_BUG',"Signaler un bug ou soumettre une suggestion");
DEFINE('_JW_GOALS_COUNTRY',"Pays");

/* French translations 1.2.8b_12 */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_UPPERCASE',"Cochez pour afficher le nom des pays en majuscules dans le module en Front-end. Par exemple : FRANCE, UNITED KINGDOM au lieu de France, United Kingdom.");
DEFINE('_JW_DESC_CACHE_FRONTEND_USERS',"Durée du cache, en secondes, pour les statistiques des utilisateurs dans le module en Front-end.");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL_INITIAL', "Valeur de départ pour le nombre total de visiteurs dans le module en Front-end. Cette option sert lorsque vous migrez d'un autre utilitaire de statistiques vers JoomlaWatch tout en conservant le total du compteur de visiteurs (par exemple : 19650). Saisir 0 si vous ne voulez pas utiliser cette option.");
DEFINE('_JW_DESC_IGNORE_USER', "Entrez les identifiants des utilisateurs enregistrées du site que vous souhaitez ignorer dans les statistiques. Par exemple, en rentrant votre identifiant, l'intérêt est de ne pas fausser les statistiques lorsque vous surfez sur votre propre site. Vous devez saisir un identifiant par ligne (exemple : Marc {retour à la ligne} Paul.");
DEFINE('_JW_FRONTEND_USERS_MOST', "Utilisateurs les plus actifs aujourd'hui sur un total de ");
DEFINE('_JW_DESC_SPAMWORD_BANS_ENABLED',"Les mots figurant sur la liste ci-dessous seront bannis");
DEFINE('_JW_DESC_SPAMWORD_LIST',"Mots bannis les plus couramment utilisés par les bots des spammeurs. Vous pouvez utiliser des jokers * (par exemple : pharmac*). Lorsque cette option est activée, JoomlaWatch vérifiera si un formulaire de votre site est rempli avec ces mots bannis (requête HTTP POST). Cette option fonctionnera pour les formulaires prévus pour être utilisé dans Joomla! (par exemple : forum, commentaires) et devrait également permettre de bloquer les bots qui tenteraient d'envoyer un spam sur les autres types de formulaires de votre site.");
DEFINE('_JW_SETTINGS_ANTI_SPAM',"IP bloquées &amp; Anti-spam");
DEFINE('_JW_DESC_FRONTEND_USER_LINK',"URL qui sera ouverte lorsqu'un visiteur clique sur l'identifiant d'un utilisateur. L'expression {user} sera remplacée par l'identifiant de l'utilisateur dans l'URL. Par exemple : index.php?option=com_comprofiler&task=userProfile&user=<b>{user}</b>.");

/* translations 1.2.11b */
DEFINE('_JW_STATS_KEYPHRASE', "Expressions-clés");
DEFINE('_JW_DESC_HISTORY_MAX_VALUES', "Nombre de valeurs maximum dans l'onglet Historique.");

DEFINE('_JW_DESC_ONLY_LAST_URI', "Cochez pour n'afficher que la dernière page ouverte pour chaque visiteur dans l'onglet Visites &amp; Statistiques.");
DEFINE('_JW_DESC_HIDE_REPETITIVE_TITLE', "Cochez pour masquer le nom de domaine pour chaque page ouverte par les visiteurs dans l'onglet Visites &amp; Statistiques. Le nom de domaine est remplacé par /.");
DEFINE('_JW_DESC_HISTORY_MAX_DB_RECORDS', "Nombre de visiteurs maximum à conserver dans l'historique des visites de la base de données. Maniez cette valeur avec précaution ! En effet, si le site génère beaucoup de trafic, la taille de la base de données peut considérablement augmenter. Vérifiez régulièrement la taile de celle-ci dans l'onglet Base de données.");
DEFINE('_JW_DESC_UNINSTALL_KEEP_DATA', "Cochez pour conserver les tables de la base de données en cas de désinstallation de JoomlaWatch. Cette option est utile lors d'une mise à jour pour ne pas perdre tout l'historique.");

/* email reports */
DEFINE('_JW_DESC_EMAIL_REPORTS_ENABLED', "Activer la réception de rapports par e-mail. L'envoi des e-mails est nocturne, ainsi vous pourrez les lire au matin.");
DEFINE('_JW_DESC_EMAIL_REPORTS_ADDRESS', "Adresse e-mail à laquelle vous souhaitez recevoir les rapports.");
DEFINE('_JW_DESC_EMAIL_PERCENT_HIGHER_THAN', "N'inclure dans le rapport que les lignes dont le pourcentage est supérieur à la valeur saisie <i>(par exemple : 5)</i>. Saisir 0 si vous ne souhaitez pas inclure cette option dans le rapport.");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_POSITIVE', "N'inclure dans le rapport que les <b>évolutions positives sur 1 jour</b> dont le pourcentage est supérieur à la valeur saisie <i>(par exemple : 5)</i>. Saisir 0 si vous ne souhaitez pas inclure cette option dans le rapport.");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_NEGATIVE', "N'inclure dans le rapport que les <b>évolutions négatives sur 1 jour</b> dont le pourcentage est inférieur à la valeur saisie <i>(par exemple : -10)</i>. Saisir 0 si vous ne souhaitez pas inclure cette option dans le rapport.");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_POSITIVE', "N'inclure dans le rapport que les <b>évolutions positives sur 7 jours</b> dont le pourcentage est supérieur à la valeur saisie <i>(par exemple : 2)</i>. Saisir 0 si vous ne souhaitez pas inclure cette option dans le rapport.");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_NEGATIVE', "N'inclure dans le rapport que les <b>évolutions négatives sur 7 jours</b> dont le pourcentage est inférieur à la valeur saisie <i>(par exemple : -13)</i>. Saisir 0 si vous ne souhaitez pas inclure cette option dans le rapport.");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_POSITIVE', "N'inclure dans le rapport que les <b>évolutions positives sur 30 jours</b> dont le pourcentage est supérieur à la valeur saisie <i>(par exemple : 2)</i>. Saisir 0 si vous ne souhaitez pas inclure cette option dans le rapport.");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_NEGATIVE', "N'inclure dans le rapport que les <b>évolutions négatives sur 30 jours</b> dont le pourcentage est inférieur à la valeur saisie <i>(par exemple : -13)</i>. Saisir 0 si vous ne souhaitez pas inclure cette option dans le rapport.");
DEFINE('_JW_DESC_FRONTEND_NOFOLLOW', "<b><i>(Version Pro uniquement)</i></b>&nbsp;&nbsp;Cochez pour valider le lien du logo de JoomlaWatch avec l'attribut rel='nofollow'.");
DEFINE('_JW_DESC_EMAIL_NAME_TRUNCATE', "Nombre de caractères maximum pour la 1ère colonne du tableau du rapport par e-mail généré. Réduisez la valeur par défaut si la fenêtre de votre logiciel de messagerie est trop petite.");

DEFINE('_JW_MENU_HISTORY', "Historique");
DEFINE('_JW_MENU_EMAILS', "Rapports par e-mail");
DEFINE('_JW_MENU_STATUS', "Base de données");
DEFINE('_JW_DESC_BLOCKED',"IP bloquées par l'anti-spam");


DEFINE('_JW_HISTORY_VISITORS',"Historique des visiteurs");
DEFINE('_JW_HISTORY_SHOWING_ONLY', "Affichage des %d derniers enregistrements.<br />Pour changer cette valeur : allez dans l'onglet Réglages -&gt; Historique &amp; Performance -&gt; Nombre de visiteurs maximum.<br />Maniez cette valeur avec précaution ! En effet, ce réglage a une incidence sur le temps de chargement des données ci-dessous.");
DEFINE('_JW_MENU_BUG', "Signaler un bug");
DEFINE('_JW_MENU_FEATURE', "Faire une suggestion");

DEFINE('_JW_VISITS_CAME_FROM_KEYWORDS',"Mots-clés");

DEFINE('_JW_BLOCKING_UNBLOCK',"Débloquer");
DEFINE('_JW_STATS_KEYPHRASE ',"Expressions-clés");
DEFINE('_JW_STATUS_DATABASE',"Statistiques de la base de données");

DEFINE('_JW_STATUS_DATABASE_TABLE_NAME',"Nom des tables de JoomlaWatch");
DEFINE('_JW_STATUS_DATABASE_ROWS',"Lignes");
DEFINE('_JW_STATUS_DATABASE_DATA',"Taille");
DEFINE('_JW_STATUS_DATABASE_TOTAL',"TOTAL&nbsp;");

DEFINE('_JW_EMAIL_REPORTS',"Rapports par e-mail :");
DEFINE('_JW_EMAIL_REPORT_GENERATED',"Rapport par e-mail généré pour la veille");
DEFINE('_JW_EMAIL_REPORTS_VALUE_FILTERS',"Options du rapport&nbsp;");
DEFINE('_JW_EMAIL_REPORTS_VALUE',"Valeur");
DEFINE('_JW_EMAIL_REPORTS_PERCENT',"Pourcentage");
DEFINE('_JW_EMAIL_REPORTS_1DAY_CHANGE',"Évolution sur 1 jour");
DEFINE('_JW_EMAIL_REPORTS_7DAY_CHANGE',"Évolution sur 7 jours");
DEFINE('_JW_EMAIL_REPORTS_28DAY_CHANGE',"Évolution sur 30 jours");
DEFINE('_JW_ANTISPAM_BLOCKED',"JoomlaWatch a bloqué %d tentative(s) d'accès de spammeurs aujourd'hui. Total : %d");
DEFINE('_JW_ANTISPAM_ADDRESSES',"Adresses IP bloquées&nbsp;");
DEFINE('_JW_ANTISPAM_SETTINGS',"Réglages anti-spam :");
DEFINE('_JW_TRAFFIC_AJAX',"Flux du trafic mis à jour via AJAX");


DEFINE('_JW_HISTORY_PREVIOUS',"Précédent");
DEFINE('_JW_HISTORY_NEXT',"Suivant");

/** additional translation for 1.2.11 for countries in more rows */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_COLUMNS',"Nombre de colonnes maximum pour l'affichage des pays dans le module en Front-end.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_ROWS',"Nombre de lignes maximum pour l'affichage des pays dans le module en Front-end.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NAMES',"Cochez pour afficher le nom du pays dans le module en Front-end.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FLAGS_FIRST',"Cochez pour afficher le drapeau du pays avant le pourcentage dans le module en Front-end.");

/* JoomlaWatch 1.2.14 translations */

DEFINE('_JW_GOALS_GET_INVERSED', "Condition inversée");
DEFINE('_JW_GOALS_POST_INVERSED', "Condition inversée");
DEFINE('_JW_GOALS_TITLE_INVERSED', "Condition inversée");
DEFINE('_JW_GOALS_USERNAME_INVERSED', "Condition inversée");
DEFINE('_JW_GOALS_CAME_FROM_INVERSED', "Condition inversée");

DEFINE('_JW_STATS_MAP', "Géolocalisation du dernier visiteur");
DEFINE('_JW_STATS_MAP_ENTER_KEY',"Obtenez une clé sur le site <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a> pour activer la géolocalisation du dernier visiteur.");
DEFINE('_JW_STATS_MAP_STORE_KEY',"Sauver la clé");
DEFINE('_JW_STATS_MAP_INVALID_KEY',"Veuillez saisir la clé que vous avez obtenu sur le site <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a> pour activer la géolocalisation du dernier visiteur.");

DEFINE('_JW_SIZEQUERY_BAD_REQUEST',"Requête erronnée : ");

DEFINE('_JW_VISIT_SUBMITED_FIELDS',"Champs du formulaire de soumission");
DEFINE('_JW_VISIT_URL_PARAMETERS',"Paramètres de l'URL");
DEFINE('_JW_VISIT_ADD_PAGE'," Ajouter cette URL comme cible");
DEFINE('_JW_VISIT_BLOCK_IP'," Bloquer cette adresse IP");
DEFINE('_JW_VISIT_SUBMITED_FROM_VARIABLE'," Ajouter cette variable du formulaire comme cible");
DEFINE('_JW_VISIT_URL_PARAMETER_GOAL'," Ajouter ce paramètre comme cible");

DEFINE('_JW_TREND_EMPTY',"Aucune donnée");

DEFINE('_JW_NOT_NUMBER'," Attention ! La valeur que vous avez saisie n'est pas un nombre, JoomlaWatch ne fonctionnera pas correctement.");
DEFINE('_JW_EVALUATION_LEFT',"Version d'évaluation limitée à 15 jours. Nombre de jours restants : <b>%d</b>. Veuillez faire l'acquisition de la <a href='http://www.codegravity.com/donate/joomlawatch/' target='_blank'>licence de JoomlaWatch</a> pour votre nom de domaine et ainsi bénéficier de toutes les fonctions et mises à jour futures !");
DEFINE('_JW_TRIAL_VERSION_EXPIRED'," La version d'essai a expiré ! Veuillez faire l'acquisition de la <a href='http://www.codegravity.com/donate/joomlawatch/' target='_blank'>licence de JoomlaWatch</a> pour votre nom domaine et ainsi bénéficier de toutes les fonctions et mises à jour futures !");

DEFINE('_JW_CONFIG_LICENSE_ACTIVATED',"Licence activée avec succès ! Dorénavant, vous pourrez profiter de toutes les fonctions sans limite de temps.");
DEFINE('_JW_CONFIG_LICENCE_DONT_MATCH',"<b>Attention ! Le numéro de licence et votre nom de domaine ne correspondent pas.</b><br />Avez-vous saisi le même nom de domaine dans le formulaire de donation que celui ci-dessous ? En cas de problème, veuillez contacter : info@codegravity.com");

DEFINE('_JW_VIEW_ADMINBODY_LONG_MESSAGE',"Si vous voyez ce message s'afficher, c'est que le nom de domaine dans JoomlaWatch est incorrect !
                    Ouvrez le fichier components/com_joomlawatch/<b>config.php</b>
                    Effacez le #, puis entrez votre nom de domaine dans la variable.
                    Par exemple : define('JOOMLAWATCH_LIVE_SITE', 'http://www.codegravity.com');");

DEFINE('_JW_ADMINBODY_LIVE_SITE',"Attention ! Le nom de domaine dans votre navigateur (%s) et celui affiché dans JoomlaWatch (%s) ne correspondent pas.");
DEFINE('_JW_ADMINBODY_SET_LIVE_SITE',"Saisir le nom de domaine dans JoomlaWatch : %s puis continuer...");

DEFINE('_JW_ADMINHEADER_JW',"JoomlaWatch ");
DEFINE('_JW_ADMINHEADER_REMOVE_BACKLINK',"Masquer le lien retour");
DEFINE('_JW_ADMINHEADER_KNOWLEDGE_BASE',"Base de connaissances");
DEFINE('_JW_ADMINHEADER_FLOW',"Flux du trafic");
DEFINE('_JW_ADMINHEADER_GRAPHS',"Graphiques");
DEFINE('_JW_ADMINHEADER_COMPONENTS',"Composants &amp; Modules");
DEFINE('_JW_ADMINHEADER_REVIEW',"commentaire");
DEFINE('_JW_ADMINHEADER_WRITE'," et rédiger un ");

DEFINE('_JW_FLOW_TRAFFIC',"Flux du trafic");
DEFINE('_JW_FLOW_SELECT_PAGE',"Sélectionner une page :");
DEFINE('_JW_FLOW_OUTG_LINKS',"Nombre de liens sortants :");
DEFINE('_JW_FLOW_NESTING',"Niveau d'inclusion :");
DEFINE('_JW_FLOW_SCALE',"Pourcentage :");

DEFINE('_JW_COMERCIAL_AD_FREE',"Version Pro");
DEFINE('_JW_COMERCIAL_THANK_DONATION',"Merci pour votre don !");
DEFINE('_JW_COMERCIAL_REGISTRATION_KEY',"Le numéro de licence pour le site %s est : ");
DEFINE('_JW_COMERCIAL_BACKLINKS_REMOVE',"Dorénavant, vous pouvez désactiver dans la section Réglages le lien retour ou masquer le logo de JoomlaWatch dans le site.");

DEFINE('_JW_SIZES_LAST_CHECK',"Dernière mise à jour effectuée le :");
DEFINE('_JW_SIZES_ADMINISTRATOR',"En bleu : Taille du composant et taille du module dans le dossier /administrator");

DEFINE('_JW_SIZECOMPONENTS_COMPONENT',"Composants");
DEFINE('_JW_SIZECOMPONENTS_TOTAL',"TOTAL :");
DEFINE('_JW_SIZECOMPONENTS_SIZE',"Taille");
DEFINE('_JW_SIZECOMPONENTS_REFRESH_ALL',"Tout rafraîchir");

DEFINE('_JW_SIZEDATABASE_TABLE',"Nom de la table");
DEFINE('_JW_SIZEDATABASE_SIZE',"Taille");
DEFINE('_JW_SIZEDATABASE_1DAY',"Évolution sur 1 jour");
DEFINE('_JW_SIZEDATABASE_7DAY',"Évolution sur 7 jours");
DEFINE('_JW_SIZEDATABASE_28DAY',"Évolution sur 30 jours");
DEFINE('_JW_SIZEDATABASE_NO_DATA',"aucune donnée");
DEFINE('_JW_SIZEDATABASE_TOTAL',"TOTAL :");

DEFINE('_JW_SIZEMODULES_REFRESH_ALL',"Tout rafraîchir");
DEFINE('_JW_SIZEMODULES_TOTAL',"TOTAL :");
DEFINE('_JW_SIZEMODULES_MODULE',"Modules");
DEFINE('_JW_SIZEMODULES_SIZE',"Taille");

DEFINE('_JW_SIZES_FILES',"Taille des Composants &amp; Modules");
DEFINE('_JW_SIZES_BYTES',"octets");
DEFINE('_JW_SIZES_KB',"Ko");
DEFINE('_JW_SIZES_MB',"Mo");
DEFINE('_JW_SIZES_GB',"Go");
DEFINE('_JW_SIZES_REFRESH',"Rafraîchir");

DEFINE('_JW_STATS_FOOTER',"JoomlaWatch &copy; 2006-@YEAR@ par Matej Koval");

DEFINE('_JW_STATUS_MB',"Mo");

DEFINE('_JW_DESC_IPINFODB_KEY',"<b><i>(Version Pro uniquement)</i></b>&nbsp;&nbsp;Obtenez une clé sur le site <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a> pour activer la géolocalisation du dernier visiteur.");


/* JoomlaWatch 1.2.17 translations */
DEFINE('_JW_MENU_UPDATE', "Mise à jour");
DEFINE('_JW_MENU_UPDATE_TITLE', "Sauvegarde & Mise à jour");
DEFINE('_JW_ADMINHEADER_NA_IN_THIS_VERSION',"Indisponible pour la version gratuite, veuillez saisir le numéro d'enregistrement dans l'onglet 'Licence'");
DEFINE('_JW_SPAMWORD_BANS_ENABLED', "Activer le bannissement");
DEFINE('_JW_SPAMWORD_LIST', "Liste de mots bannis");
DEFINE('_JW_HIDE_REPETITIVE_TITLE', "Masquer le nom de domaine");
DEFINE('_JW_TRUNCATE_VISITS', "Visites");
DEFINE('_JW_TRUNCATE_STATS', "Statistiques");
DEFINE('_JW_TRUNCATE_GOALS', "Cibles");
DEFINE('_JW_LIMIT_BOTS', "Limite de bots");
DEFINE('_JW_LIMIT_VISITORS', "Limite de visiteurs");
DEFINE('_JW_TOOLTIP_WIDTH', "Largeur de la fenêtre");
DEFINE('_JW_TOOLTIP_HEIGHT', "Hauteur de la fenêtre");
DEFINE('_JW_TOOLTIP_URL', "Site de recherche de l'IP");
DEFINE('_JW_TOOLTIP_ONCLICK', "Cliquer pour afficher la fenêtre");
DEFINE('_JW_IP_STATS', "Statistiques des IP");
DEFINE('_JW_IPINFODB_KEY', "Clé de IP Info DB");
DEFINE('_JW_ONLY_LAST_URI', "Dernière page uniquement");
DEFINE('_JW_FRONTEND_HIDE_LOGO', "Masquer le logo ");
DEFINE('_JW_FRONTEND_NOFOLLOW', "Attribut nofollow");
DEFINE('_JW_FRONTEND_NO_BACKLINK', "Masquer le lien retour");
DEFINE('_JW_FRONTEND_USER_LINK', "URL vers l'utilisateur");
DEFINE('_JW_FRONTEND_COUNTRIES_FIRST', "Afficher les pays en premier");
DEFINE('_JW_FRONTEND_COUNTRIES_NAMES', "Afficher le nom des pays");
DEFINE('_JW_FRONTEND_COUNTRIES_UPPERCASE', "Afficher le nom des pays en majuscules");
DEFINE('_JW_FRONTEND_COUNTRIES_FLAGS_FIRST', "Afficher le drapeau des pays en premier");
DEFINE('_JW_FRONTEND_COUNTRIES_NUM', "Nombre de pays");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_COLUMNS', "Nombre de colonnes de pays");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_ROWS', "Nombre de lignes pour l'affichage");
DEFINE('_JW_FRONTEND_VISITORS_TODAY', "Afficher les visiteurs du jour");
DEFINE('_JW_FRONTEND_VISITORS_YESTERDAY', "Afficher le nombre de visiteurs de la veille");
DEFINE('_JW_FRONTEND_VISITORS_THIS_WEEK', "Afficher le nombre de visiteurs de la semaine");
DEFINE('_JW_FRONTEND_VISITORS_LAST_WEEK', "Afficher le nombre de visiteurs de la semaine dernière");
DEFINE('_JW_FRONTEND_VISITORS_THIS_MONTH', "Afficher le nombre de visiteurs du mois");
DEFINE('_JW_FRONTEND_VISITORS_LAST_MONTH', "Afficher le nombre de visiteurs du mois dernier");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL', "Afficher le nombre total de visiteurs");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL', "Nombre de visiteurs initial");
DEFINE('_JW_HISTORY_MAX_VALUES', "Nombre de valeurs maximum");
DEFINE('_JW_HISTORY_MAX_DB_RECORDS', "Nombre de visiteurs maximum");
DEFINE('_JW_UPDATE_TIME_VISITS', "Temps de rafraîchissement des visiteurs");
DEFINE('_JW_UPDATE_TIME_STATS', "Temps de rafraîchissement des statistiques");
DEFINE('_JW_STATS_MAX_ROWS', "Nombre de lignes maximum");
DEFINE('_JW_STATS_IP_HITS', "Nombre de hits minimum par IP");
DEFINE('_JW_MAXID_BOTS', "Nombre de visites de bots");
DEFINE('_JW_MAXID_VISITORS', "Nombre de visiteurs uniques");
DEFINE('_JW_STATS_KEEP_DAYS', "Durée de conservation des statistiques");
DEFINE('_JW_CACHE_FRONTEND_COUNTRIES', "Durée du cache pour les pays");
DEFINE('_JW_CACHE_FRONTEND_VISITORS', "Durée du cache pour les visiteurs");
DEFINE('_JW_CACHE_FRONTEND_USERS', "Durée du cache pour les statistiques");
DEFINE('_JW_UNINSTALL_KEEP_DATA', "Conserver les tables");
DEFINE('_JW_IGNORE_IP', "Ignorer les IP");
DEFINE('_JW_IGNORE_URI', "Ignorer les URI");
DEFINE('_JW_IGNORE_USER', "Ignorer les utilisateurs");
DEFINE('_JW_BLOCKING_MESSAGE', "Message");
DEFINE('_JW_SERVER_URI_KEY', "Clé de l'URI du serveur");
DEFINE('_JW_SIZEDATABASE_RECORDS', "Nombre d'enregistrements");

/***********EDITs******************/
DEFINE('_JW_ANTISPAM_BLOCKING_TEXT',"Afin que le blocage soit effectif, vous devez publier l'agent de JoomlaWatch AVANT quelque contenu ou formulaire que ce soit.<br />Par exemple : à gauche dans le template.<br />Gestion des modules -> JoomlaWatch agent -> Position : left");
DEFINE('_JW_EMAIL_SEO_REPORTS', "Rapports SEO");
DEFINE('_JW_DESC_EMAIL_SEO_REPORTS_ENABLED',"Activer la réception de rapports SEO par e-mail. L'envoi des e-mails est nocturne, ainsi vous pourrez les lire au matin.");
DEFINE('_JW_WATCH_INSTALLATION_DEMO',"Regarder la démonstration de l'installation");
DEFINE('_LANGUAGE', "Langue");
?>