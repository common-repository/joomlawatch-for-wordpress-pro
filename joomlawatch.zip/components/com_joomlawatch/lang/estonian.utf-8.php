<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version @VERSION@
 * @revision @REVISION@
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) @YEAR@ by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/
defined( '_JEXEC' ) or die( 'Restricted access' );

#JoomlaWatch: Estonian language - Eesti keel

# Main Menu
DEFINE('_JW_MENU_STATS', "Live statistika");
DEFINE('_JW_MENU_GOALS', "Eesmärgid");
DEFINE('_JW_MENU_SETTINGS', "Seaded");
DEFINE('_JW_MENU_CREDITS', "Autorid");
DEFINE('_JW_MENU_FAQ', "KKK");
DEFINE('_JW_MENU_DOCUMENTATION', "Dokumentatsioon");
DEFINE('_JW_MENU_LICENSE', "Litsents");
DEFINE('_JW_MENU_DONATORS', "Toetajad");
DEFINE('_JW_MENU_SUPPORT', "Toeta JoomlaWatch'i ja sa saad oma reklaamid eemaldada administraatori lehel.");

# Left visitors real-time window
DEFINE('_JW_VISITS_VISITORS', "Viimased külastajad");
DEFINE('_JW_VISITS_BOTS', "Robotid");
DEFINE('_JW_VISITS_CAME_FROM', "Tuli");
DEFINE('_JW_VISITS_MODULE_NOT_PUBLISHED', "Sinu JoomlaWatch moodul ei ole avaldatud! Uusi andmeid ei salvestata, et seda avaldada, mine Moodulite sektsiooni ja avalda see kõikidel lehtedel");
DEFINE('_JW_VISITS_PANE_LOADING', "Laen külastusi...");

# Right stats window
DEFINE('_JW_STATS_TITLE', "Nädala külastuste statistika");
DEFINE('_JW_STATS_WEEK', "Nädal");
DEFINE('_JW_STATS_THIS_WEEK', "sel nädalal");
DEFINE('_JW_STATS_UNIQUE', "unikaalne");
DEFINE('_JW_STATS_LOADS', "laadimist");
DEFINE('_JW_STATS_HITS', "tabamust");
DEFINE('_JW_STATS_TODAY', "täna");
DEFINE('_JW_STATS_FOR', "");
DEFINE('_JW_STATS_ALL_TIME', "Kokku");
DEFINE('_JW_STATS_EXPAND', "Laienda");
DEFINE('_JW_STATS_COLLAPSE', "Ahenda");
DEFINE('_JW_STATS_URI', "lehed");
DEFINE('_JW_STATS_COUNTRY', "Riigid");
DEFINE('_JW_STATS_USERS', "kasutajad");
DEFINE('_JW_STATS_REFERERS', "linkijad");
DEFINE('_JW_STATS_IP', "IPd");
DEFINE('_JW_STATS_BROWSER', "brauserid");
DEFINE('_JW_STATS_OS', "OS");
DEFINE('_JW_STATS_KEYWORDS', "märksõnad");
DEFINE('_JW_STATS_GOALS', "Eesmärgid");
DEFINE('_JW_STATS_TOTAL', "Kokku");
DEFINE('_JW_STATS_DAILY', "Täna");
DEFINE('_JW_STATS_DAILY_TITLE', "Päeva statistika");
DEFINE('_JW_STATS_ALL_TIME_TITLE', "Kogu statistika");
DEFINE('_JW_STATS_LOADING', "laadimine...");
DEFINE('_JW_STATS_LOADING_WAIT', "laadimine... palun oota");
DEFINE('_JW_STATS_IP_BLOCKING_TITLE', "IP blokeerimine");
DEFINE('_JW_STATS_IP_BLOCKING_ENTER', "Sisesta IP käsitsi");
DEFINE('_JW_STATS_IP_BLOCKING_MANUALLY', "Sisesta IP aadress, mida soovid blokeerida. (nt 217.242.11.54 või 217.* või 217.242.*, et blokeerida kõik IPd, mis sobivad nende märkidega)");
DEFINE('_JW_STATS_IP_BLOCKING_TOGGLE', "Blokeeri järgmine IP: ");
DEFINE('_JW_STATS_PANE_LOADING', "Laen andmeid...");

# Settings
DEFINE('_JW_SETTINGS_TITLE', "Seaded");
DEFINE('_JW_SETTINGS_DEFAULT', "Vaikeseaded");
DEFINE('_JW_SETTINGS_SAVE', "Salvesta");
DEFINE('_JW_SETTINGS_APPEARANCE', "Välimus");
DEFINE('_JW_SETTINGS_FRONTEND', "Esileht");
DEFINE('_JW_SETTINGS_HISTORY_PERFORMANCE', "Ajalugu &amp; jõudlus");
DEFINE('_JW_SETTINGS_ADVANCED', "Täpsemalt");
DEFINE('_JW_SETTINGS_IGNORE', "Eira");
DEFINE('_JW_SETTINGS_BLOCKING', "Blokeerimine");
DEFINE('_JW_SETTINGS_EXPERT', "Ekspert");
DEFINE('_JW_SETTINGS_RESET_CONFIRM', "Kas sa tõesti soovid nullida kogu statistika ja külastajate andmed?");
DEFINE('_JW_SETTINGS_RESET_ALL', "Taasta kõik");
DEFINE('_JW_SETTINGS_RESET_ALL_LINK', "Nulli kogu statistika &amp; külastajate andmed");
DEFINE('_JW_SETTINGS_LANGUAGE', "Keel");
DEFINE('_JW_SETTINGS_SAVED', "Seaded on salvestatud");
DEFINE('_JW_SETTINGS_ADD_YOUR_IP', "Lisa oma IP");
DEFINE('_JW_SETTINGS_TO_THE_LIST', "nimekirja.");

# Other / mostly general
DEFINE('_JW_TITLE', "Reaalajas AJAX Joomla jälgija");
DEFINE('_JW_BACK', "Tagasi");
DEFINE('_JW_ACCESS_DENIED', "Sul ei ole õigusi selle lehe vaatamiseks!");
DEFINE('_JW_LICENSE_AGREE', "Nõustun tingimustega, mis on eespool");
DEFINE('_JW_LICENSE_CONTINUE', "Jätka");
DEFINE('_JW_SUCCESS', "Toiming oli edukas");
DEFINE('_JW_RESET_SUCCESS', "Kogu statistika ja külastajate andmed kustutati edukalt");
DEFINE('_JW_RESET_ERROR', "Andmed EI kustutatud edukalt, midagi läks viltu");
DEFINE('_JW_CREDITS_TITLE', "Autorid");
DEFINE('_JW_TRENDS_DAILY_WEEKLY', "Igapäeva ja iganädala statistika");
DEFINE('_JW_AJAX_PERMISSION_DENIED_1', "AJAX juurdepääs keelatud: Palun vaata seda statistikat domeenist, mis on nimetatud configuration.php joomla failis - ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_2', "Võibolla sa lihtsalt unustasid www. oma domeeni nime ette panemast. Teie javascript püüab kasutada ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_3', "");
DEFINE('_JW_AJAX_PERMISSION_DENIED_4', "Mis teeb seda arvama, et see on erinev domeen.");

# Header
DEFINE('_JW_HEADER_DOWNLOAD', "Hangi pikendus kood");
DEFINE('_JW_HEADER_CAST_YOUR', "Sisesta oma");
DEFINE('_JW_HEADER_VOTE', "hääl");

# Tooltips
DEFINE('_JW_TOOLTIP_CLICK', "Vajuta, et näha kohtspikrit");
DEFINE('_JW_TOOLTIP_MOUSE_OVER', "Hõlju hiirega üle, et näha kohtspikrit");
DEFINE('_JW_TOOLTIP_YESTERDAY_INCREASE', "eilne kasv");
DEFINE('_JW_TOOLTIP_HELP', "Avab online välise abi");
DEFINE('_JW_TOOLTIP_WINDOW_CLOSE', "Sulge see aken");
DEFINE('_JW_TOOLTIP_PRINT', "Prindi");

# Goals
DEFINE('_JW_GOALS_INSERT', "Sisesta uus eesmärk");
DEFINE('_JW_GOALS_UPDATE', "Update eesmärki nr");
DEFINE('_JW_GOALS_ACTION', "Toiming");
DEFINE('_JW_GOALS_TITLE', "Uus eesmärk");
DEFINE('_JW_GOALS_NEW', "Uus eesmärk");
DEFINE('_JW_GOALS_RELOAD', "Värskenda");
DEFINE('_JW_GOALS_ADVANCED', "Täpsem");
DEFINE('_JW_GOALS_NAME', "Nimi");
DEFINE('_JW_GOALS_ID', "ID");
DEFINE('_JW_GOALS_URI_CONDITION', "URI tingimus");
DEFINE('_JW_GOALS_URI_INVERSED', "URI ümberpööramis tingimus");
DEFINE('_JW_GOALS_GET_VAR', "GET var");
DEFINE('_JW_GOALS_GET_CONDITION', "GET tingimus");
DEFINE('_JW_GOALS_POST_VAR', "POST Var");
DEFINE('_JW_GOALS_POST_CONDITION', "POST tingimus");
DEFINE('_JW_GOALS_TITLE_CONDITION', "Pealkirja tingimus");
DEFINE('_JW_GOALS_USERNAME_CONDITION', "Kasutaja tingimus");
DEFINE('_JW_GOALS_IP_CONDITION', "IP tingimus");
DEFINE('_JW_GOALS_IP_INVERSED', "IP ümberpööramis tingimus");
DEFINE('_JW_GOALS_CAME_FROM_CONDITION', "Tuli tingimus");
DEFINE('_JW_GOALS_BLOCK', "Blokeeri");
DEFINE('_JW_GOALS_REDIRECT', "Suuna ümber URLile");
DEFINE('_JW_GOALS_HITS', "Tabamused");
DEFINE('_JW_GOALS_ENABLED', "Sees");
DEFINE('_JW_GOALS_EDIT', "Muuda");
DEFINE('_JW_GOALS_DELETE', "Kustuta");
DEFINE('_JW_GOALS_DELETE_CONFIRM', "Sa kaotad selle eesmärgi kõik hiljutised statistika andmed. Kas sa tõesti soovid kustutada eesmärki nr ");

# Frontend
DEFINE('_JW_FRONTEND_COUNTRIES', "Riigid");
DEFINE('_JW_FRONTEND_VISITORS', "Külastajad");
DEFINE('_JW_FRONTEND_TODAY', "Täna");
DEFINE('_JW_FRONTEND_YESTERDAY', "Eile");
DEFINE('_JW_FRONTEND_THIS_WEEK', "See nädal");
DEFINE('_JW_FRONTEND_LAST_WEEK', "Eelmine nädal");
DEFINE('_JW_FRONTEND_THIS_MONTH', "See kuu");
DEFINE('_JW_FRONTEND_LAST_MONTH', "Eelmine kuu");
DEFINE('_JW_FRONTEND_TOTAL', "Kokku");

# Settings description - quite long
DEFINE('_JW_DESC_DEBUG', "JoomlaWatch on silumis režiimis. Sel moel saab leida vigade põhjuseid. Et see välja lülitada, palun muuda JOOMLAWATCH_DEBUG /components/com_joomlawatch/config.php väärtust. Muuda 1 tagasi 0");
DEFINE('_JW_DESC_STATS_MAX_ROWS', "Max rida, mida näidatakse, kui statistika on laiendatud režiimis.");
DEFINE('_JW_DESC_STATS_IP_HITS', "Kõikidel IP aadressidel, millel on vähem tabamusi eelmistel päevadel, kui sellel väärtusel siis kustutatakse see IP ajaloost.");
DEFINE('_JW_DESC_STATS_URL_HITS', "Kõikidel URL-idel aadressidel, millel on vähem tabamusi eelmistel päevadel, kui sellel väärtusel siis kustutatakse see IP ajaloost.");
DEFINE('_JW_DESC_IGNORE_IP', "Välista teatud IP aadressid statistikast. Eralda uue reaga. Võid kasutada ka metamärke siin. <br/>Nt. 192.* ignoreerib 192.168.51.31, 192.168.16.2, jne.");
DEFINE('_JW_DESC_UPDATE_TIME_VISITS', "Külastajate värskendamis aeg millisekundites, vaikeseade on 2000, ole sellega ettevaatlik. Siis lae uuesti JoomlaWatch administraatori lehte.");
DEFINE('_JW_DESC_UPDATE_TIME_STATS', "Statistika värskendamis aeg millisekundites, vaikeseade on 4000, ole sellega ettevaatlik. Siis lae uuesti JoomlaWatch administraatori lehte.");
DEFINE('_JW_DESC_MAXID_BOTS', "Mitu roboti külastust hoitakse andmebaasis.");
DEFINE('_JW_DESC_MAXID_VISITORS', "Mitu päris külastajat hoitakse andmebaasis.");
DEFINE('_JW_DESC_LIMIT_BOTS', "Mitu roboti sa näed administraatori lehel.");
DEFINE('_JW_DESC_LIMIT_VISITORS', "Kui palju päris külastajaid sa näed administraatori lehel.");
DEFINE('_JW_DESC_TRUNCATE_VISITS', "Maksimaalne tähemärkide arv, mida näidatakse pikemates pealkirjades ja linkides.");
DEFINE('_JW_DESC_TRUNCATE_STATS', "Maksimaalne tähemärkide arv, mida näidatakse paremal olevas statistika paneelis.");
DEFINE('_JW_DESC_STATS_KEEP_DAYS', "Mitu päeva hoitakse statistikat andmebaasis, 0 = lõpmatu.");
DEFINE('_JW_DESC_TIMEZONE_OFFSET', "Kui oled erinevas ajav&ouml;&ouml;ndis, kui oma server. (positiivne või negatiivne väärtus tunnis)");
DEFINE('_JW_DESC_WEEK_OFFSET', "Nädala nihe, ajatempel/(3600*24*7) annab nädala numbri alates 1.1.1970, see nihe on parandus, mis paneb seda alustama esmaspäevast ");
DEFINE('_JW_DESC_DAY_OFFSET', "Päeva nihe, ajatempel/(3600*24) annab päeva numbri alates 1.1.1970, see nihe on parandus, mis paneb seda alustama kell 00:00 ");
DEFINE('_JW_DESC_FRONTEND_HIDE_LOGO', "<b>(funktsionaalne reklaami-vaba versioonis)</b> Kasutatakse 1x1px ikooni esilehel");
DEFINE('_JW_DESC_IP_STATS', "Selleks, et lülitada sisse IP-aadressi statistikat. Mõnes riigis IP andmebaasi hoidmine pikemat aega on keelatud seadusega. Kasuta omal vastutusel.");
DEFINE('_JW_DESC_HIDE_ADS', "See seade peidab reklaami administraatori lehel, kui see tõesti sind tüütab. Hoides neid, te toetate selle t&ouml;&ouml;riista edasiarendamist. Tänan teid");
DEFINE('_JW_DESC_TOOLTIP_ONCLICK', "Eemalda, kui soovid kuvada kohtspikrit hiire üle minnes, hiireklõpsuga avamise asemel.");
DEFINE('_JW_DESC_SERVER_URI_KEY', "Vaikeseade on 'REDIRECT_URL', mis on standard, kui sa kasutad URL ümberkirjutamist, saab seada ka 'SCRIPT_URL' kui see logib ainult index.php");
DEFINE('_JW_DESC_BLOCKING_MESSAGE', "Sõnum, mida näidatakse blokeeritud kasutajale või täiendavat teavet, miks sa blokeerid neid kasutajaid.");
DEFINE('_JW_DESC_TOOLTIP_WIDTH', "Kohtspikri laius");
DEFINE('_JW_DESC_TOOLTIP_HEIGHT', "Kohtspikri kõrgus");
DEFINE('_JW_DESC_TOOLTIP_URL', "Sa võid panna siia ükskõik millise URLi, et visualiseerida külastaja IPd. {ip} asendatakse külastaja IPga. Nt. http://somewebsite.com/query?iplookup={ip}");
DEFINE('_JW_DESC_IGNORE_URI', "Siia võid kirjutada IP aadressid, mida eiratakse statistikas. Võid kasutada ka metamärke (* ja ?). Nt.: /freel?n* ");
DEFINE('_JW_DESC_GOALS_NAME', "Täpsusta eesmärgi nimi. Seda nime näed statistikas.");
DEFINE('_JW_DESC_GOALS_URI_CONDITION', "Kõik, mis on pärast sinu domeeninime. http://www.codegravity.com/projects/ URLi jaoks on /projects/ (Kasutammis näide: <b>/projects*</b>)");
DEFINE('_JW_DESC_GOALS_GET_VAR', "GET muutuja on muutuja, mida näed URLis tavaliselt pärast ? või &amp; märki. Nt. http://www.codegravity.com/index.php?<u>name</u>=peter&amp;<u>surname</u>=smith. Sa võid ka kasutada <u>*</u> selles väljas, et kontrollida kõiki GET väärtusi. (Kasutammis näide: <b>n*me</b>)");
DEFINE('_JW_DESC_GOALS_GET_CONDITION', "Siin tuleb sul määrata vaste eelmise välja väärtusele. (Kasutammis näide: <b>p?t*r</b>) ");
DEFINE('_JW_DESC_GOALS_POST_VAR', "üsna sarnane, kuid me kontrollimine väärtusi, mis on esitatud vormist. Nii, et kui sul on vorm oma veebilehel, millel on väli &lt;input type='text' name='<u>experiences</u>' /&gt;. (Kasutammis näide: <b>exper*ces</b>)");
DEFINE('_JW_DESC_GOALS_POST_CONDITION', "Vaste väärtus sellest POST väljast. Nt. me tahame kontrollida, kas kasutajatel on java kogemusi. (Kasutammis näide: <b>*java*</b>)");
DEFINE('_JW_DESC_GOALS_TITLE_CONDITION', "Lehe pealkiri, mis peab sobima. (Kasutammis näide: <b>*freelance programmers*</b>)");
DEFINE('_JW_DESC_GOALS_USERNAME_CONDITION', "Sisseloginud kasutaja nimi. (Kasutammis näide: <b>psmith*</b>)");
DEFINE('_JW_DESC_GOALS_IP_CONDITION', "IP kust kasutaja tuleb: (Kasutammis näide: <b>201.9?.*.*</b>)");
DEFINE('_JW_DESC_GOALS_CAME_FROM_CONDITION', "URL kust kasutaja tuleb. (Kasutammis näide: <b>*www.google.*</b>)");
DEFINE('_JW_DESC_GOALS_REDIRECT', "Kasutaja suunatakse URLile, mille oled määranud. Sellel on suurem prioriteet, kui 'blocking': (Kasutammis näide: <b>http://www.codegravity.com/goaway.html</b>)");
DEFINE('_JW_DESC_TRUNCATE_GOALS', "Mitu tähemärki kärbitakse eesmärkide tabelis");
DEFINE('_JW_DESC_FRONTEND_NO_BACKLINK', "<b>(funktsionaalne reklaami-vaba versioonis)</b> codegravity.com link, võid selle välja lülitada, kuid me oleme tänulik kui see on seal. Tänan teid");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES', "Näita riikide statistikat esilehel olevas moodulis. Kui muudetud, see funktsioon hakkab esilehel t&ouml;&ouml;le pärast tähtaega, mis on sätestatud CACHE_FRONTEND_ ");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FIRST', "Kui sa soovid vahetada külastajate/riikide järjekorda esilehel. Eemalda see valik ja Külastajad ilmuvad esimesena.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NUM', "Mitu riiki näidatakse esilehel.");
DEFINE('_JW_DESC_FRONTEND_VISITORS', "Näita riikide külastajaid esilehel olevas moodulis. Kui muudetud, see funktsioon hakkab esilehel t&ouml;&ouml;le pärast tähtaega, mis on sätestatud in CACHE_FRONTEND_");
DEFINE('_JW_DESC_CACHE_FRONTEND_COUNTRIES', "Aeg sekundites, kuni vahemälu võetakse esilehel olevatel riikidel");
DEFINE('_JW_DESC_CACHE_FRONTEND_VISITORS', "Aeg sekundites, kuni vahemälu võetakse esilehel olevatel külastajatel");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TODAY', "Selleks, et näidata külastajaid esilehel: täna. Kui muudetud, see funktsioon hakkab esilehel t&ouml;&ouml;le pärast tähtaega, mis on sätestatud CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_YESTERDAY', "Selleks, et näidata külastajaid esilehel: eile. Kui muudetud, see funktsioon hakkab esilehel t&ouml;&ouml;le pärast tähtaega, mis on sätestatud CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_WEEK', "Selleks, et näidata külastajaid esilehel: sellel nädalal. Kui muudetud, see funktsioon hakkab esilehel t&ouml;&ouml;le pärast tähtaega, mis on sätestatud CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_WEEK', "Selleks, et näidata külastajaid esilehel: eelmisel nädalal. Kui muudetud, see funktsioon hakkab esilehel t&ouml;&ouml;le pärast tähtaega, mis on sätestatud CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_MONTH', "Selleks, et näidata külastajaid esilehel: sellel kuul. Kui muudetud, see funktsioon hakkab esilehel t&ouml;&ouml;le pärast tähtaega, mis on sätestatud CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_MONTH', "Selleks, et näidata külastajaid esilehel: eelmisel kuul. Kui muudetud, see funktsioon hakkab esilehel t&ouml;&ouml;le pärast tähtaega, mis on sätestatud CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL', "Selleks, et näidata külastajate koguarvu alates JoomlaWatch'i paigaldamisest. Kui muudetud, see funktsioon hakkab esilehel t&ouml;&ouml;le pärast tähtaega, mis on sätestatud CACHE_FRONTEND_...");
DEFINE('_JW_DESC_LANGUAGE', "Kasutatav keelefail. Nad on paigutatud /components/com_joomlawatch/lang/. Kui soovid luua täiesti uut keele fail, kontrollige kõigepealt projekti kodulehte, ja kui keele fail ei ole ikka veel olemas, kopeeri vaike keele fail english.php ja muuda see nt german.php ja pane see sinna kataloogi. Siis, tõlki kõik failis olevad olulisemad väärtused.");
DEFINE('_JW_DESC_GOALS', "Eesmärkidega saad määrata eri parameetreid. Kui need parameetrid langevad kokku, eesmärgi loendur suureneb. Nii saad jälgida, kas kasutaja on külastanud konkreetset URLi, postitanud konkreetse väärtuse, on eriline kasutajanime või tuli konkreetselt aadressilt. SA saad ka blokeerida või suunata selliseid kasutajaid mõnele teisele URLile.");
DEFINE('_JW_DESC_GOALS_INSERT', "Kõikides valdkondades, välja arvatud nimi saad kasutada * ja ? metamärke. Nagu näiteks: ?ear (sobib kokku: near, tear, ...),  p*r (sobib kokku: pr, peer, pear ...) ");
DEFINE('_JW_DESC_GOALS_BLOCK', "Määra väärtuseks 1 kui sa soovid kasutajaid blokeerida. Ta ei näe ülejäänud sisu, ainult sõnumi, et ta on blokeeritud - ilma ümbersuunamiseta ja tema IP on lisatud 'blokeeritud' statistikasse (Kasutammis näide: <b>1</b>)");

/* new translations */
DEFINE('_JW_GOALS_COUNTRY_CONDITION', "Riigi olukord");
DEFINE('_JW_GOALS_CONTRY_INVERSED', "Riigi ümberpööramis tingimus");
DEFINE('_JW_DESC_GOALS_COUNTRY_CONDITION', "2-täheline riigi kood suurtes tähtedes (nt: <b>EE</b>)");
DEFINE('_JW_STATS_INTERNAL',"Sisemine");
DEFINE('_JW_STATS_FROM',"Kust");
DEFINE('_JW_STATS_TO',"Kuhu");
DEFINE('_JW_STATS_ADD_TO_GOALS',"Lisa eesmärkide hulka");
DEFINE('_JW_VISITS_ADD_GOAL_COUNTRY',"Lisa eesmärk sellele riigile");
DEFINE('_JW_MENU_REPORT_BUG',"Teata veast või funktsioonist");
DEFINE('_JW_GOALS_COUNTRY',"Riik");


/* translations 1.2.8b_12 */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_UPPERCASE',"Kui soovid esilehel riigi nimesid suurtes tähtedes (Nt: SAKSAMAA ja SUURBRITANNIA. Saksamaa ja Suurbritannia asemel.)");
DEFINE('_JW_DESC_CACHE_FRONTEND_USERS',"Aeg sekundites, kuni vahemälu võetakse esilehel olevatel kasutajatelt");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL_INITIAL', "Esialgne väärtus, mida näidatakse kokku: esilehel. Kasulik, kui sa migreerud teise statistika komponenti. (Nt.: 20000). Muuda väärtus tagasi 0 kui sa ei soovi seda funktsiooni kasutada.");
DEFINE('_JW_DESC_IGNORE_USER', "Eira kasutajad, kes on loetletud selles tekstikastis, üks rea kohta. (Nt: Mina {line break} mark_*) ");
DEFINE('_JW_FRONTEND_USERS_MOST', "Kõige aktiivsemad kasutajad täna");
DEFINE('_JW_DESC_SPAMWORD_BANS_ENABLED',"Luba keelud, mis põhineb allpool olevatest spämmi sõnadest? ?");
DEFINE('_JW_DESC_SPAMWORD_LIST',"Kõige levinumad rämpsposti sõnad, mida kasutavad spämmi robotid. Võid kasutada ka metamärke siin, (Nt.: ph?rmac*). Kui see seade on sisse lülitatud, JoomlaWatch kontrollib, kas ründaja sisestas välja (HTTP POST-taotluse) sinu veebilehel, mis sisaldavad neid spämmi sõnu. (Rakendub juhul kui vorm laeb Joomla baasil olevas veebilehel ainult - foorum, kommentaarid, kuid see on üsna tõhus viis blokeerimaks spämmi roboteid, mis püüavad sisestada igat võimaliku vormi.)");
DEFINE('_JW_SETTINGS_ANTI_SPAM',"Rämpspostitõrje");
DEFINE('_JW_DESC_FRONTEND_USER_LINK',"Link esilehel olevas Kasutaja moodulis - võimaldab määrata URLi, mis avaneb, kui kasutaja klõpsab kasutaja nimi. Peab sisaldama stringi {user}, mis asendatakse tegeliku kasutaja nimega. (Nt. index.php?option=com_comprofiler&task=userProfile&user={user}) ");

/* translations 1.2.11b */
DEFINE('_JW_STATS_KEYPHRASE', "võtmelaused");
DEFINE('_JW_DESC_HISTORY_MAX_VALUES', "Maksimumväärtus ajaloo vahelehel (Näide: <i>100</i>)");

DEFINE('_JW_DESC_ONLY_LAST_URI', "Külastuses näita ainult viimast külastatud lehte, mitte kõiki");
DEFINE('_JW_DESC_HIDE_REPETITIVE_TITLE', "Külastustes peida korduvad lehenimed, külastatud lehe pealkirjas");
DEFINE('_JW_DESC_HISTORY_MAX_DB_RECORDS', "Maksimum number külastajaid, mida hoitakse külastajate ajaloo andmebaasis. Ole selle seadega ettevaatlik, kui teil on kõrge liiklus siis võib see kasvada väga kiiresti. Kontrolli alati, kui palju andmeid ajaloo statistika tabelis on");
DEFINE('_JW_DESC_UNINSTALL_KEEP_DATA', "Hoia andmebaasi tabelid komponendi eemaldamisel. Märgi see valik, enne eemaldamist, kui sa teostad versiooniuuendust ja soovid oma andmeid hoida.");

/* email reports */
DEFINE('_JW_DESC_EMAIL_REPORTS_ENABLED', "Sa saad &ouml;&ouml;sel e-posti aruandeid eelmise päeva kohta, mida sa võid hommikul lugeda");
DEFINE('_JW_DESC_EMAIL_REPORTS_ADDRESS', "E-posti aadress, kuhu saadetakse need aruanded");
DEFINE('_JW_DESC_EMAIL_PERCENT_HIGHER_THAN', "Ainult lisa read e-posti aruandes, kus see protsent on kõrgem kui {value}. Määra see 0 kui sa ei soovi seda funktsiooni kasutada <i>(näide: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_POSITIVE', "Ainult kaasa <b>positiivne üks päev</b> muuda väärtus e-maili aruandesse, mis on suurem kui {value} protsent. Määra väärtuseks 0, kui sa ei soovi seda funktsiooni kasutada <i>(näide: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_NEGATIVE', "Ainult kaasa <b>negatiivne üks päev</b> muuda väärtus e-maili aruandesse, mis on madalam kui {value} protsent. Määra väärtuseks 0, kui sa ei soovi seda funktsiooni kasutada <i>(näide: -10)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_POSITIVE', "Ainult kaasa <b>positiivne seitse päeva</b> muuda väärtus e-maili aruandesse, mis on suurem kui {value} protsent. Määra väärtuseks 0, kui sa ei soovi seda funktsiooni kasutada <i>(näide: 2)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_NEGATIVE', "Ainult kaasa <b>negatiivne seitse päeva</b> muuda väärtus e-maili aruandesse, mis on madalam kui {value} protsent. Määra väärtuseks 0, kui sa ei soovi seda funktsiooni kasutada <i>(näide: -13)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_POSITIVE', "Ainult kaasa <b>positiivne kolmkümmend päeva</b> muuda väärtus e-maili aruandesse, mis on suurem kui {value} protsent. Määra väärtuseks 0, kui sa ei soovi seda funktsiooni kasutada <i>(näide: 2)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_NEGATIVE', "Ainult kaasa <b>negatiivne kolmkümmend päeva</b> muuda väärtus e-maili aruandesse, mis on madalam kui {value} protsent. Määra väärtuseks 0, kui sa ei soovi seda funktsiooni kasutada <i>(näide: -13)</i>");

DEFINE('_JW_DESC_FRONTEND_NOFOLLOW', "<b>(funktsionaalne reklaami-vaba versioonis)</b> Lülita sisse see seade, kui soovid muuta logo lingi atribuuti rel='nofollow' ");
DEFINE('_JW_DESC_EMAIL_NAME_TRUNCATE', "Maksimaalne tähemärkide arv e-posti rea nimes. Muuda seda, kui sinu e-posti sõnumi aken on liiga väike");

DEFINE('_JW_MENU_HISTORY', "Ajalugu");
DEFINE('_JW_MENU_EMAILS', "Emailid");
DEFINE('_JW_MENU_STATUS', "AB olek");
DEFINE('_JW_DESC_BLOCKED',"Need IPd on blokeerinud rämpspostitõrje");


DEFINE('_JW_HISTORY_VISITORS',"Külastajate ajalugu");
DEFINE('_JW_HISTORY_SHOWING_ONLY', "Näidatakse ainult %d viimast külastajat.
                Selle väärtuse muutmiseks, mine Seaded -&gt; Ajalugu &amp; Jõudlus -&gt; HISTORY_MAX_DB_RECORDS . Ole ettevaatlik, see seade mõjutab allpool olevate andmete laadimisaega.  ");
DEFINE('_JW_MENU_BUG', "Teata veast");
DEFINE('_JW_MENU_FEATURE', "Küsi funktsiooni");

DEFINE('_JW_VISITS_CAME_FROM_KEYWORDS',"Märksõnad");

DEFINE('_JW_BLOCKING_UNBLOCK',"deblokeeri");
DEFINE('_JW_STATS_KEYPHRASE ',"Võtme lause");

DEFINE('_JW_STATUS_DATABASE_TABLE_NAME',"tabeli nimi");
DEFINE('_JW_STATUS_DATABASE_ROWS',"rida");
DEFINE('_JW_STATUS_DATABASE_DATA',"andmed");
DEFINE('_JW_STATUS_DATABASE_TOTAL',"kokku");

DEFINE('_JW_EMAIL_REPORTS',"Emaili aruanded");
DEFINE('_JW_EMAIL_REPORT_GENERATED',"Eile loodud filtreeritud e-posti aruanne");
DEFINE('_JW_EMAIL_REPORTS_VALUE_FILTERS',"Emaili väärtuse filtrid");
DEFINE('_JW_EMAIL_REPORTS_VALUE',"väärtus");
DEFINE('_JW_EMAIL_REPORTS_PERCENT',"protsent");
DEFINE('_JW_EMAIL_REPORTS_1DAY_CHANGE',"1-päeva muutus");
DEFINE('_JW_EMAIL_REPORTS_7DAY_CHANGE',"7-päeva muutus");
DEFINE('_JW_EMAIL_REPORTS_28DAY_CHANGE',"28-päeva muutus");
DEFINE('_JW_ANTISPAM_BLOCKED',"JoomlaWatch on blokeerinud %d spämmerit täna, kokku: %d");
DEFINE('_JW_ANTISPAM_ADDRESSES',"Blokeeritud IP aadressid");
DEFINE('_JW_ANTISPAM_SETTINGS',"Rämpspostitõrje seaded");
DEFINE('_JW_TRAFFIC_AJAX',"AJAX värskendab liiklusteavet");


DEFINE('_JW_HISTORY_PREVIOUS',"tagasi");
DEFINE('_JW_HISTORY_NEXT',"edasi");

/** additional translation for 1.2.11 for countries in more rows */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_COLUMNS',"Riikide veergude arv");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_ROWS',"Riikide ridade arv");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NAMES',"Näita või ära näita riikide nimesid");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FLAGS_FIRST',"Näita lippe ennem, seejärel protsente");

/* JoomlaWatch 1.2.14 translations */

DEFINE('_JW_GOALS_GET_INVERSED', "GET ümberpööramis tingimus");
DEFINE('_JW_GOALS_POST_INVERSED', "POST ümberpööramis tingimus");
DEFINE('_JW_GOALS_TITLE_INVERSED', "Tiitli ümberpööramis tingimus");
DEFINE('_JW_GOALS_USERNAME_INVERSED', "Kasutajanime ümberpööramis tingimus");
DEFINE('_JW_GOALS_CAME_FROM_INVERSED', "Tuli ümberpööramis tingimus");

DEFINE('_JW_STATS_MAP', "Viimaste külastuste kaart");
DEFINE('_JW_STATS_MAP_ENTER_KEY',"Palun sisesta <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a> võti, et kuvada viimaste külastuste kaarti:");
DEFINE('_JW_STATS_MAP_STORE_KEY',"säilita võti");
DEFINE('_JW_STATS_MAP_INVALID_KEY',"Palun sisesta kehtiv ipinfodb võti, mille said lehelt: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");

DEFINE('_JW_SIZEQUERY_BAD_REQUEST',"HALB PÄRING: ");

DEFINE('_JW_VISIT_SUBMITED_FIELDS',"Sisestatud vormiväljad:");
DEFINE('_JW_VISIT_URL_PARAMETERS',"URL parameetrid:");
DEFINE('_JW_VISIT_ADD_PAGE'," Lisa leht eesmärgina");
DEFINE('_JW_VISIT_BLOCK_IP'," Blokeeri see IP aadress");
DEFINE('_JW_VISIT_SUBMITED_FROM_VARIABLE'," Lisa see sisestatud vormi muutuja eesmärgina");
DEFINE('_JW_VISIT_URL_PARAMETER_GOAL'," Lisa see URL parameeter eesmärgina");

DEFINE('_JW_TREND_EMPTY',"Tühi");

DEFINE('_JW_NOT_NUMBER'," HOIATUS: Sisestatud väärtus ei ole number. JoomlaWatch ei tööta korralikult!");
DEFINE('_JW_EVALUATION_LEFT',"&nbsp; See on 15-päevane testimise versioon. Päeva jäänud: <b>%d</b>. Palun osa eluaegne <a href='http://www.codegravity.com/donate/joomlawatch/' target='_blank'>JoomlaWatch litsents oma domeenile</a> sellele ja tulevastele versioonidele.");
DEFINE('_JW_TRIAL_VERSION_EXPIRED'," Sinu prooviversioon on aegunud. Palun osta JoomlaWatch");

DEFINE('_JW_CONFIG_LICENSE_ACTIVATED',"Litsents on aktiveeritud edukalt. Tänan teid");
DEFINE('_JW_CONFIG_LICENCE_DONT_MATCH',"<b>Tõrge: litsentsivõti ja domeen ei sobi.</b><br/>Kas sa sisestasid sama domeeninime annetuse vormis, mida näed allpool? Palun võta ühendust: info@codegravity.com");

DEFINE('_JW_VIEW_ADMINBODY_LONG_MESSAGE',"Kui sa näed eespool olevat sõnumit liiga kaua siis sinu live sait võib olla vale.
                    Ava components/com_joomlawatch/config.php
                    eemalda kommentaar ja määra oma tegelik live sait. nt:
                    define('JOOMLAWATCH_LIVE_SITE', 'http://www.codegravity.com');");

DEFINE('_JW_ADMINBODY_LIVE_SITE',"Hoiatus: Sinu brauseris olev sait ja live sait konfiguratsioonis: %s ja %s ei sobi.");
DEFINE('_JW_ADMINBODY_SET_LIVE_SITE',"Määra live sait: %s ja jätka...");

DEFINE('_JW_ADMINHEADER_JW',"JoomlaWatch ");
DEFINE('_JW_ADMINHEADER_REMOVE_BACKLINK',"Eemalda tagalink");
DEFINE('_JW_ADMINHEADER_KNOWLEDGE_BASE',"Teadmistebaas");
DEFINE('_JW_ADMINHEADER_FLOW',"Voog");
DEFINE('_JW_ADMINHEADER_GRAPHS',"Graafik");
DEFINE('_JW_ADMINHEADER_COMPONENTS',"Komponendid");
DEFINE('_JW_ADMINHEADER_REVIEW',"ülevaade");
DEFINE('_JW_ADMINHEADER_WRITE',"Kirjuta ");

DEFINE('_JW_FLOW_TRAFFIC',"Liiklusvoog");
DEFINE('_JW_FLOW_SELECT_PAGE',"Vali leht:");
DEFINE('_JW_FLOW_OUTG_LINKS',"Juure väljuvate linkide arv:");
DEFINE('_JW_FLOW_NESTING',"Pesastustase:");
DEFINE('_JW_FLOW_SCALE',"Skaala:");

DEFINE('_JW_COMERCIAL_AD_FREE',"Reklaamivaba versioon");
DEFINE('_JW_COMERCIAL_THANK_DONATION',"Täname Teid väga Teie annetuse eest!");
DEFINE('_JW_COMERCIAL_REGISTRATION_KEY',"Sinu domeeni %s registreerimisvõti on: ");
DEFINE('_JW_COMERCIAL_BACKLINKS_REMOVE',"Nüüd sa saad eemaldada tagalinki või peita JoomlaWatch logo esilehel (seadetes) ");


DEFINE('_JW_SIZES_LAST_CHECK',"Viimane kontroll teostati:");
DEFINE('_JW_SIZES_ADMINISTRATOR',"SININE = Komponendi/mooduli suurus /administrator kataloogis");

DEFINE('_JW_SIZECOMPONENTS_COMPONENT',"Komponent");
DEFINE('_JW_SIZECOMPONENTS_TOTAL',"Kokku:");
DEFINE('_JW_SIZECOMPONENTS_SIZE',"Suurus");
DEFINE('_JW_SIZECOMPONENTS_REFRESH_ALL',"Värskenda kõik");

DEFINE('_JW_SIZEDATABASE_TABLE',"Tabel");
DEFINE('_JW_SIZEDATABASE_SIZE',"Suurus");
DEFINE('_JW_SIZEDATABASE_1DAY',"1 päeva muutus");
DEFINE('_JW_SIZEDATABASE_7DAY',"7 päeva muutus");
DEFINE('_JW_SIZEDATABASE_28DAY',"30 päeva muutus");
DEFINE('_JW_SIZEDATABASE_NO_DATA',"andmed puuduvad");
DEFINE('_JW_SIZEDATABASE_TOTAL',"Kokku:");

DEFINE('_JW_SIZEMODULES_REFRESH_ALL',"Värskenda kõiki");
DEFINE('_JW_SIZEMODULES_TOTAL',"Kokku:");
DEFINE('_JW_SIZEMODULES_MODULE',"Moodul");
DEFINE('_JW_SIZEMODULES_SIZE',"Suurus");

DEFINE('_JW_SIZES_FILES',"Failid &amp; kataloogid");
DEFINE('_JW_SIZES_BYTES',"baiti");
DEFINE('_JW_SIZES_KB',"KB");
DEFINE('_JW_SIZES_MB',"MB");
DEFINE('_JW_SIZES_GB',"GB");
DEFINE('_JW_SIZES_REFRESH',"Värskenda");

DEFINE('_JW_STATS_FOOTER',"JoomlaWatch &copy;2006-@YEAR@ Matej Koval");

DEFINE('_JW_STATUS_MB',"MB");
DEFINE('_JW_STATUS_DATABASE',"Joomla andmebaasi tabeli suuruss");


DEFINE('_JW_DESC_IPINFODB_KEY',"Viimaste külastuste kaart ipinfodb.com võti: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");
DEFINE('_JW_SETTINGS_FORCE_TIMEZONE_OFFSET',"Sunni ajatsooni nihe");


/* JoomlaWatch 1.2.17 translations */
DEFINE('_JW_MENU_UPDATE', "Uuenda");
DEFINE('_JW_MENU_UPDATE_TITLE', "Varunda & Uuenda");
DEFINE('_JW_ADMINHEADER_NA_IN_THIS_VERSION',"Pole saadaval tasuta versioonis, kontrolli palun litsentsi vahekaarti");
DEFINE('_JW_SPAMWORD_BANS_ENABLED', "Spämmi sõnade keeld lubatud");
DEFINE('_JW_SPAMWORD_LIST', "Spämmi sõnade nimekiri");
DEFINE('_JW_HIDE_REPETITIVE_TITLE', "Peida korduvad pealkirjad");
DEFINE('_JW_TRUNCATE_VISITS', "Lühendatud külastused");
DEFINE('_JW_TRUNCATE_STATS', "Lühendatud andmed");
DEFINE('_JW_TRUNCATE_GOALS', "Lühendatud eesmärgid");
DEFINE('_JW_LIMIT_BOTS', "Piira bote");
DEFINE('_JW_LIMIT_VISITORS', "Limit Visitors");
DEFINE('_JW_TOOLTIP_WIDTH', "Kohtspikkri laius");
DEFINE('_JW_TOOLTIP_HEIGHT', "Kohtspikkri kõrgus");
DEFINE('_JW_TOOLTIP_URL', "Kohtspikkri URL");
DEFINE('_JW_TOOLTIP_ONCLICK', "Kohtspikkri OnClick");
DEFINE('_JW_IP_STATS', "IP statistika");
DEFINE('_JW_IPINFODB_KEY', "IP info AB võti ");
DEFINE('_JW_ONLY_LAST_URI', "Ainult viimane URI ");

DEFINE('_JW_FRONTEND_HIDE_LOGO', "Peida esiotsa logo ");
DEFINE('_JW_FRONTEND_NOFOLLOW', "Esiosa No Follow");
DEFINE('_JW_FRONTEND_NO_BACKLINK', "Esiosa no Back Link");
DEFINE('_JW_FRONTEND_USER_LINK', "Esiosa kasutaja lingid");
DEFINE('_JW_FRONTEND_COUNTRIES_FIRST', "Esiosa riigid enne");
DEFINE('_JW_FRONTEND_COUNTRIES_NAMES', "Esiosa riigide nimed");
DEFINE('_JW_FRONTEND_COUNTRIES_UPPERCASE', "Esiosa riigide suurtähed");
DEFINE('_JW_FRONTEND_COUNTRIES_FLAGS_FIRST', "Esiosa riigide lipp ennem ");
DEFINE('_JW_FRONTEND_COUNTRIES_NUM', "Esiosa riikide arv");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_COLUMNS', "Esiosa riikide maks. veerud");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_ROWS', "Esiosa riikide maks. read");
DEFINE('_JW_FRONTEND_VISITORS_TODAY', "Esiosa tänased külastajad ");
DEFINE('_JW_FRONTEND_VISITORS_YESTERDAY', "Esiosa eilsed külastajad ");
DEFINE('_JW_FRONTEND_VISITORS_THIS_WEEK', "Esiosa selle nädala külastajad ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_WEEK', "Esiosa eelmise nädala külastajad ");

DEFINE('_JW_FRONTEND_VISITORS_THIS_MONTH', "Esiosa selle kuu külastajad ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_MONTH', "Esiosa eelmise kuu külastajad ");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL', "Esiosa Peida Külastajad kokku");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL	', "Esiosa Esialgne kokku");
DEFINE('_JW_HISTORY_MAX_VALUES', "Ajaloo maks. väärtused");
DEFINE('_JW_HISTORY_MAX_DB_RECORDS', "Ajaloo maks. andmed");
DEFINE('_JW_UPDATE_TIME_VISITS', "Uuenda külastus aega");
DEFINE('_JW_UPDATE_TIME_STATS', "Uuenda aja andmeid");
DEFINE('_JW_STATS_MAX_ROWS', "Maks. ridade statistika");
DEFINE('_JW_STATS_IP_HITS', "IP tabamuste statistika");
DEFINE('_JW_MAXID_BOTS', "Maks. ID botid");
DEFINE('_JW_MAXID_VISITORS', "Maks. ID külastajad");
DEFINE('_JW_STATS_KEEP_DAYS', "Statistika hoidmise päevad ");
DEFINE('_JW_CACHE_FRONTEND_COUNTRIES', "Puhverda esiosa riigid ");
DEFINE('_JW_CACHE_FRONTEND_VISITORS', "Puhverda esiosa külastajad ");

DEFINE('_JW_UNINSTALL_KEEP_DATA	', "Eemalda ja säilita andmed ");
DEFINE('_JW_IGNORE_IP', "Eira IP'd");
DEFINE('_JW_IGNORE_URI', "Eira URI");
DEFINE('_JW_IGNORE_USER', "Eira Kasutajat");
DEFINE('_JW_BLOCKING_MESSAGE', "Blokeerim sõnumit");
DEFINE('_JW_SERVER_URI_KEY', "Serveri URI võti");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL', "Esiotsa kasutajate Esialgsed kokku");
DEFINE('_JW_SIZEDATABASE_RECORDS', "Andmed");
/***********EDITs******************/
DEFINE('_JW_ANTISPAM_BLOCKING_TEXT'," Et blokeerimist tõhustada, pead avaldama JoomlaWatch agendi ENNE sisu ja vorme. Nt. vasak pool mallis.
                    <br/>
                    Mine Mooduli haldur -> JoomlaWatch agent -> Vali positsiooniks vasakule");
DEFINE('_JW_EMAIL_SEO_REPORTS', "SEO aruanded");
DEFINE('_JW_DESC_EMAIL_SEO_REPORTS_ENABLED',"SEO Öine e-maili aruanded lubatud");
DEFINE('_JW_WATCH_INSTALLATION_DEMO',"Vaata paigaldamise demot");
?>