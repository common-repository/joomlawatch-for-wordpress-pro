<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version @VERSION@
 * @revision @REVISION@
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) @YEAR@ by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/
defined( '_JEXEC' ) or die( 'Restricted access' );

#JoomlaWatch language file - to create a new language file, just copy the english.php to eg. german.php and place into /components/com_joomlawatch/lang/

# Main Menu
DEFINE('_JW_MENU_STATS', "�tatistika");
DEFINE('_JW_MENU_GOALS', "Ciele");
DEFINE('_JW_MENU_SETTINGS', "Nastavenia");
DEFINE('_JW_MENU_CREDITS', "Po�akovanie");
DEFINE('_JW_MENU_FAQ', "�ast� ot�zky");
DEFINE('_JW_MENU_DOCUMENTATION', "Dokument�cia");
DEFINE('_JW_MENU_LICENSE', "Licencia");
DEFINE('_JW_MENU_DONATORS', "Podporovatelia");
DEFINE('_JW_MENU_SUPPORT', "Podporte JoomlaWatch a reklamy sa V�m nebud� zobrazova�.");

# Left visitors real-time window
DEFINE('_JW_VISITS_VISITORS', "Posledn� n�v�tevn�ci");
DEFINE('_JW_VISITS_BOTS', "Roboti");
DEFINE('_JW_VISITS_CAME_FROM', "Pri�iel z");
DEFINE('_JW_VISITS_MODULE_NOT_PUBLISHED', "V� JoomlaWach modul nie je publikovan�. �iadne �tatistiky sa preto nezaznamen�vaj�. Cho�te do sekcie modulov a nastavte pre modul JoomlaWatch - publikova� na v�etk�ch str�nkach");
DEFINE('_JW_VISITS_PANE_LOADING', "Na��tavam...");

# Right stats window
DEFINE('_JW_STATS_TITLE', "�tatistiky n�v�tev pre t��de�");
DEFINE('_JW_STATS_WEEK', "T��de�");
DEFINE('_JW_STATS_THIS_WEEK', "tento t��de�");
DEFINE('_JW_STATS_UNIQUE', "jedine�n�");
DEFINE('_JW_STATS_LOADS', "na��tan�");
DEFINE('_JW_STATS_HITS', "hits");
DEFINE('_JW_STATS_TODAY', "dnes");
DEFINE('_JW_STATS_FOR', "pre");
DEFINE('_JW_STATS_ALL_TIME', "Cel� obdobie");
DEFINE('_JW_STATS_EXPAND', "rozba�");
DEFINE('_JW_STATS_COLLAPSE', "zaba�");
DEFINE('_JW_STATS_URI', "Str�nky");
DEFINE('_JW_STATS_COUNTRY', "Krajiny");
DEFINE('_JW_STATS_USERS', "Pou��vatelia");
DEFINE('_JW_STATS_REFERERS', "Odkazovatelia");
DEFINE('_JW_STATS_IP', "IP adresy");
DEFINE('_JW_STATS_BROWSER', "Prehliada�e");
DEFINE('_JW_STATS_OS', "OS");
DEFINE('_JW_STATS_KEYWORDS', "K���ov� slov�");
DEFINE('_JW_STATS_GOALS', "Ciele");
DEFINE('_JW_STATS_TOTAL', "Celkovo");
DEFINE('_JW_STATS_DAILY', "Denne");
DEFINE('_JW_STATS_DAILY_TITLE', "Denn� �tatistiky");
DEFINE('_JW_STATS_ALL_TIME_TITLE', "Celkov� �tatistiky");
DEFINE('_JW_STATS_LOADING', "na��tavam...");
DEFINE('_JW_STATS_LOADING_WAIT', "na��tavam... pros�m �akajte");
DEFINE('_JW_STATS_IP_BLOCKING_TITLE', "Blokovanie IP adries");
DEFINE('_JW_STATS_IP_BLOCKING_ENTER', "Vlo�te manu�lne IP");
DEFINE('_JW_STATS_IP_BLOCKING_MANUALLY', "Vlo�te IP adresu, ktor� chcete zablokova�. (napr. 217.242.11.54 or 217.* alebo 217.242.* pre zablokovanie rozsahu hviezdi�kou)");
DEFINE('_JW_STATS_IP_BLOCKING_TOGGLE', "Skuto�ne prepn�� blokovanie IP");
DEFINE('_JW_STATS_PANE_LOADING', "Na��tavam �tatistiky...");

# Settings
DEFINE('_JW_SETTINGS_TITLE', "Nastavenia");
DEFINE('_JW_SETTINGS_DEFAULT', "�tandardne");
DEFINE('_JW_SETTINGS_SAVE', "Ulo�");
DEFINE('_JW_SETTINGS_APPEARANCE', "Vzh�ad");
DEFINE('_JW_SETTINGS_FRONTEND', "Vzh�ad na str�nke");
DEFINE('_JW_SETTINGS_HISTORY_PERFORMANCE', "Hist�ria a V�konnos�");
DEFINE('_JW_SETTINGS_ADVANCED', "Roz��ren�");
DEFINE('_JW_SETTINGS_IGNORE', "Ignorovanie");
DEFINE('_JW_SETTINGS_BLOCKING', "Blokovanie");
DEFINE('_JW_SETTINGS_EXPERT', "Expert");
DEFINE('_JW_SETTINGS_RESET_CONFIRM', "Skuto�ne chcete vymaza� v�etky �daje?");
DEFINE('_JW_SETTINGS_RESET_ALL', "Vyma� v�etky �daje");
DEFINE('_JW_SETTINGS_RESET_ALL_LINK', "Vyma� v�etky �tatistick� a n�v�tevn�cke �daje");
DEFINE('_JW_SETTINGS_LANGUAGE', "Jazyk");
DEFINE('_JW_SETTINGS_SAVED', "Nastavenia boli ulo�en�");
DEFINE('_JW_SETTINGS_ADD_YOUR_IP', "Pridajte va�u IP");
DEFINE('_JW_SETTINGS_TO_THE_LIST', "do zoznamu.");

# Other / mostly general
DEFINE('_JW_TITLE', "AJAX monitor pre Joomla CMS");
DEFINE('_JW_BACK', "Nasp�");
DEFINE('_JW_ACCESS_DENIED', "Nem�te �iadne pr�va na tento obsah");
DEFINE('_JW_LICENSE_AGREE', "S�hlas�m s podmienkami");
DEFINE('_JW_LICENSE_CONTINUE', "Pokra�ova�");
DEFINE('_JW_SUCCESS', "Oper�cia prebehla �spe�ne");
DEFINE('_JW_RESET_SUCCESS', "V�etky �tatistick� �daje a �daje o n�v�tevn�koch boli vymazan�");
DEFINE('_JW_RESET_ERROR', "�daje neboli vymazan�, nie�o nevy�lo");
DEFINE('_JW_CREDITS_TITLE', "Po�akovanie");
DEFINE('_JW_TRENDS_DAILY_WEEKLY', "Denn� a t��denn� �tatistiky pre �daj:");
DEFINE('_JW_AJAX_PERMISSION_DENIED_1', "AJAX pr�stup odmietnut�: Pros�m prezerajte tieto �tatistiky z dom�ny, ktor� ste �pecifikovali v configuration.php syst�mu joomla - ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_2', "Mo�no ste len zabudli zada� www. pred n�zvom va�ej dom�ny v prehliada�i. Javascript sk��a z�ska� obsah ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_3', "z");
DEFINE('_JW_AJAX_PERMISSION_DENIED_4', "�o ho n�ti myslie� si, �e je to in� dom�na.");

# Header
DEFINE('_JW_HEADER_DOWNLOAD', "Z�skajte najnov�� k�d tohto roz��renia z");
DEFINE('_JW_HEADER_CAST_YOUR', "Za�lite svoj");
DEFINE('_JW_HEADER_VOTE', "Hlas");

# Tooltips
DEFINE('_JW_TOOLTIP_CLICK', "Kliknite pre otvorenie tooltip okna");
DEFINE('_JW_TOOLTIP_MOUSE_OVER', "Prejdite my�ou pre otvorenie tooltip okna");
DEFINE('_JW_TOOLTIP_YESTERDAY_INCREASE', "v�eraj�� pr�rastok");
DEFINE('_JW_TOOLTIP_HELP', "Otvor� online extern� help pre");
DEFINE('_JW_TOOLTIP_WINDOW_CLOSE', "Zatvor toto okno");
DEFINE('_JW_TOOLTIP_PRINT', "Tla�");

# Goals
DEFINE('_JW_GOALS_INSERT', "Pridaj nov� cie�");
DEFINE('_JW_GOALS_UPDATE', "Uprav cie� ��slo");
DEFINE('_JW_GOALS_ACTION', "Akcia");
DEFINE('_JW_GOALS_TITLE', "Nov� cie�");
DEFINE('_JW_GOALS_NEW', "Nov� cie�");
DEFINE('_JW_GOALS_RELOAD', "Obnov");
DEFINE('_JW_GOALS_ADVANCED', "Roz��ren�");
DEFINE('_JW_GOALS_NAME', "Meno");
DEFINE('_JW_GOALS_ID', "id");
DEFINE('_JW_GOALS_URI_CONDITION', "URI podmienka");
DEFINE('_JW_GOALS_GET_VAR', "GET premenn�");
DEFINE('_JW_GOALS_GET_CONDITION', "GET podmienka");
DEFINE('_JW_GOALS_POST_VAR', "POST premenn�");
DEFINE('_JW_GOALS_POST_CONDITION', "POST podmienka");
DEFINE('_JW_GOALS_TITLE_CONDITION', "Title podmienka");
DEFINE('_JW_GOALS_USERNAME_CONDITION', "Username podmienka");
DEFINE('_JW_GOALS_IP_CONDITION', "IP podmienka");
DEFINE('_JW_GOALS_CAME_FROM_CONDITION', "'Pri�iel z adresy..' podmienka");
DEFINE('_JW_GOALS_BLOCK', "Blokuj");
DEFINE('_JW_GOALS_REDIRECT', "Presmeruj na URL");
DEFINE('_JW_GOALS_HITS', "Hits");
DEFINE('_JW_GOALS_ENABLED', "Povolen�");
DEFINE('_JW_GOALS_EDIT', "Uprav");
DEFINE('_JW_GOALS_DELETE', "Vyma�");
DEFINE('_JW_GOALS_DELETE_CONFIRM', "Strat�te v�etky doteraj�ie �tatistick� d�ta pre tento cie�. Chcete naozaj vymaza� cie� ��slo ");

# Frontend
DEFINE('_JW_FRONTEND_COUNTRIES', "Krajiny");
DEFINE('_JW_FRONTEND_VISITORS', "N�v�tevn�ci");
DEFINE('_JW_FRONTEND_TODAY', "Dnes");
DEFINE('_JW_FRONTEND_YESTERDAY', "V�era");
DEFINE('_JW_FRONTEND_THIS_WEEK', "Tento t��de�");
DEFINE('_JW_FRONTEND_LAST_WEEK', "Minul� t��de�");
DEFINE('_JW_FRONTEND_THIS_MONTH', "Tento mesiac");
DEFINE('_JW_FRONTEND_LAST_MONTH', "Minul� mesiac");
DEFINE('_JW_FRONTEND_TOTAL', "Celkovo");

# Settings description - quite long
DEFINE('_JW_DESC_DEBUG', "JoomlaWatch je v debug m�de. Touto cestou viete zisti� pr��iny ch�b. Pre vypnutie, zme�te pros�m hodnotu JOOMLAWATCH_DEBUG v /components/com_joomlawatch/config.php z 1 na 0");
DEFINE('_JW_DESC_STATS_MAX_ROWS', "Maxim�lny po�et riadkov �dajov po rozbalen� v �tatistike");
DEFINE('_JW_DESC_STATS_IP_HITS', "V�etky IP adresy, ktor� maj� menej hitov predch�dzaj�ci de� ako dan� hodnota bud� vymazan� z hist�rie IP adries.");
DEFINE('_JW_DESC_STATS_URL_HITS', "V�etky URL, ktor� maj� menej hitov predch�dzaj�ci de� ako dan� hodnota bud� vymazan� z hist�rie URL.");
DEFINE('_JW_DESC_IGNORE_IP', "Ignoruj dan� IP adresy v �tatistike. Odde�te nov�m riadkom. M��te pou�i� hviezdi�ky. <br/>Napr�klad. 192.* bude ignorova� 192.168.51.31, 192.168.16.2, at�..");
DEFINE('_JW_DESC_UPDATE_TIME_VISITS', "Doba obnovovania n�v�tevn�kov v �avom paneli v milisekund�ch, �tandardne 2000, bu�te opatrn� s t�mto nastaven�m. Pre prejavenie ��inku, znovu na��tajte administra�n� rozhranie JoomlaWatch-u.");
DEFINE('_JW_DESC_UPDATE_TIME_STATS', "Doba obnovovania �tatist�k v pravom paneli v milisekund�ch, �tandardne 2000, bu�te opatrn� s t�mto nastaven�m. Pre prejavenie ��inku, znovu na��tajte administra�n� rozhranie JoomlaWatch-u.");
DEFINE('_JW_DESC_MAXID_BOTS', "Ko�ko z�znamov robotov uchov�va� v datab�ze.");
DEFINE('_JW_DESC_MAXID_VISITORS', "Ko�ko z�znamov n�v�tevn�kov uchov�va� v datab�ze.");
DEFINE('_JW_DESC_LIMIT_BOTS', "Ko�ko z�znamov robotov uvid�te v �avom paneli v administra�nom rozhran�.");
DEFINE('_JW_DESC_LIMIT_VISITORS', "Ko�ko z�znamov re�lnych n�v�tevn�kov uvid�te v �avom paneli v administra�nom rozhran�.");
DEFINE('_JW_DESC_TRUNCATE_VISITS', "Maximum znakov ktor� bud� zobrazen� pre dlh� titulky a URI adresy");
DEFINE('_JW_DESC_TRUNCATE_STATS', "Maximum znakov ktor� bud� zobrazen� pre dlh� titulky v pravom �tatistickom paneli");
DEFINE('_JW_DESC_STATS_KEEP_DAYS', "Po�et dn�, za ktor� uchov�va� celkov� hist�riu �tatist�k v datab�ze. 0 = nekone�no.");
DEFINE('_JW_DESC_TIMEZONE_OFFSET', "Ak ste v inom �asovom p�sme ako v� server na ktorom hostujete str�nky. (Zadajte kladn� alebo z�porn� ��slo ako rozdiel �asov�ho p�sma)");
DEFINE('_JW_DESC_WEEK_OFFSET', "Posun vr�mci t��d�a, timestamp/(3600*24*7) vracia ��slo t��d�a od 1.1.1970, tento posun je korekcia, aby t��de� za��nal pondelkom. V norm�lnych pr�padoch nie je potrebn� meni�.");
DEFINE('_JW_DESC_DAY_OFFSET', "Posun vr�mci d�a, timestamp/(3600*24) vracia ��slo d�a od 1.1.1970, tento posun je korekcia, aby de� za��nal o 00:00. V norm�lnych pr�padoch nie je potrebn� meni�.");
DEFINE('_JW_DESC_FRONTEND_HIDE_LOGO', "Pre nahradenie loga JoomlaWatch nevidite�n�m logom na str�nkach");
DEFINE('_JW_DESC_IP_STATS', "Pou��va� aj IP adresy v �tatistik�ch. V niektor�ch krajin�ch sa IP adresa pova�uje za osobn� �daj. Pou��vajte na vlastn� riziko.");
DEFINE('_JW_DESC_HIDE_ADS', "This setting hides the ads in the backend, if they really annoy you. By keeping them, you support the further development of this tool. Thank you");
DEFINE('_JW_DESC_TOOLTIP_ONCLICK', "Nastavte na neza�krtnut�, ak chcete zobrazova� okn� grafov a m�p po prejden� kurzorom nad dan�mi ikonkami, namiesto kliknutia.");
DEFINE('_JW_DESC_SERVER_URI_KEY', "�tandardne je toto nastavenie 'REDIRECT_URL', ak pou��vate url rewriting, m��te nastavi� aj na 'SCRIPT_URL' ak sa vo va�ich �tatistik�ch zobrazuje len index.php");
DEFINE('_JW_DESC_BLOCKING_MESSAGE', "Spr�va, ktor� je zobrazen� zablokovan�m pou��vate�om, alebo �al�ie inform�cie z ak�ho d�vodu ste dan�ch pou��vate�ov zablokovali.");
DEFINE('_JW_DESC_TOOLTIP_WIDTH', "��rka tooltip okna");
DEFINE('_JW_DESC_TOOLTIP_HEIGHT', "V��ka tooltip okna");
DEFINE('_JW_DESC_TOOLTIP_URL', "Mo�te tu da� �ubovo�n� adresu, pre vizualiz�ciu IP adresy n�v�tevn�ka. {ip} bude nahraden� aktu�lnou IP adresou pou��vate�a. Pr�klad: http://somewebsite.com/query?iplookup={ip}");
DEFINE('_JW_DESC_IGNORE_URI', "You can type any URI you want to be ignored from stats. You can use wildcards (* and ?) here. Napr. : /freel?n* ");
DEFINE('_JW_DESC_GOALS_NAME', "�pecifikujte meno cie�a. Toto meno n�sledne uvid�te v �tatistik�ch.");
DEFINE('_JW_DESC_GOALS_URI_CONDITION', "To, �o sa nach�dza hne� za adresou va�ej dom�ny. Pre http://www.codegravity.com/projects/ je URI: /projects/ (Pr�klad: <b>/projects*</b>)");
DEFINE('_JW_DESC_GOALS_GET_VAR', "GET premenn� je zvy�ajne to, �o vid�te v URL zvy�ajne za znakom ? alebo &amp; znakom. Napr: http://www.codegravity.com/index.php?<u>meno</u>=peter&amp;<u>priezvisko</u>=smith. M��te tie� pou�i� <u>*</u> v tomto pol��ku pre prejdenie v�etk�ch get premenn�ch. (Pr�klad: <b>m*no</b>)");
DEFINE('_JW_DESC_GOALS_GET_CONDITION', "Tu m��te �pecifikova� �omu sa m� rovna� premenn� z predch�dzaj�ceho po�a. (Pr�klad: <b>p?t*r</b>) ");
DEFINE('_JW_DESC_GOALS_POST_VAR', "Celkom podobne, ale zis�ujeme hodnoty zadan� do formul�rov. Teda, ak m�te na str�nke formul�r, ktor� m� vstupn� pole &lt;input type='text' name='<u>skusenosti</u>' /&gt;. (Pr�klad: <b>sk*enosti</b>)");
DEFINE('_JW_DESC_GOALS_POST_CONDITION', "Hodnota, ktorej sa m� rovna� premenn� z predch. POST po�a. Napr. Chceme zisti�, �� pou��vate� do formul�ra zadal v poli skusenosti hodnotu java. (Pr�klad: <b>*java*</b>)");
DEFINE('_JW_DESC_GOALS_TITLE_CONDITION', "Titulok str�nky ktor� sa m� zhodova�. (Pr�klad: <b>*freelance programmers*</b>)");
DEFINE('_JW_DESC_GOALS_USERNAME_CONDITION', "Meno prihl�sen�ho pou��vate�a, na ktor�ho sa cie� vz�ahuje. (Pr�klad: <b>psmith*</b>)");
DEFINE('_JW_DESC_GOALS_IP_CONDITION', "IP ktor� poch�dza z adresy: (Pr�klad: <b>201.9?.*.*</b>)");
DEFINE('_JW_DESC_GOALS_CAME_FROM_CONDITION', "URL adresa z ktorej pri�iel dan� n�v�tevn�k. (Pr�klad: <b>*www.google.*</b>)");
DEFINE('_JW_DESC_GOALS_REDIRECT', "Ak s� naplnen� horeuveden� podmienky, m��ete pou��vate�a presmerova� dan� vami zvolen� adresu. M� vy��iu prioritu ako 'blokovanie': (Pr�klad: <b>http://www.codegravity.com/chod-prec.html</b>)");
DEFINE('_JW_DESC_TRUNCATE_GOALS', "Ko�ko znakov maxim�lne ukazova� v tabu�ke cie�ov pre dlh� n�zvy");
DEFINE('_JW_DESC_FRONTEND_NO_BACKLINK', "Sp�tn� odkaz na codegravity.com, m��ete toto nastavenie zmeni�, no budeme v�a�n� ak ho ponech�te.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES', "Zobraz celkov� �tatistiky v module na str�nka. Ak nastavenie zmen�te, mus�te po�ka� �as uveden� v CACHE_FRONTEND_ aby sa zmeny prejavili");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FIRST', "Ak chcete prehodi� poradie N�v�tevn�ci/Krajiny v module na str�nke. Od�krtnite to, a �tatistika N�v�tevn�ci sa bude zobrazova� ako prv�, za �ou Krajiny.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NUM', "Po�et kraj�n ktor� si prajete ukazova� v module na str�nkach");
DEFINE('_JW_DESC_FRONTEND_VISITORS', "Zobraz krajiny vmodule na str�nkach. Ak nastavenie zmen�te, mus�te po�ka� �as uveden� v CACHE_FRONTEND_ aby sa zmeny prejavili");
DEFINE('_JW_DESC_CACHE_FRONTEND_COUNTRIES', "�as v sekund�ch ako �asto sa maj� obnovova� �tatistiky kraj�n v module na str�nkach");
DEFINE('_JW_DESC_CACHE_FRONTEND_VISITORS', "�as v sekund�ch ako �asto sa maj� obnovova� �tatistiky n�v�tevn�kov v module na str�nkach");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TODAY', "Zobraz n�v�tevn�kov na str�nke pre: dnes. Ak nastavenie zmen�te, mus�te po�ka� �as uveden� v CACHE_FRONTEND_ aby sa zmeny prejavili");
DEFINE('_JW_DESC_FRONTEND_VISITORS_YESTERDAY', "Zobraz n�v�tevn�kov na str�nke pre: v�era. Ak nastavenie zmen�te, mus�te po�ka� �as uveden� v CACHE_FRONTEND_ aby sa zmeny prejavili");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_WEEK', "Zobraz n�v�tevn�kov na str�nke pre: tento v��de�. Ak nastavenie zmen�te, mus�te po�ka� �as uveden� v CACHE_FRONTEND_ aby sa zmeny prejavili");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_WEEK', "Zobraz n�v�tevn�kov na str�nke pre: minul� t��de�. Ak nastavenie zmen�te, mus�te po�ka� �as uveden� v CACHE_FRONTEND_ aby sa zmeny prejavili");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_MONTH', "Zobraz n�v�tevn�kov na str�nke pre: tento mesiac. Ak nastavenie zmen�te, mus�te po�ka� �as uveden� v CACHE_FRONTEND_ aby sa zmeny prejavili");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_MONTH', "Zobraz n�v�tevn�kov na str�nke pre: minul� mesiac. Ak nastavenie zmen�te, mus�te po�ka� �as uveden� v CACHE_FRONTEND_ aby sa zmeny prejavili");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL', "Zobraz n�v�tevn�kov celkovo od in�tal�cie JoomlaWatch. Ak nastavenie zmen�te, mus�te po�ka� �as uveden� v CACHE_FRONTEND_ aby sa zmeny prejavili");
DEFINE('_JW_DESC_LANGUAGE', "Jazykov� s�bor ktor� sa pou�ije. Jazykov� s�bory s� umiestnen� v /components/com_joomlawatch/lang/. Ak chcete prida� nov� jazyk, najprv sa presved�te �i sa u� nenach�dza na str�nkach tohto projektu. Ak tam nie je, skop�rujte �tandardn� english.php napr�klad na mojjazyk.php a umiestnite do dan�ho adres�ra. N�sledne prelo�te v�etky n�zvy vpravo. Najle�ie ke� pou�ijete k�dovanie UTF-8");
DEFINE('_JW_DESC_GOALS', "Ciele v�m umo��uj� zada� �peci�lne parametre. Ak tieto parametre s�hlasia, po��tadlo dan�ho cie�a je zv��en�. T�mto sp�sobom m��te monitorova�, �i n�v�tevn�k nav�t�vil �pecifick� URI, poslal �pecifick� hodnotu vo formul�ri, m� �pecifick� pou��vate�sk� meno, alebo pri�iel z niektorej adresy. M��ete tak�hoto n�v�tevn�ka zablokova�, alebo presmerova� na �peci�lnu URL adresu.");
DEFINE('_JW_DESC_GOALS_INSERT', "Vo v�etk�ch poliach okrem mena m��ete pou��va� znaky * a ?. Napr�klad: ?ear (obsiahne: near, tear, ..),  p*r (obsiahne: pr, peer, pear ..) ");
DEFINE('_JW_DESC_GOALS_BLOCK', "Nastavte na 1, ak si �el�te aby bol n�v�tevn�k ktor� vyhovuje krit�ri�m blokovan�. Nebude vidie� zbytok obsahu str�nok, iba spr�vu o jeho blokovan� - bez presmerovania, a jeho IP adresa bude pridan� do zoznamu blokovan�ch adries v �tatistike (Pr�klad: <b>1</b>)");

/* new translations */
DEFINE('_JW_GOALS_COUNTRY_CONDITION', "Country podmienka");
DEFINE('_JW_DESC_GOALS_COUNTRY_CONDITION', "Dvojp�smenov� k�d krajiny (Napr.: <b>TH</b>)");
DEFINE('_JW_STATS_INTERNAL',"Pohyb na str�nke");
DEFINE('_JW_STATS_FROM',"Z");
DEFINE('_JW_STATS_TO',"Do");
DEFINE('_JW_STATS_ADD_TO_GOALS',"Pridaj ku g�lom");
DEFINE('_JW_VISITS_ADD_GOAL_COUNTRY',"Pridaj g�l pre t�to krajinu");
DEFINE('_JW_MENU_REPORT_BUG',"Ohl�s chybu alebo n�vrh");
DEFINE('_JW_GOALS_COUNTRY',"Krajina");

/* translations 1.2.8b_12 */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_UPPERCASE',"Ak chcete, aby sa n�zvy kraj�n zobrazovali na str�nkach s v�etk�mi ve�k�mi p�smenami (Napr.: GERMANY, UNITED KINGDOM namiesto Germany, United Kingdom)");
DEFINE('_JW_DESC_CACHE_FRONTEND_USERS',"�as v sekund�ch ako �asto sa maj� obnovova� �tatistiky pou��vate�ov v module na str�nkach");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL_INITIAL', "Po�iato�n� hodnota 'Celkovo:' na str�nkach. U�ito�n�, ke� ste migrovali z in�ho �tatistick�ho n�stroja. (Napr.: 20000). Nastavte nasp� na 0 ak nechcete pou��va� t�to vlastnos�.");
DEFINE('_JW_DESC_IGNORE_USER', "Ignoruj pou��vate�ov z tohto textbox-u. Pou��vate�sk� meno na riadok. (Napr.: myself {nov� riadok} mark_*) ");
DEFINE('_JW_FRONTEND_USERS_MOST', "Najakt�vnej�� pou��vatelia za dnes z celkov�ho po�tu");
DEFINE('_JW_DESC_SPAMWORD_BANS_ENABLED',"Povoli� blokovanie na z�klade listu spam slov zobrazen�ho ni��ie?");
DEFINE('_JW_DESC_SPAMWORD_LIST',"Najpou��vatej�ie spam slov� pou��van� spam robotmi. M��te pou�i� * a ?. (Napr.: ph?rmac*). Ak nastavenie hore je povolen�, JoomlaWatch bude zis�ova�, �i �to�n�k odoslal formul�r (HTTP POST po�iadavka) na va�ej str�nke s niektor�m z t�chto slov. (Vz�ahuje sa len na Joomla str�nky - f�rum, koment�re, no je to celkom efekt�vny sp�sob eliminova� spam robotov, ktor� sk��aj� odosla� ka�d� mo�n� formul�r)");
DEFINE('_JW_SETTINGS_ANTI_SPAM',"Anti-Spam");

/* translations 1.2.11b */
DEFINE('_JW_STATS_KEYPHRASE', "K���ov� slov�");
DEFINE('_JW_DESC_HISTORY_MAX_VALUES', "Maximum po�et n�v�tev v hist�rii(Pr�klad: <i>100</i>)");

DEFINE('_JW_DESC_ONLY_LAST_URI', "V n�v�tev�ch, uk� v�dy iba posledn� str�nku, nie v�etky");
DEFINE('_JW_DESC_HIDE_REPETITIVE_TITLE', "V n�v�tev�ch, skry opakuj�ci sa titulok str�nky");
DEFINE('_JW_DESC_HISTORY_MAX_DB_RECORDS', "Maximum po�tu n�v�tev, ktor� dr�a� v datab�ze pre z�lo�ku Hist�ria. Bu�te opatrn� s t�mto nastaven�m, ak m�te ve�mi nav�tevovan� str�nku.");
DEFINE('_JW_DESC_UNINSTALL_KEEP_DATA', "Nech�va� d�ta v tabu�k�ch pri odin�talovan�. Za�krtnite t�to mo�nos�, ak rob�te napr�klad prechod na vy��iu verziu a nechcete pr�s� o svoje d�ta.");

/* email reports */
DEFINE('_JW_DESC_EMAIL_REPORTS_ENABLED', "Dostanete no�n� emailov� reporty za predch�dzaj�ci de�, ktor� si m��ete pre��ta� r�no");
DEFINE('_JW_DESC_EMAIL_REPORTS_ADDRESS', "Emailov� adresa na ktor� zasiela� tieto emailov� reporty");
DEFINE('_JW_DESC_EMAIL_PERCENT_HIGHER_THAN', "Do emailov�ch reportov zahrn�� iba riadky, kde percentu�lna hodnota je vy��ia ako {vami zadan� hodnota}. Nastavte na 0, ak chcete zobrazova� v�etky z�znamy <i>(Pr�klad: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_POSITIVE', "Do emailov�ch reportov zahrn�� iba riadky, kde pozit�vna percentu�lna hodnota pre jednod�ov� zmenu je vy��ia ako {vami zadan� hodnota}. Nastavte na 0, ak chcete zobrazova� v�etky z�znamy <i>(Pr�klad: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_NEGATIVE', "Do emailov�ch reportov zahrn�� iba riadky, kde negat�vna percentu�lna hodnota pre jednod�ov� zmenu je ni��ia ako {vami zadan� hodnota}. Nastavte na 0, ak chcete zobrazova� v�etky z�znamy <i>(Pr�klad: -5)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_POSITIVE', "Do emailov�ch reportov zahrn�� iba riadky, kde pozit�vna percentu�lna hodnota pre sedemd�ov� zmenu je vy��ia ako {vami zadan� hodnota}. Nastavte na 0, ak chcete zobrazova� v�etky z�znamy <i>(Pr�klad: 5)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_NEGATIVE', "Do emailov�ch reportov zahrn�� iba riadky, kde negat�vna percentu�lna hodnota pre sedemd�ov� zmenu je ni��ia ako {vami zadan� hodnota}. Nastavte na 0, ak chcete zobrazova� v�etky z�znamy <i>(Pr�klad: -5)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_POSITIVE', "Do emailov�ch reportov zahrn�� iba riadky, kde pozit�vna percentu�lna hodnota pre dvadsa�osemd�ov� zmenu je vy��ia ako {vami zadan� hodnota}. Nastavte na 0, ak chcete zobrazova� v�etky z�znamy <i>(Pr�klad: 5)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_NEGATIVE', "Do emailov�ch reportov zahrn�� iba riadky, kde negat�vna percentu�lna hodnota pre dvadsa�osemd�ov� zmenu je ni��ia ako {vami zadan� hodnota}. Nastavte na 0, ak chcete zobrazova� v�etky z�znamy <i>(Pr�klad: -5)</i>");

DEFINE('_JW_DESC_FRONTEND_NOFOLLOW', "<b>(funk�n� v PRO verzii)</b> Povo�te, ak chcete vidie� logo JoomlaWatch na va�ich str�nkach s atrib�tom rel='nofollow' ");
DEFINE('_JW_DESC_EMAIL_NAME_TRUNCATE', "Maximum znakov riadku pre emailov� report. Zme�te toto nastavenie, ak okno v�ho emailov�ho klienta je pr�li� �zke");

DEFINE('_JW_MENU_HISTORY', "Hist�ria");
DEFINE('_JW_MENU_EMAILS', "Emaily");
DEFINE('_JW_MENU_STATUS', "Status");
DEFINE('_JW_DESC_BLOCKED',"Tieto IP adresy boli blokovan� anti-spamom");


DEFINE('_JW_HISTORY_VISITORS',"Hist�ria n�v�tev");
DEFINE('_JW_HISTORY_SHOWING_ONLY', "Uk�za� len %d z�znamov.
                Pre zmenenie tejto hodnoty, cho�te do nastaven� -&gt; Hist�ria &amp; V�konnos� -&gt; 'Maximum po�tu n�v�tev'. Toto nastavenie m� vplyv na r�chlos� na��tavania d�t.");
DEFINE('_JW_MENU_BUG', "Vyreportujte chybu");
DEFINE('_JW_MENU_FEATURE', "Navrhnite nov� funkcionalitu");

DEFINE('_JW_VISITS_CAME_FROM_KEYWORDS',"K���ov� slov�");

DEFINE('_JW_BLOCKING_UNBLOCK',"odblokuj");
DEFINE('_JW_STATS_KEYPHRASE ',"K���ov� slov�");
DEFINE('_JW_STATUS_DATABASE',"Status datab�zy");

DEFINE('_JW_STATUS_DATABASE_TABLE_NAME',"n�zov tabu�ky");
DEFINE('_JW_STATUS_DATABASE_ROWS',"riadky");
DEFINE('_JW_STATUS_DATABASE_DATA',"d�ta");
DEFINE('_JW_STATUS_DATABASE_TOTAL',"celkovo");

DEFINE('_JW_EMAIL_REPORTS',"Emailov� reporty");
DEFINE('_JW_EMAIL_REPORT_GENERATED',"Generovan� filtrovan� email reporty zo v�eraj�ka");
DEFINE('_JW_EMAIL_REPORTS_VALUE_FILTERS',"Filtre v emailov�ch adres�ch");
DEFINE('_JW_EMAIL_REPORTS_VALUE',"hodnota");
DEFINE('_JW_EMAIL_REPORTS_PERCENT',"percento");
DEFINE('_JW_EMAIL_REPORTS_1DAY_CHANGE',"1-d�ov� zmena");
DEFINE('_JW_EMAIL_REPORTS_7DAY_CHANGE',"7-d�ov� zmena");
DEFINE('_JW_EMAIL_REPORTS_28DAY_CHANGE',"28-d�ov� zmena");
DEFINE('_JW_ANTISPAM_BLOCKED',"JoomlaWatch zaoblokoval %d spam pokusov dnes, celkovo: %d");
DEFINE('_JW_ANTISPAM_ADDRESSES',"Zablokovan� IP adresy");
DEFINE('_JW_ANTISPAM_SETTINGS',"Anti-Spam nastavenia");
DEFINE('_JW_TRAFFIC_AJAX',"d�ta prenesen� AJAX updatmi");


DEFINE('_JW_HISTORY_PREVIOUS',"predch�dzaj�ce");
DEFINE('_JW_HISTORY_NEXT',"nasleduj�ce");

/** additional translation for 1.2.11 for countries in more rows */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_COLUMNS',"Po�et st�pcov vlajok kraj�n na str�nke");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_ROWS',"Po�et riadkov vlajok kraj�n na str�nke");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NAMES',"Zobrazova� men� flajok kraj�n");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FLAGS_FIRST',"Zobraz vlajky kraj�n ako prv�, a� tak percent�");

/* JoomlaWatch 1.2.14 translations */

DEFINE('_JW_GOALS_GET_INVERSED', "neg�cia podmienky parametru z premenn�ch poslan�ch cez HTTP GET");
DEFINE('_JW_GOALS_POST_INVERSED', "neg�cia podmienky parametru z premenn�ch poslan�ch cez HTTP POST");
DEFINE('_JW_GOALS_TITLE_INVERSED', "neg�cia podmienky N�zov str�nky");
DEFINE('_JW_GOALS_USERNAME_INVERSED', "neg�cia podmienky Pou��vate�sk� meno");
DEFINE('_JW_GOALS_CAME_FROM_INVERSED', "neg�cia podmienky Pri�iel z ...");

DEFINE('_JW_STATS_MAP', "Mapa poslednej n�v�tevy");
DEFINE('_JW_STATS_MAP_ENTER_KEY',"Pros�m vlo�te <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a> aktiva�n� k��� pre zobrazenie mapy:");
DEFINE('_JW_STATS_MAP_STORE_KEY',"ulo�");
DEFINE('_JW_STATS_MAP_INVALID_KEY',"Pros�m zadajte platn� ipinfodb k���, ktor� ste z�skali z: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");

DEFINE('_JW_SIZEQUERY_BAD_REQUEST',"ZL� PO�IADAVKA: ");

DEFINE('_JW_VISIT_SUBMITED_FIELDS',"D�ta poslan� z formul�ra:");
DEFINE('_JW_VISIT_URL_PARAMETERS',"URL parametre:");
DEFINE('_JW_VISIT_ADD_PAGE'," Pridaj str�nku ako cie�");
DEFINE('_JW_VISIT_BLOCK_IP'," Blokuj t�to IP adresu");
DEFINE('_JW_VISIT_SUBMITED_FROM_VARIABLE'," Pridaj t�to hodnotu poslan� z formul�ra ako cie�");
DEFINE('_JW_VISIT_URL_PARAMETER_GOAL'," Pridaj tento URL parameter ako cie�");

DEFINE('_JW_TREND_EMPTY',"Pr�zdne");

DEFINE('_JW_NOT_NUMBER'," UPOZORNENIE: Hodnota ktor� ste zadali, nie je ��slo. JoomlaWatch nebude fungova� korektne!");
DEFINE('_JW_EVALUATION_LEFT',"&nbsp; Toto je 15-d�ov� sk��obn� verzia. Po�et dn� do konca: <b>%d</b>. Pros�m objednajte si celo�ivotn� licenciu na <a href='http://www.codegravity.com/donate/joomlawatch/' target='_blank'>JoomlaWatch licencia pre va�u dom�nu</a> pre t�to a nasleduj�ce verzie.");
DEFINE('_JW_TRIAL_VERSION_EXPIRED'," Va�a trial verzia expirovala. Pros�m k�pte si licenciu");

DEFINE('_JW_CONFIG_LICENSE_ACTIVATED',"Licencia aktivovan� �spe�ne. �akujeme");
DEFINE('_JW_CONFIG_LICENCE_DONT_MATCH',"<b>Chyba: licen�n� k��� a va�a dom�na sa nezhoduj�.</b><br/>
Naozaj ste vlo�ili spr�vny n�zov dom�ny do aktiva�n�ho dial�gu? Pros�m kontaktujte: info@codegravity.com");

DEFINE('_JW_VIEW_ADMINBODY_LONG_MESSAGE',"Ak vid�te t�to spr�vu pr�li� dlho, nastavenie va�ej dom�ny m��e by� nespr�vne.
                    Otvorte components/com_joomlawatch/config.php
                    odkomentujte, a zme�te n�zov va�ej dom�ny. Eg.:
                    define('JOOMLAWATCH_LIVE_SITE', 'http://www.codegravity.com');");

DEFINE('_JW_ADMINBODY_LIVE_SITE',"Upozornenie: str�nka vo va�om browseri %s a v konfigur�cii %s sa nezohoduj�.");
DEFINE('_JW_ADMINBODY_SET_LIVE_SITE',"Nastavte dom�nu na: %s a pokra�ujte...");

DEFINE('_JW_ADMINHEADER_JW',"JoomlaWatch ");
DEFINE('_JW_ADMINHEADER_REMOVE_BACKLINK',"Odstr�ni� sp�tn� odkaz");
DEFINE('_JW_ADMINHEADER_KNOWLEDGE_BASE',"B�za znalost�");
DEFINE('_JW_ADMINHEADER_FLOW',"Tok n�v�tev");
DEFINE('_JW_ADMINHEADER_GRAPHS',"Grafy");
DEFINE('_JW_ADMINHEADER_COMPONENTS',"Komponenty");
DEFINE('_JW_ADMINHEADER_REVIEW',"Posudok");
DEFINE('_JW_ADMINHEADER_WRITE',"Nap��te ");

DEFINE('_JW_FLOW_TRAFFIC',"Tok n�v�tev");
DEFINE('_JW_FLOW_SELECT_PAGE',"Zvo�te str�nku:");
DEFINE('_JW_FLOW_OUTG_LINKS',"Max. po�et liniek z ka�dej str�nky:");
DEFINE('_JW_FLOW_NESTING',"Level vnorenia:");
DEFINE('_JW_FLOW_SCALE',"�k�la:");

DEFINE('_JW_COMERCIAL_AD_FREE',"Verzia bez rekl�m");
DEFINE('_JW_COMERCIAL_THANK_DONATION',"�akujeme v�m za v� pr�spevok!");
DEFINE('_JW_COMERCIAL_REGISTRATION_KEY',"Registra�n� k��� pre va�u dom�nu %s je: ");
DEFINE('_JW_COMERCIAL_BACKLINKS_REMOVE',"Teraz m��te skry� JoomlaWatch logo na str�nke z nastaven�");

DEFINE('_JW_SIZES_LAST_CHECK',"Posledn� kontrola bola vykonan�:");
DEFINE('_JW_SIZES_ADMINISTRATOR',"BLUE = Ve�kos� komponentu/modulu v /administrator adres�ri");

DEFINE('_JW_SIZECOMPONENTS_COMPONENT',"Komponent");
DEFINE('_JW_SIZECOMPONENTS_TOTAL',"Celkovo:");
DEFINE('_JW_SIZECOMPONENTS_SIZE',"Ve�kos�");
DEFINE('_JW_SIZECOMPONENTS_REFRESH_ALL',"Obnovi� v�etko");

DEFINE('_JW_SIZEDATABASE_TABLE',"Tabu�ka");
DEFINE('_JW_SIZEDATABASE_SIZE',"Ve�kos�");
DEFINE('_JW_SIZEDATABASE_1DAY',"1-d�ov� zmena");
DEFINE('_JW_SIZEDATABASE_7DAY',"7-d�ov� zmena");
DEFINE('_JW_SIZEDATABASE_28DAY',"28-d�ov� zmena");
DEFINE('_JW_SIZEDATABASE_NO_DATA',"�iadne d�ta");
DEFINE('_JW_SIZEDATABASE_TOTAL',"Celkovo:");

DEFINE('_JW_SIZEMODULES_REFRESH_ALL',"Obnovi� v�etko");
DEFINE('_JW_SIZEMODULES_TOTAL',"Celkovo:");
DEFINE('_JW_SIZEMODULES_MODULE',"Modul");
DEFINE('_JW_SIZEMODULES_SIZE',"Ve�kos�");

DEFINE('_JW_SIZES_FILES',"S�bory a adres�re");
DEFINE('_JW_SIZES_BYTES',"bajty");
DEFINE('_JW_SIZES_KB',"KB");
DEFINE('_JW_SIZES_MB',"MB");
DEFINE('_JW_SIZES_GB',"GB");
DEFINE('_JW_SIZES_REFRESH',"Obnovi�");

DEFINE('_JW_STATS_FOOTER',"JoomlaWatch &copy;2006-@YEAR@ by Matej Koval");

DEFINE('_JW_STATUS_MB',"MB");

DEFINE('_JW_DESC_IPINFODB_KEY',"Aktiva�n� k��� pre mapu poslednej n�v�tevy z : <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");
DEFINE('_JW_SETTINGS_FORCE_TIMEZONE_OFFSET',"Nastav nasilu rozdiel �asov�ch p�siem");

/* JoomlaWatch 1.2.17 translations */
DEFINE('_JW_MENU_UPDATE', "Aktualizuj");
DEFINE('_JW_MENU_UPDATE_TITLE', "Z�lohuj a obnov");
DEFINE('_JW_ADMINHEADER_NA_IN_THIS_VERSION',"Nefunk�n� vo free verzii, pros�m pozrite si z�lo�ku licenci�");
DEFINE('_JW_SPAMWORD_BANS_ENABLED', "Blokuj na z�klade nevhodn�ch slov");
DEFINE('_JW_SPAMWORD_LIST', "Zoznam nevhodn�ch slov");
DEFINE('_JW_HIDE_REPETITIVE_TITLE', "Skry opakuj�ce s titulky str�nok");
DEFINE('_JW_TRUNCATE_VISITS', "Skracuj slov� n�tev");
DEFINE('_JW_TRUNCATE_STATS', "Skracuj slov� �tatistiky");
DEFINE('_JW_TRUNCATE_GOALS', "Skracuj ciele");
DEFINE('_JW_LIMIT_BOTS', "Max. po�et robotov");
DEFINE('_JW_LIMIT_VISITORS', "Max. po�et n�v�tev");
DEFINE('_JW_TOOLTIP_WIDTH', "��rka vyskakuj�ceho okna");
DEFINE('_JW_TOOLTIP_HEIGHT', "V��ka vyskakuj�ceho okna");
DEFINE('_JW_TOOLTIP_URL', "URL Adresa vyskakovacieho okna");
DEFINE('_JW_TOOLTIP_ONCLICK', "Otvori� vyskakovacie okno pri kliku");
DEFINE('_JW_IP_STATS', "�tatistiky IP adries");
DEFINE('_JW_IPINFODB_KEY', "K��� z ipinfodb.com");
DEFINE('_JW_ONLY_LAST_URI', "Iba posledn� URI");

DEFINE('_JW_FRONTEND_HIDE_LOGO', "Skry logo na str�nkach ");
DEFINE('_JW_FRONTEND_NOFOLLOW', "No Follow pre linku na str�nkach");
DEFINE('_JW_FRONTEND_NO_BACKLINK', "�iadny sp�tn� odkaz na str�nkach");
DEFINE('_JW_FRONTEND_USER_LINK', "Linka na detail pou��vate�a z modulu registrovan�ch pou��vate�ov");
DEFINE('_JW_FRONTEND_COUNTRIES_FIRST', "vlajky kraj�n ako prv�");
DEFINE('_JW_FRONTEND_COUNTRIES_NAMES', "zobrazova� men� vlajok kraj�n");
DEFINE('_JW_FRONTEND_COUNTRIES_UPPERCASE', "men� vlajok kraj�n ve�k�mi p�smenami");
DEFINE('_JW_FRONTEND_COUNTRIES_FLAGS_FIRST', "vlajky kraj�n ako prv�");
DEFINE('_JW_FRONTEND_COUNTRIES_NUM', "po�et vlajok kraj�n");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_COLUMNS', "maxim�lny po�et st�pcov vlajok kraj�n");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_ROWS', "maxim�lny po�et riadkov vlajok kraj�n");
DEFINE('_JW_FRONTEND_VISITORS_TODAY', "po�et n�v�tevn�kov dnes ");
DEFINE('_JW_FRONTEND_VISITORS_YESTERDAY', "po�et n�v�tevn�kov v�era ");
DEFINE('_JW_FRONTEND_VISITORS_THIS_WEEK', "po�et n�v�tevn�kov tento t��de� ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_WEEK', "po�et n�v�tevn�kov minul� t��de� ");
DEFINE('_JW_FRONTEND_VISITORS_THIS_MONTH', "po�et n�v�tevn�kov tento mesiac");
DEFINE('_JW_FRONTEND_VISITORS_LAST_MONTH', "po�et n�v�tevn�kov minul� mesiac");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL', "po�et n�v�tevn�kov celkovo");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL	', "po�et n�v�tevn�kov - �vodn� ��slo");
DEFINE('_JW_HISTORY_MAX_VALUES', "Max. hodnoty v hist�rii");
DEFINE('_JW_HISTORY_MAX_DB_RECORDS', "Max. po�et z�znamov v hist�rii");
DEFINE('_JW_UPDATE_TIME_VISITS', "Po�et sek�nd obnovovania n�v�tev v re�lnom �ase");
DEFINE('_JW_UPDATE_TIME_STATS', "Po�et sek�nd obnovovania �tatist�k v re�lnom �ase");
DEFINE('_JW_STATS_MAX_ROWS', "Max. po�et riadkov v �tatistike");
DEFINE('_JW_STATS_IP_HITS', "Zobrazova� IP adresy v �tatistike");
DEFINE('_JW_MAXID_BOTS', "Max. po�et robotov");
DEFINE('_JW_MAXID_VISITORS', "Max. po�et n�v�tevn�kov");
DEFINE('_JW_STATS_KEEP_DAYS', "Max. po�et dn� pre ktor� uchov�va� �tatistiky");
DEFINE('_JW_CACHE_FRONTEND_COUNTRIES', "Po�et sek�nd pre ke�ovanie vlajok kraj�n na str�nkach");
DEFINE('_JW_CACHE_FRONTEND_VISITORS', "Po�et sek�nd pre ke�ovanie n�v�tevn�kov na str�nkach");

DEFINE('_JW_UNINSTALL_KEEP_DATA	', "Ponecha� d�ta po odin�talovan�");
DEFINE('_JW_IGNORE_IP', "Ignoruj IP adresu");
DEFINE('_JW_IGNORE_URI', "Ignoruj URI (str�nku)");
DEFINE('_JW_IGNORE_USER', "Ignoruj pou��vate�a");
DEFINE('_JW_BLOCKING_MESSAGE', "Spr�va zobrazen� ke� je pou��vate� zablokovan�");
DEFINE('_JW_SERVER_URI_KEY', "parameter PHP premennej SERVER odkia� sa berie adresa URI");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL', "po�et n�v�tevn�kov - �vodn� ��slo");
DEFINE('_JW_SIZEDATABASE_RECORDS', "Z�znamy");
/***********EDITs******************/
DEFINE('_JW_ANTISPAM_BLOCKING_TEXT'," Aby blokovanie fungovalo, mus�te JoomlaWatch agent modul umiestni� do poz�cie pred va��m obsahom.
Napr�klad na �avej strane va�ej �abl�ny
                    <br/>
                    Cho�te do Module Manager -> JoomlaWatch agent -> zvo�te poz�ciu left");
DEFINE('_JW_EMAIL_SEO_REPORTS', "SEO Reporty");
DEFINE('_JW_DESC_EMAIL_SEO_REPORTS_ENABLED',"SEO No�n� emaily povolen�");
DEFINE('_JW_WATCH_INSTALLATION_DEMO',"Pozrite si in�tala�n� demo");

?>