<?php


/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version @VERSION@
 * @revision @REVISION@
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) @YEAR@ by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/
defined( '_JEXEC' ) or die( 'Restricted access' );

#JoomlaWatch language file - to create a new language file, just copy the english.php to Örnek german.php and place into /components/com_joomlawatch/lang/

# Main Menu
DEFINE('_JW_MENU_STATS', "İstatistikler");
DEFINE('_JW_MENU_GOALS', "Hedefler");
DEFINE('_JW_MENU_SETTINGS', "Ayarlar");
DEFINE('_JW_MENU_CREDITS', "Yapımcılar");
DEFINE('_JW_MENU_FAQ', "SSS");
DEFINE('_JW_MENU_DOCUMENTATION', "Dökümantasyon");
DEFINE('_JW_MENU_LICENSE', "Lisans");
DEFINE('_JW_MENU_DONATORS', "Bağış Yapanlar");
DEFINE('_JW_MENU_SUPPORT', "Joomla Watch'u Destekle ve Yönetim Panelindeki Reklamları Kaldır.");

# Left visitors real-time window
DEFINE('_JW_VISITS_VISITORS', "Son Ziyaretçiler");
DEFINE('_JW_VISITS_BOTS', "Botlar");
DEFINE('_JW_VISITS_CAME_FROM', "Geldigi Yer");
DEFINE('_JW_VISITS_MODULE_NOT_PUBLISHED', "JoomlaWatch modülü henüz yayinda olmadığı için herhangi bir istatistik verisi bulunmamaktadır. Lütfen modülü kurup yayınlayınız.");
DEFINE('_JW_VISITS_PANE_LOADING', "Ziyaretler Yükleniyor...");

# Right stats window
DEFINE('_JW_STATS_TITLE', "Haftalık Ziyaret İstatistikleri");
DEFINE('_JW_STATS_WEEK', "hafta");
DEFINE('_JW_STATS_THIS_WEEK', "bu hafta");
DEFINE('_JW_STATS_UNIQUE', "tekil");
DEFINE('_JW_STATS_LOADS', "görüntüleme");
DEFINE('_JW_STATS_HITS', "hitler");
DEFINE('_JW_STATS_TODAY', "bugün");
DEFINE('_JW_STATS_FOR', "için");
DEFINE('_JW_STATS_ALL_TIME', "Tüm zamanlar");
DEFINE('_JW_STATS_EXPAND', "genişlet");
DEFINE('_JW_STATS_COLLAPSE', "Portatif");
DEFINE('_JW_STATS_URI', "Sayfalar");
DEFINE('_JW_STATS_COUNTRIES', "Ülkeler");
DEFINE('_JW_STATS_USERS', "Kullanıcılar");
DEFINE('_JW_STATS_REFERERS', "Referanslar");
DEFINE('_JW_STATS_IP', "IPler");
DEFINE('_JW_STATS_BROWSER', "Tarayıcılar");
DEFINE('_JW_STATS_OS', "OS");
DEFINE('_JW_STATS_KEYWORDS', "Anahtar Kelimeler");
DEFINE('_JW_STATS_GOALS', "Hedefler");
DEFINE('_JW_STATS_TOTAL', "Toplam");
DEFINE('_JW_STATS_DAILY', "Günlük");
DEFINE('_JW_STATS_DAILY_TITLE', "Günlük İstatistikler");
DEFINE('_JW_STATS_ALL_TIME_TITLE', "Tüm zamanlarin istatistikleri");
DEFINE('_JW_STATS_LOADING', "yükleniyor...");
DEFINE('_JW_STATS_LOADING_WAIT', "yükleniyor... lütfen bekleyiniz.");
DEFINE('_JW_STATS_IP_BLOCKING_TITLE', "IP Engelleme");
DEFINE('_JW_STATS_IP_BLOCKING_ENTER', "Elle IP Girisi");
DEFINE('_JW_STATS_IP_BLOCKING_MANUALLY', "Engellemek istediginiz IP numarasini girin. (örnek: 217.242.11.54, arama kriterlerini içeren tüm IPleri engellemek için; 217.* veya 217.242.*)");
DEFINE('_JW_STATS_IP_BLOCKING_TOGGLE', "Gerçekten engellemek istiyor musun ");
DEFINE('_JW_STATS_PANE_LOADING', "İstatistikler yükleniyor...");

# Settings
DEFINE('_JW_SETTINGS_TITLE', "Ayarlar");
DEFINE('_JW_SETTINGS_DEFAULT', "Varsayılan");
DEFINE('_JW_SETTINGS_SAVE', "Kaydet");
DEFINE('_JW_SETTINGS_APPEARANCE', "Görünüm");
DEFINE('_JW_SETTINGS_FRONTEND', "Ön Uç");
DEFINE('_JW_SETTINGS_HISTORY_PERFORMANCE', "Geçmiş  &amp; Performans");
DEFINE('_JW_SETTINGS_ADVANCED', "Gelişmiş");
DEFINE('_JW_SETTINGS_IGNORE', "Yoksay");
DEFINE('_JW_SETTINGS_BLOCKING', "Engelle");
DEFINE('_JW_SETTINGS_EXPERT', "Uzman");
DEFINE('_JW_SETTINGS_RESET_CONFIRM', "Tüm istatistik kayıtlarını gerçekten silmek istiyor musun?");
DEFINE('_JW_SETTINGS_RESET_ALL', "Tümünü Sil");
DEFINE('_JW_SETTINGS_RESET_ALL_LINK', "Tüm istatistikleri &amp; ziyaretçi bilgisini sil");
DEFINE('_JW_SETTINGS_LANGUAGE', "Dil");
DEFINE('_JW_SETTINGS_SAVED', "Ayarlar kaydedildi");
DEFINE('_JW_SETTINGS_ADD_YOUR_IP', "Kendi IP numarani ekle");
DEFINE('_JW_SETTINGS_TO_THE_LIST', "listeye");

# Other / mostly general
DEFINE('_JW_TITLE', "Gerçek zamanlı AJAX Joomla ekranı");
DEFINE('_JW_BACK', "Geri");
DEFINE('_JW_ACCESS_DENIED', "Bu içeriği görme izinin yok!");
DEFINE('_JW_LICENSE_AGREE', "Sözleşmeyi okudum ve kabul ediyorum &amp; sözleşme yukarıda");
DEFINE('_JW_LICENSE_CONTINUE', "Devam et");
DEFINE('_JW_SUCCESS', "İşlem başarılı");
DEFINE('_JW_RESET_SUCCESS', "Tüm istatistik verileri ve ziyaretçi bilgileri başarıyla silindi.");
DEFINE('_JW_RESET_ERROR', "Veri tamamen silinemedi bir hata var.");
DEFINE('_JW_CREDITS_TITLE', "Yapımcılar");
DEFINE('_JW_TRENDS_DAILY_WEEKLY', "Günlük ve haftalık istatistikleri");
DEFINE('_JW_AJAX_PERMISSION_DENIED_1', "AJAX kabul edilmedi: Bu istatistiklere joomlanın configuration.php dosyasında belirlenen adresten erişebilirsiniz. ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_2', "Belki de alan adınızın önüne www. eklemeyi unuttunuz. Javascriptiniz ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_3', "dosyasına");
DEFINE('_JW_AJAX_PERMISSION_DENIED_4', "alan adının farklı olduğunu düşünmesine sebep olan adresinden erişmeyi deniyor.");

# Header
DEFINE('_JW_HEADER_DOWNLOAD', "Son eklenti kodunu al");
DEFINE('_JW_HEADER_CAST_YOUR', "Bize");
DEFINE('_JW_HEADER_VOTE', "oy ver");

# Tooltips
DEFINE('_JW_TOOLTIP_CLICK', "İpuçlarini görmek için tıkla");
DEFINE('_JW_TOOLTIP_MOUSE_OVER', "Tooltipi göstermek için fareyi üstüne getir");
DEFINE('_JW_TOOLTIP_YESTERDAY_INCREASE', "dünkü artış");
DEFINE('_JW_TOOLTIP_HELP', "Harici online yardım dökümanını aç");
DEFINE('_JW_TOOLTIP_WINDOW_CLOSE', "Pencereyi kapat");
DEFINE('_JW_TOOLTIP_PRINT', "Çıktı al");

# Goals
DEFINE('_JW_GOALS_INSERT', "Yeni hedef gir");
DEFINE('_JW_GOALS_UPDATE', "Hedef numarasını değiştir.");
DEFINE('_JW_GOALS_ACTION', "Eylem");
DEFINE('_JW_GOALS_TITLE', "Yeni Hedef");
DEFINE('_JW_GOALS_NEW', "Yeni Hedef");
DEFINE('_JW_GOALS_RELOAD', "Tekrar Yükle");
DEFINE('_JW_GOALS_ADVANCED', "Gelişmiş");
DEFINE('_JW_GOALS_NAME', "İsim");
DEFINE('_JW_GOALS_ID', "Kimlik");
DEFINE('_JW_GOALS_URI_CONDITION', "URL Durumu");
DEFINE('_JW_GOALS_GET_VAR', "Alma");
DEFINE('_JW_GOALS_GET_CONDITION', "Alma Durumu");
DEFINE('_JW_GOALS_POST_VAR', "Gönderme");
DEFINE('_JW_GOALS_POST_CONDITION', "Gönderme Durumu");
DEFINE('_JW_GOALS_TITLE_CONDITION', "Başlık Durumu");
DEFINE('_JW_GOALS_USERNAME_CONDITION', "Kullanıcı Durumu");
DEFINE('_JW_GOALS_IP_CONDITION', "IP Durumu");
DEFINE('_JW_GOALS_CAME_FROM_CONDITION', "Gelen Kaynak Durumu");
DEFINE('_JW_GOALS_BLOCK', "Engelleme");
DEFINE('_JW_GOALS_REDIRECT', "Yönlendirilen URL");
DEFINE('_JW_GOALS_HITS', "Hitler");
DEFINE('_JW_GOALS_ENABLED', "Aktif");
DEFINE('_JW_GOALS_EDIT', "Düzenle");
DEFINE('_JW_GOALS_DELETE', "Sil");
DEFINE('_JW_GOALS_DELETE_CONFIRM', "Bu hedef için tüm istatistikler silinecek. Gerçekten silmek istiyor musun?");

# Frontend
DEFINE('_JW_FRONTEND_COUNTRIES', "Ülkeler");
DEFINE('_JW_FRONTEND_VISITORS', "Ziyaretçiler");
DEFINE('_JW_FRONTEND_TODAY', "Bugün");
DEFINE('_JW_FRONTEND_YESTERDAY', "Dün");
DEFINE('_JW_FRONTEND_THIS_WEEK', "Bu Hafta");
DEFINE('_JW_FRONTEND_LAST_WEEK', "Geçen Hafta");
DEFINE('_JW_FRONTEND_THIS_MONTH', "Bu Ay");
DEFINE('_JW_FRONTEND_LAST_MONTH', "Geçen Ay");
DEFINE('_JW_FRONTEND_TOTAL', "Toplam");

# Settings description - quite long
DEFINE('_JW_DESC_DEBUG', "JoomlaWatch hata ayıklama modunda. Bu şekilde hatanın nedenini bulabilirsiniz. Kapatmak için, /components/com_joomlawatch/config.php dosyasında JOOMLAWATCH_DEBUG değerini 1 yerine 0 yapın");
DEFINE('_JW_DESC_STATS_MAX_ROWS', "İstatistikler genişletilmiş moda alındığında azami kaç satır gösterileceği.");
DEFINE('_JW_DESC_STATS_IP_HITS', "Önceki günlerde, girilen değerden daha az hite sahip olan tüm IP adresleri, IP geçmişinden silinecek.");
DEFINE('_JW_DESC_STATS_URL_HITS', "Önceki günlerde, girilen değerden daha az hite sahip olan tüm URLler, IP geçmişinden silinecek.");
DEFINE('_JW_DESC_IGNORE_IP', "Belirli IPleri istatistiklerin dışında tut. Yeni bir satır ile ayır. Burada arama kriterleri kullanılabilir. <br/>Örnek: 192.* girmek, 192.168.51.31, 192.168.16.2, gibi adresleri yoksayacaktır.");
DEFINE('_JW_DESC_UPDATE_TIME_VISITS', "Ziyaretçinin milisaniye cinsinden yenileme süresi, lütfen dikkatli kullanınız (öntanımlı süre 2000). Ardından JoomlaWatch arka ucunu yeniden yükleyiniz.");
DEFINE('_JW_DESC_UPDATE_TIME_STATS', "İstatistiklerin milisaniye cinsinden yenileme süresi, lütfen dikkatli kullanınız (öntanımlı süre 4000). Ardından JoomlaWatch arka ucunu yeniden yükleyiniz.");
DEFINE('_JW_DESC_MAXID_BOTS', "Veritabanında tutulacak bot ziyaret kaydı sayısı.");
DEFINE('_JW_DESC_MAXID_VISITORS', "Veritabanında tutulacak gerçek ziyaret sayısı.");
DEFINE('_JW_DESC_LIMIT_BOTS', "Arka uçta görüntülenecek olan bot sayısı.");
DEFINE('_JW_DESC_LIMIT_VISITORS', "Arka uçta görüntülenecek olan gerçek ziyaretçi sayısı.");
DEFINE('_JW_DESC_TRUNCATE_VISITS', "Uzun başlık ve URLlerde gösterilecek azami karakter sayısı.");
DEFINE('_JW_DESC_TRUNCATE_STATS', "İstatistik panelinde gösterilecek azami karakter sayısı.");
DEFINE('_JW_DESC_STATS_KEEP_DAYS', "Veritabanında istatistiklerin kaç gün tutulacağı, 0 = sonsuz.");
DEFINE('_JW_DESC_TIMEZONE_OFFSET', "Suncudan farklı bir saat diliminde bulunduğunuzda. (saat olarak artı veya eksi değer)");
DEFINE('_JW_DESC_WEEK_OFFSET', "Hafta düzenlemesi, zaman damgası/(3600*24*7) 1.1.1970 tarihinden itibaren hafta numarası verir, bu düzenleme haftanın pazartesi günü ile başlamasını sağlar ");
DEFINE('_JW_DESC_DAY_OFFSET', "Gün düzenlemesi, zaman damgası/(3600*24) 1.1.1970 tarihinden itibaren gün numarası verir, bu düzenleme günün 00:00'da başlamasını sağlar ");
DEFINE('_JW_DESC_FRONTEND_HIDE_LOGO', "<b>(PRO sürümde çalışır)</b> Ön uçta 1x1px boş simge kullanmayı sağlar");
DEFINE('_JW_DESC_IP_STATS', "IP adresi istatistiklerini etkinleştirir. Bazı ülkelerde IP adresini veritabanında uzun süre tutmak yasalara aykırıdır. Kullanımda sorumluluk size aittir.");
DEFINE('_JW_DESC_HIDE_ADS', "Bu ayar, sizi rahatsız etmeleri durumunda arka uçtaki reklamları gizler. Reklamların orada kalmasını sağlayarak bu aracın gelişmesine katkıda bulunmuş olursunuz. Teşekkürler");
DEFINE('_JW_DESC_TOOLTIP_ONCLICK', "Araç bilgisinin fareye tıklamak yerine, üzerine geldiğinde görüntülenmesini istiyorsanız işareti kaldırın.");
DEFINE('_JW_DESC_SERVER_URI_KEY', "Öntanımlı olan 'REDIRECT_URL'dir, url yeniden yazma özelliğini kullanıyorsanız bu zaten standarttır. Eğer sadece index.php'nin kayıtları tutuluyorsa, 'SCRIPT_URL' olarak değiştirilebilir.");
DEFINE('_JW_DESC_BLOCKING_MESSAGE', "Engellenen kullanıcıya gösterilen veya kullanıcıların neden engellendiğine dair detaylı bilgi mesajı.");
DEFINE('_JW_DESC_TOOLTIP_WIDTH', "Araç bilgisi genişliği");
DEFINE('_JW_DESC_TOOLTIP_HEIGHT', "Araç bilgisi yüksekliği");
DEFINE('_JW_DESC_TOOLTIP_URL', "Ziyaretçinin IPsini görselleştirmek için, buraya herhangi bir URL girebilirsiniz. {ip} kullanıcının IPsi ile değiştirilecektir. Örnek: http://somewebsite.com/query?iplookup={ip}");
DEFINE('_JW_DESC_IGNORE_URI', "İstatistiklerin yoksaymasını istediğiniz adresleri yazabilirsiniz. Kriterler kullanabilirsiniz (* ve ?). Örnek: /freel?n* ");
DEFINE('_JW_DESC_GOALS_NAME', "Buraya bir hedef ismi girin. Bu isim istatistiklerde görünecek.");
DEFINE('_JW_DESC_GOALS_URI_CONDITION', "Alan adınızın ardından gelen herşey. http://www.codegravity.com/projects/ adresi için URI: /projects/ (Örnek: <b>/projects*</b>)");
DEFINE('_JW_DESC_GOALS_GET_VAR', "GET değişkeni, URLde genelde ? veya &amp; işaretleri ardından görebileceğiniz bir değişkendir. Örnek: http://www.codegravity.com/index.php?<u>name</u>=peter&amp;<u>surname</u>=smith. Aynı zamanda <u>*</u> bu alandaki tüm get değerlerini tarayabilirsiniz. (Örnek: <b>n*me</b>)");
DEFINE('_JW_DESC_GOALS_GET_CONDITION', "Burada bir önceki alandan alınan değeri sağlayan bir değer girmelisiniz. (Örnek: <b>p?t*r</b>) ");
DEFINE('_JW_DESC_GOALS_POST_VAR', "Benzer şekilde, formlardan gelen değerleri de kontrol ediyoruz. Sitenizde form varsa, şu şekilde bir alana sahiptir  &lt;input type='text' name='<u>experiences</u>' /&gt; ve burada da arama kriterlerini kullanabilirsiniz.. (Örnek: <b>exper*ces</b>)");
DEFINE('_JW_DESC_GOALS_POST_CONDITION', "POST alanından değer için bir eşleşme. Örnek: Eğer kullanıcıların java tecrübesi olup olmadığını kontrol etmek istersek, <b>*java*</b>");
DEFINE('_JW_DESC_GOALS_TITLE_CONDITION', "Eşleşmesi gereken sayfanın başlığı. (Örnek: <b>*serbest çalışan programcılar*</b>)");
DEFINE('_JW_DESC_GOALS_USERNAME_CONDITION', "Giriş yapmış olan kullanıcının adı. (örnek: <b>ahmetyılmaz*</b>)");
DEFINE('_JW_DESC_GOALS_IP_CONDITION', "Kullanıcının geldiği IP adresi: (Örnek: <b>201.9?.*.*</b>)");
DEFINE('_JW_DESC_GOALS_CAME_FROM_CONDITION', "Kullanıcının geldiği adres. (Örnek: <b>*www.google.*</b>)");
DEFINE('_JW_DESC_GOALS_REDIRECT', "Kullanıcı, tarafınızdan belirlenen bir adrese yönlendirildi. 'Engelleme'den daha yüksek önceliği vardır: (Örnek: <b>http://www.codegravity.com/goaway.html</b>)");
DEFINE('_JW_DESC_TRUNCATE_GOALS', "Hedef tablosunda kaç adet karakterin eksiltileceği");
DEFINE('_JW_DESC_FRONTEND_NO_BACKLINK', "<b>(PRO sürümde çalışır)</b> codegravity.com adresine olan bağlantıyı kaldırabilirsiniz, ancak bunu yapmazsanız mutluluk duyarız. Teşekkürler");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES', "Ön uçta ülkelerin toplam istatistiklerini görüntüle. Eğer değiştirilrse, bu ayar CACHE_FRONTEND_ süresi ayarlandıktan sonra ön uçta etkin olacaktır. ");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FIRST', "Eğer ön uçta Ziyaretçi/Ülke sıralamasını değiştirmek istiyorsanız işareti kaldırın, Ziyaretçiler daha önce görünecektir.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NUM', "Ön uçta gösterilmesini istediğiniz ülke sayısı");
DEFINE('_JW_DESC_FRONTEND_VISITORS', "Ön uçta ülkelerden gelen ziyaretçileri göster. Eğer değiştirilrse, bu ayar CACHE_FRONTEND_ süresi ayarlandıktan sonra ön uçta etkin olacaktır. ");
DEFINE('_JW_DESC_CACHE_FRONTEND_COUNTRIES', "Ön uçtaki tüm ülke verilerinin önbelleğe alınması için saniye cinsinden geçen süre");
DEFINE('_JW_DESC_CACHE_FRONTEND_VISITORS', "Ön uçtaki tüm ziyaretçi verilerinin önbelleğe alınması için saniye cinsinden geçen süre");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TODAY', "Bugünkü ziyaretçilerin ön uçta gösterilmesi. Eğer değiştirilrse, bu ayar CACHE_FRONTEND_... süresi ayarlandıktan sonra ön uçta etkin olacaktır.");
DEFINE('_JW_DESC_FRONTEND_VISITORS_YESTERDAY', "Dünkü ziyaretçilerin ön uçta gösterilmesi.. Eğer değiştirilrse, bu ayar CACHE_FRONTEND_... süresi ayarlandıktan sonra ön uçta etkin olacaktır.");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_WEEK', "Bu haftaki ziyaretçilerin ön uçta gösterilmesi. Eğer değiştirilrse, bu ayar CACHE_FRONTEND_... süresi ayarlandıktan sonra ön uçta etkin olacaktır.");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_WEEK', "Geçen haftaki ziyaretçilerin ön uçta gösterilmesi. Eğer değiştirilrse, bu ayar CACHE_FRONTEND_... süresi ayarlandıktan sonra ön uçta etkin olacaktır.");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_MONTH', "Bu ayki ziyaretçilerin ön uçta gösterilmesi. Eğer değiştirilrse, bu ayar CACHE_FRONTEND_... süresi ayarlandıktan sonra ön uçta etkin olacaktır.");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_MONTH', "Geçen ayki ziyaretçilerin ön uçta gösterilmesi. Eğer değiştirilrse, bu ayar CACHE_FRONTEND_... süresi ayarlandıktan sonra ön uçta etkin olacaktır.");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL', "JoomlaWatch yüklemesinden bu yana toplam ziyaretçi sayısını göster. Eğer değiştirilrse, bu ayar CACHE_FRONTEND_... süresi ayarlandıktan sonra ön uçta etkin olacaktır.");
DEFINE('_JW_DESC_LANGUAGE', "Kullanılacak dil dosyasıları /components/com_joomlawatch/lang/ adresinde bulunur. Eğer yeni bir dil dosyası oluşturmak isterseniz, öncelikle projenin anasayfasını kontrol edin, eğer orada bulamazsanız, english dosyasını örneğin german.php ismi ile buraya kopyalayın. Ardından, sağda anahtar değerleri tercüme edebilirsiniz.");
DEFINE('_JW_DESC_GOALS', "Hedefler özel parametreler belirtmenize olanak sağlar. Bu parametreler eşleştiğinde, hedef sayacı yükselir. Bu şekilde kullanıcının belirli bir adresi ziyaret edip etmediğini, girilen belirli bir değeri, belirli bir kullanıcı adını, ya da belirli bir adresten gelenleri takip edebilirsiniz. Aynı zamanda bu kullanıcıları engelleyebilir, ya da onları başka bir adrese yönlendirebilirsiniz.");
DEFINE('_JW_DESC_GOALS_INSERT', "İsim haricindeki tüm alanlarda arama kriterleri * ve ? kullanabilirsiniz. Örnek: ?itap (eşleşenler: kitap, bitap, ..),  o*r (eşleşenler: or, onur, otur ..) ");
DEFINE('_JW_DESC_GOALS_BLOCK', "Ziyaretçinin engellenmesini istiyorsanız değeri 1 yapın. İçeriğin geri kalanı yerine sadece engellendiği mesajını görecektir. Bir yönlendirme yapılmayacak ve IP adresi 'engellenenler'in istatistiklerine eklenecektir. (Örnek kullanım: <b>1</b>)");

/* new translations */
DEFINE('_JW_GOALS_COUNTRY_CONDITION', "Ülke durumu");
DEFINE('_JW_GOALS_CONTRY_INVERSED', "Ülke tersine durumu");
DEFINE('_JW_DESC_GOALS_COUNTRY_CONDITION', "Büyük harflerle 2 harfli ülke kodu (Örnek: <b>TH</b>)");
DEFINE('_JW_STATS_INTERNAL',"Dahili");
DEFINE('_JW_STATS_FROM',"Başlangıç");
DEFINE('_JW_STATS_TO',"Bitiş");
DEFINE('_JW_STATS_ADD_TO_GOALS',"Hedeflere ekle");
DEFINE('_JW_VISITS_ADD_GOAL_COUNTRY',"Bu ülke için bir hedef ekle");
DEFINE('_JW_MENU_REPORT_BUG',"Hata ya da özellik rapor et");
DEFINE('_JW_GOALS_COUNTRY',"Ülke");


/* translations 1.2.8b_12 */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_UPPERCASE',"Eğer ön uçta ülke isimlerinin büyük harflerle görünmesini isterseniz(Örnek: Almanya, İngiltere yerine ALMANYA, İNGİLTERE)");
DEFINE('_JW_DESC_CACHE_FRONTEND_USERS',"Ön uçtaki kullanıcıların verilerinin önbelleğe alınması için saniye cinsinden geçen süre");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL_INITIAL', "Toplam:'da gösterilecek başlangıç değerleri (ön uçta). Başka bir istatistik aracından geçiş yaptığınızda kullanışlı bir araçtır. (Örnek: 20000). Bu özelliği kullanmak istemiyorsanız değeri tekrar 0 yapın.");
DEFINE('_JW_DESC_IGNORE_USER', "Bu kutuda listelenen kullanıcıları yoksay. Satır başına sadece bir adet girilmelidir. (Örnek: kendim {line break} murat_*) ");
DEFINE('_JW_FRONTEND_USERS_MOST', "Günün en aktif kullanıcıları, toplam kullanıcı:");
DEFINE('_JW_DESC_SPAMWORD_BANS_ENABLED',"Aşağıdaki spam listesinde belirtilen kelimeler için engellemeyi etkinleştirir");
DEFINE('_JW_DESC_SPAMWORD_LIST',"Spam botları tarafından en sık kullanılan kelimeler. Burada ? ve * kriterleri kullanılabilir, (Örnek: ph?rmac*). Eğer yukarıdaki seçenek aktif ise, JoomlaWatch saldırganın web sitenize (HTTP POST isteği) bu spam kelimeleri içeren bir form gönderip göndermediğini kontrol edecektir. (Sadece form Joomla tabanlı bir websitesi yüklediğinde geçerlidir. (forum ve yorumlar için de geçerli) Buna rağmen, mümkün olan her formu göndermeye çalışan spam botlarını engellemekte oldukça etkilidir.)");
DEFINE('_JW_SETTINGS_ANTI_SPAM',"Anti-Spam");
DEFINE('_JW_DESC_FRONTEND_USER_LINK',"Ön uç Kullanıcılar modülünde bir adres belirterek kullanıcının kullanıcı adına tıkladığında açılmasını sağlayan bağlantı. {user} dizgisini içermelidir, bu dizginin yerini kullanıcı adı alacaktır. (Örnek: index.php?option=com_comprofiler&task=userProfile&user={user}) ");

/* translations 1.2.11b */
DEFINE('_JW_STATS_KEYPHRASE', "Anahtar sözcükler");
DEFINE('_JW_DESC_HISTORY_MAX_VALUES', "Geçmiş sekmesinde olabilecek en yüksek değer (Örnek: <i>100</i>)");

DEFINE('_JW_DESC_ONLY_LAST_URI', "Ziyaretlerde, ziyaret edilen tüm sayfalar yerine sadece son sayfayı göster");
DEFINE('_JW_DESC_HIDE_REPETITIVE_TITLE', "Ziyaretlerde, ziyaret edilen sayfa başlığında tekrar eden site ismini gizle");
DEFINE('_JW_DESC_HISTORY_MAX_DB_RECORDS', "Ziyaret Geçmişi'nde, veritabanında tutulacak en yüksek ziyaret sayısı. Lütfen bu ayara dikkat edin, eğer trafiğiniz yüksekse, oldukça hızlı bir şekilde büyüyebilir. Durum kısmında geçmiş tablosunun ne kadar veri tuttuğunu düzenli olarak kontrol edin.");
DEFINE('_JW_DESC_UNINSTALL_KEEP_DATA', "Kaldırma yaparken, Veritabanı Tabloları'nı tut. Sürüm yükseltme yapıyor ve verilerinizi saklamak istiyorsanız, kaldırma yapmadan önce bu seçeneği işaretleyin.");

/* email reports */
DEFINE('_JW_DESC_EMAIL_REPORTS_ENABLED', "Sabah okumak üzere, bir önceki günün raporlarını eposta ile geceden teslim alırsınız.");
DEFINE('_JW_DESC_EMAIL_REPORTS_ADDRESS', "Raporları almak istediğiniz eposta adresi");
DEFINE('_JW_DESC_EMAIL_PERCENT_HIGHER_THAN', "Eposta raporlarında sadece {value} değerindazami olan satırları dahil et. Bu özelliği kullanmak istemiyorsanız değeri 0 yapın <i>(Örnek: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_POSITIVE', "Eposta raporlarına sadece günlük değişim yüzde {value} değerinin üzerinde olduğunda dahil et. Bu özelliği kullanmak istemiyorsanız değeri 0 yapın <i>(Örnek: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_NEGATIVE', "Eposta raporlarına sadece günlük değişim yüzde {value} değerinin altında olduğunda dahil et. Bu özelliği kullanmak istemiyorsanız değeri 0 yapın <i>(Örnek: -10)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_POSITIVE', "Eposta raporlarına sadece yedi günlük değişim yüzde {value} değerinin üzerinde olduğunda dahil et. Bu özelliği kullanmak istemiyorsanız değeri 0 yapın <i>(Örnek: 2)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_NEGATIVE', "Eposta raporlarına sadece yedi günlük değişim yüzde {value} değerinin altında olduğunda dahil et. Bu özelliği kullanmak istemiyorsanız değeri 0 yapın <i>(Örnek: -13)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_POSITIVE', "Eposta raporlarına sadece otuz günlük değişim yüzde {value} değerinin üzerinde olduğunda dahil et. Bu özelliği kullanmak istemiyorsanız değeri 0 yapın <i>(Örnek: 2)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_NEGATIVE', "Eposta raporlarına sadece otuz günlük değişim yüzde {value} değerinin altında olduğunda dahil et. Bu özelliği kullanmak istemiyorsanız değeri 0 yapın <i>(Örnek: -13)</i>");

DEFINE('_JW_DESC_FRONTEND_NOFOLLOW', "<b>(PRO sürümde çalışır)</b> Eğer logo bağlantısının rel='nofollow' özelliğine sahip olmasını istiyorsanız bu ayarı etkinleştirin. ");
DEFINE('_JW_DESC_EMAIL_NAME_TRUNCATE', "Eposta satır isminde yer alacak olan azami karakter sayısı. Eğer eposta uygulamanızdaki mesaj penceresi çok küçük olması durumunda değiştirebilirsiniz.");

DEFINE('_JW_MENU_HISTORY', "Geçmiş");
DEFINE('_JW_MENU_EMAILS', "Epostalar");
DEFINE('_JW_MENU_STATUS', "Veritabanı Durumu");
DEFINE('_JW_DESC_BLOCKED',"Bu IPler anti-spam tarafından engellendi");


DEFINE('_JW_HISTORY_VISITORS',"Ziyaretçi Geçmişi");
DEFINE('_JW_HISTORY_SHOWING_ONLY', "Sadece son %d kayıt gösteriliyor.
                Bu değeri değiştirmek için, Ayarlar -&gt; Geçmiş &amp; Performans -&gt; HISTORY_MAX_DB_RECORDS yolunu izleyin. Dikkatli olun, bu ayar aşağıdaki verinin yüklenme süresine etki edektir.  ");
DEFINE('_JW_MENU_BUG', "Hata Raporu Gönder");
DEFINE('_JW_MENU_FEATURE', "Yeni Özellik İste");

DEFINE('_JW_VISITS_CAME_FROM_KEYWORDS',"Anahtar Kelimeler");

DEFINE('_JW_BLOCKING_UNBLOCK',"engeli kaldır");
DEFINE('_JW_STATS_KEYPHRASE ',"Anahtar kelime");

DEFINE('_JW_STATUS_DATABASE_TABLE_NAME',"tablo adı");
DEFINE('_JW_STATUS_DATABASE_ROWS',"satırlar");
DEFINE('_JW_STATUS_DATABASE_DATA',"veri");
DEFINE('_JW_STATUS_DATABASE_TOTAL',"toplam");

DEFINE('_JW_EMAIL_REPORTS',"Eposta Raporları");
DEFINE('_JW_EMAIL_REPORT_GENERATED',"Dün oluşturulmuş, filtrelenmiş eposta raporu");
DEFINE('_JW_EMAIL_REPORTS_VALUE_FILTERS',"Eposta Değer Filtreleri");
DEFINE('_JW_EMAIL_REPORTS_VALUE',"değer");
DEFINE('_JW_EMAIL_REPORTS_PERCENT',"yüzde");
DEFINE('_JW_EMAIL_REPORTS_1DAY_CHANGE',"1 günlük değişim");
DEFINE('_JW_EMAIL_REPORTS_7DAY_CHANGE',"7 günlük değişim");
DEFINE('_JW_EMAIL_REPORTS_28DAY_CHANGE',"28 günlük değişim");
DEFINE('_JW_ANTISPAM_BLOCKED',"JoomlaWatch bugün %d spamci girişini engelledi, Toplam: %d");
DEFINE('_JW_ANTISPAM_ADDRESSES',"Engellenen IP Adresi");
DEFINE('_JW_ANTISPAM_SETTINGS',"Anti-Spam Ayarları");
DEFINE('_JW_TRAFFIC_AJAX',"AJAX trafik güncellemeleri (haritalar hariç)");


DEFINE('_JW_HISTORY_PREVIOUS',"önceki");
DEFINE('_JW_HISTORY_NEXT',"sonraki");

/** additional translation for 1.2.11 for countries in more rows */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_COLUMNS',"Ülke kolonu sayısı");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_ROWS',"Ülke satırı sayısı");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NAMES',"Ülke isimlerini göster/gösterme");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FLAGS_FIRST',"Önce bayrakları, ardından yüzdeyi göster");

/* JoomlaWatch 1.2.14 translations */

DEFINE('_JW_GOALS_GET_INVERSED', "Tersine durumu al");
DEFINE('_JW_GOALS_POST_INVERSED', "Tersine durumu gönder");
DEFINE('_JW_GOALS_TITLE_INVERSED', "Başlığın tersine durumu");
DEFINE('_JW_GOALS_USERNAME_INVERSED', "Kullanıcı adının tersine durumu");
DEFINE('_JW_GOALS_CAME_FROM_INVERSED', "Tersine durumdan gelmiş");

DEFINE('_JW_STATS_MAP', "Son Ziyaret Haritası");
DEFINE('_JW_STATS_MAP_ENTER_KEY',"Lütfen, son ziyaret haritasını görüntülemek için <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a> anahtarını girin:");
DEFINE('_JW_STATS_MAP_STORE_KEY',"depo anahtarı");
DEFINE('_JW_STATS_MAP_INVALID_KEY',"Lütfen, <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a> adresinden aldığınız ipinfodb anahtarını girin");

DEFINE('_JW_SIZEQUERY_BAD_REQUEST',"Hatalı İstek: ");

DEFINE('_JW_VISIT_SUBMITED_FIELDS',"Gönderilen form alanları:");
DEFINE('_JW_VISIT_URL_PARAMETERS',"URL parametreleri:");
DEFINE('_JW_VISIT_ADD_PAGE'," Sayfayı hedef olarak ekle");
DEFINE('_JW_VISIT_BLOCK_IP'," IP Adresini Engelle");
DEFINE('_JW_VISIT_SUBMITED_FROM_VARIABLE'," Eklenen form değişkenini hedef olarak ekle");
DEFINE('_JW_VISIT_URL_PARAMETER_GOAL'," bu adresi hedef olarak ekle");

DEFINE('_JW_TREND_EMPTY',"Boş");

DEFINE('_JW_NOT_NUMBER'," UYARI: Girdiğiniz değer bir sayı değil. JoomlaWatch düzgün çalışmayacak!");
DEFINE('_JW_EVALUATION_LEFT',"&nbsp; Bu 15 günlük Deneme Sürümü. <b>%d</b> gününüz kaldı. Bu adresten <a href='http://www.codegravity.com/donate/joomlawatch/' target='_blank'>Alan adınız için JoomlaWatch lisansı</a> bu ve sonraki sürümler için, hayat boyu kullanım hakkını alabilirsiniz.");
DEFINE('_JW_TRIAL_VERSION_EXPIRED'," Deneme sürümünüz sona erdi. Lütfen, JoomlaWatch'u satın alın.");

DEFINE('_JW_CONFIG_LICENSE_ACTIVATED',"Lisans başarıyla etkinleştirildi, teşekkürler.");
DEFINE('_JW_CONFIG_LICENCE_DONT_MATCH',"<b>Hata: lisans anahtarı ve alan adınız eşleşmedi.</b><br/>Etkinleştirmek için aşağıdaki formda girdiğiniz adresi girdiyseniz, lütfen info@codegravity.com adresinden bizimle iletişime geçin.");

DEFINE('_JW_VIEW_ADMINBODY_LONG_MESSAGE',"Eğer bu mesajı yukarıda uzun bir süredir görüyorsanız, yayındaki site adresiniz hatalı olabilir.
                    components/com_joomlawatch/config.php dosyasını açın
                    yorumu kaldırın ve yayındaki site adresinizi girin Örnek:
                    define('JOOMLAWATCH_LIVE_SITE', 'http://www.codegravity.com');");

DEFINE('_JW_ADMINBODY_LIVE_SITE',"Uyarı: Tarayıcınızdaki site adresi ve ayarlardaki yayındaki site adresiniz; %s ve %s eşleşmiyor.");
DEFINE('_JW_ADMINBODY_SET_LIVE_SITE',"Yayındaki site adresini: %s olarak ayarla ve devam et...");

DEFINE('_JW_ADMINHEADER_JW',"JoomlaWatch ");
DEFINE('_JW_ADMINHEADER_REMOVE_BACKLINK',"Bağlantıyı Kaldır");
DEFINE('_JW_ADMINHEADER_KNOWLEDGE_BASE',"Bilgi Merkezi");
DEFINE('_JW_ADMINHEADER_FLOW',"Akış");
DEFINE('_JW_ADMINHEADER_GRAPHS',"Grafikler");
DEFINE('_JW_ADMINHEADER_COMPONENTS',"Bileşenler");
DEFINE('_JW_ADMINHEADER_REVIEW',"yaz");
DEFINE('_JW_ADMINHEADER_WRITE',"İnceleme ");

DEFINE('_JW_FLOW_TRAFFIC',"Trafik Akışı");
DEFINE('_JW_FLOW_SELECT_PAGE',"Sayfa seç:");
DEFINE('_JW_FLOW_OUTG_LINKS',"Listelenecek olan dış bağlantı sayısı:");
DEFINE('_JW_FLOW_NESTING',"Yuvalama seviyesi:");
DEFINE('_JW_FLOW_SCALE',"Ölçü:");

DEFINE('_JW_COMERCIAL_AD_FREE',"Reklamsız sürüm");
DEFINE('_JW_COMERCIAL_THANK_DONATION',"Bağışınız için teşekkür ederiz!");
DEFINE('_JW_COMERCIAL_REGISTRATION_KEY',"Alan adınız %s için kayıt anahtarı: ");
DEFINE('_JW_COMERCIAL_BACKLINKS_REMOVE',"Artık ön uçtaki JoomlaWatch logosunu Ayarlar'dan kaldırabilir ya da saklayabilirsiniz ");


DEFINE('_JW_SIZES_LAST_CHECK',"Son kontrol zamanı:");
DEFINE('_JW_SIZES_ADMINISTRATOR',"MAVİ = /administrator directory içerisindeki component/module bölümünün boyutu");

DEFINE('_JW_SIZECOMPONENTS_COMPONENT',"Bileşen");
DEFINE('_JW_SIZECOMPONENTS_TOTAL',"Toplam:");
DEFINE('_JW_SIZECOMPONENTS_SIZE',"Boyut");
DEFINE('_JW_SIZECOMPONENTS_REFRESH_ALL',"Tümünü Yenile");

DEFINE('_JW_SIZEDATABASE_TABLE',"Tablo");
DEFINE('_JW_SIZEDATABASE_SIZE',"Boyut");
DEFINE('_JW_SIZEDATABASE_1DAY',"1 günlük değişim");
DEFINE('_JW_SIZEDATABASE_7DAY',"7 günlük değişim");
DEFINE('_JW_SIZEDATABASE_28DAY',"28 günlük değişim");
DEFINE('_JW_SIZEDATABASE_NO_DATA',"veri yok");
DEFINE('_JW_SIZEDATABASE_TOTAL',"Toplam:");

DEFINE('_JW_SIZEMODULES_REFRESH_ALL',"Tümünü Yenile");
DEFINE('_JW_SIZEMODULES_TOTAL',"Toplam:");
DEFINE('_JW_SIZEMODULES_MODULE',"Modül");
DEFINE('_JW_SIZEMODULES_SIZE',"Boyut");

DEFINE('_JW_SIZES_FILES',"Dosyalar &amp; Dizinler");
DEFINE('_JW_SIZES_BYTES',"byte");
DEFINE('_JW_SIZES_KB',"KB");
DEFINE('_JW_SIZES_MB',"MB");
DEFINE('_JW_SIZES_GB',"GB");
DEFINE('_JW_SIZES_REFRESH',"Yenile");

DEFINE('_JW_STATS_FOOTER',"JoomlaWatch &copy;2006-@YEAR@  Matej Koval");

DEFINE('_JW_STATUS_MB',"MB");
DEFINE('_JW_STATUS_DATABASE',"Veritabanı Tablo Boyutları");


DEFINE('_JW_DESC_IPINFODB_KEY',"Son ziyaret haritası ipinfodb.com anahtarı: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");
DEFINE('_JW_SETTINGS_FORCE_TIMEZONE_OFFSET',"Saat Dilimi ayarını zorunlu kıl");


//add for upgrade
DEFINE('_JW_MENU_UPDATE', "Güncelle");
DEFINE('_JW_MENU_UPDATE_TITLE', "Yedekle & Sürüm yükselt");


/* JoomlaWatch 1.2.17 translations */
DEFINE('_JW_MENU_UPDATE', "Güncelle");
DEFINE('_JW_MENU_UPDATE_TITLE', "Yedekle & Sürüm yükselt");
DEFINE('_JW_ADMINHEADER_NA_IN_THIS_VERSION',"Ücretsiz sürümde mevcut değil, lütfen lisans sekmesini kontrol ediniz");
DEFINE('_JW_SPAMWORD_BANS_ENABLED', "Spam Kelimeler için engellemeyi etkinleştir");
DEFINE('_JW_SPAMWORD_LIST', "Spam Kelime Listesi");
DEFINE('_JW_HIDE_REPETITIVE_TITLE', "Tekrar Eden Başlığı Gizle");
DEFINE('_JW_TRUNCATE_VISITS', "Ziyaret gösterimini kısalt");
DEFINE('_JW_TRUNCATE_STATS', "İstatistiklerin gösterimini kısalt");
DEFINE('_JW_TRUNCATE_GOALS', "Hedeflerin gösterimini kısalt");
DEFINE('_JW_LIMIT_BOTS', "Botların gösterimini kısalt");
DEFINE('_JW_LIMIT_VISITORS', "Ziyaretçileri sınırla");
DEFINE('_JW_TOOLTIP_WIDTH', "Tooltip Genişliği");
DEFINE('_JW_TOOLTIP_HEIGHT', "Tooltip Yüksekliği");
DEFINE('_JW_TOOLTIP_URL', "Tooltip Adresi");
DEFINE('_JW_TOOLTIP_ONCLICK', "Tooltip Tıklayarak Açılsın");
DEFINE('_JW_IP_STATS', "IP istatistikleri");
DEFINE('_JW_IPINFODB_KEY', "IP Bilgisi Veritabanı anahtarı ");
DEFINE('_JW_ONLY_LAST_URI', "Sadece son URL ");

DEFINE('_JW_FRONTEND_HIDE_LOGO', "Ön uçtaki logoyu gizle ");
DEFINE('_JW_FRONTEND_NOFOLLOW', "Ön uca 'no follow' özelliği ekle");
DEFINE('_JW_FRONTEND_NO_BACKLINK', "Ön uçtaki bağlantıyı kaldır");
DEFINE('_JW_FRONTEND_USER_LINK', "Ön taraftaki kullanıcı bağlantıları");
DEFINE('_JW_FRONTEND_COUNTRIES_FIRST', "Ön uçta ilk önce ülkeleri dikkate al");
DEFINE('_JW_FRONTEND_COUNTRIES_NAMES', "Ön uçta ülkelerin isimleri");
DEFINE('_JW_FRONTEND_COUNTRIES_UPPERCASE', "Ön uçta ülkeleri büyük harfle göster");
DEFINE('_JW_FRONTEND_COUNTRIES_FLAGS_FIRST', "Ön uçta önce ülkelerin bayraklarını göster ");
DEFINE('_JW_FRONTEND_COUNTRIES_NUM', "Ön uçtaki ülke sayısı");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_COLUMNS', "Ön uçta ülkelerin en yüksek sütun sayısı");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_ROWS', "Ön uçta ülkelerin en yüksek satır sayısı");
DEFINE('_JW_FRONTEND_VISITORS_TODAY', "Bugün ön ucu ziyaret edenler ");
DEFINE('_JW_FRONTEND_VISITORS_YESTERDAY', "Dün ön ucu ziyaret edenler ");
DEFINE('_JW_FRONTEND_VISITORS_THIS_WEEK', "Bu hafta ön ucu ziyaret edenler ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_WEEK', "Geçen hafta ön ucu ziyaret edenler ");

DEFINE('_JW_FRONTEND_VISITORS_THIS_MONTH', "Bu ay ön ucu ziyaret edenler ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_MONTH', "Geçen ay ön ucu ziyaret edenler");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL', "Tüm ön uç ziyaretlerini göster");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL	', "Ön uç başlangıç toplamı");
DEFINE('_JW_HISTORY_MAX_VALUES', "Geçmiş için en yüksek değer");
DEFINE('_JW_HISTORY_MAX_DB_RECORDS', "Geçmiş için azami kayıt sayısı");
DEFINE('_JW_UPDATE_TIME_VISITS', "Ziyaret sürelerini güncelle");
DEFINE('_JW_UPDATE_TIME_STATS', "Süre istatistiklerini güncelle");
DEFINE('_JW_STATS_MAX_ROWS', "İstatistikler için azami satır sayısı");
DEFINE('_JW_STATS_IP_HITS', "IP hitlerinin istatistikleri");
DEFINE('_JW_MAXID_BOTS', "Azami bot kimliği sayısı");
DEFINE('_JW_MAXID_VISITORS', "Azami ziyaretçi kimliği sayısı");
DEFINE('_JW_STATS_KEEP_DAYS', "İstatistiklerin tutulacağı gün sayısı ");
DEFINE('_JW_CACHE_FRONTEND_COUNTRIES', "Ön uçtaki ülkeleri önbelleğe al ");
DEFINE('_JW_CACHE_FRONTEND_VISITORS', "Ön uçtaki ziyaretçileri önbelleğe al ");

DEFINE('_JW_UNINSTALL_KEEP_DATA	', "Kaldırmada veriyi sakla ");
DEFINE('_JW_IGNORE_IP', "IPyi yoksay");
DEFINE('_JW_IGNORE_URI', "Adresi yoksay");
DEFINE('_JW_IGNORE_USER', "Kullanıcıyı yoksay");
DEFINE('_JW_BLOCKING_MESSAGE', "Mesaj engelleniyor");
DEFINE('_JW_SERVER_URI_KEY', "Sunucu URL anahtarı");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL', "Ön uçtaki ziyaretçilerin başlangıç toplamı");
DEFINE('_JW_SIZEDATABASE_RECORDS', "Kayıtlar");
/***********EDITs******************/
DEFINE('_JW_ANTISPAM_BLOCKING_TEXT'," Engellemeyi etkili bir şekilde yapmak isterseniz, JoomlaWatch ajanını tüm içerik ve formdan önce paylaşmalısınız. Örnek: temanızın sol tarafı.
                    <br/>
                    Modül Yöneticisi'ne gidin -> JoomlaWatch ajanı -> pozisyonu sol olarak seçin");
DEFINE('_JW_EMAIL_SEO_REPORTS', "SEO Raporları");
DEFINE('_JW_DESC_EMAIL_SEO_REPORTS_ENABLED',"Gecelik SEO eposta raporu aktifleştirildi");
DEFINE('_JW_WATCH_INSTALLATION_DEMO',"Yükleme demosunu izle");

?>