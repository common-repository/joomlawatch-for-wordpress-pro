<?php

/**
* JoomlaWatch - A real-time ajax joomla monitor and live stats
* @package JoomlaWatch
* @version @VERSION@
* @revision @REVISION@
* @license http://www.gnu.org/licenses/gpl-3.0.txt GNU General Public License v3
* @copyright (C) @YEAR@ by Matej Koval - All rights reserved!
* @website http://www.codegravity.com
**/
defined( '_JEXEC' ) or die( 'Restricted access' );

#JoomlaWatch language file - to create a new language file, just copy the english.php to eg. german.php and place into /components/com_joomlawatch/lang/

# Main Menu
DEFINE('_JW_MENU_STATS', "Él&#337; statisztikák");
DEFINE('_JW_MENU_GOALS', "Célok");
DEFINE('_JW_MENU_SETTINGS', "Beállítások");
DEFINE('_JW_MENU_CREDITS', "Szerz&#337;k");
DEFINE('_JW_MENU_FAQ', "GYIK");
DEFINE('_JW_MENU_DOCUMENTATION', "Dokumentáció");
DEFINE('_JW_MENU_LICENSE', "License");
DEFINE('_JW_MENU_DONATORS', "Támogatók");
DEFINE('_JW_MENU_SUPPORT', "Támogassa JoomlaWatch-ot és a hirdetések elt&#369;nnek a háttérb&#337;l.");


# Left visitors real-time window
DEFINE('_JW_VISITS_VISITORS', "Utolsó látogatók");
DEFINE('_JW_VISITS_BOTS', "Bots");
DEFINE('_JW_VISITS_CAME_FROM', "Érkezési hely");
DEFINE('_JW_VISITS_MODULE_NOT_PUBLISHED', "Az Ön JoomlaWatch modulja nem publikus! Új statisztikák nem készülnek. Publikálni úgy tudja, hogy elmegy a Modulok szekcióra és publikussá tesz minden oldalt.");
DEFINE('_JW_VISITS_PANE_LOADING', "Látogatások betöltése...");

# Right stats window
DEFINE('_JW_STATS_TITLE', "Heti látogatói statisztikák");
DEFINE('_JW_STATS_WEEK', "Hét");
DEFINE('_JW_STATS_THIS_WEEK', "ez a hét");
DEFINE('_JW_STATS_UNIQUE', "egyedi");
DEFINE('_JW_STATS_LOADS', "betöltések");
DEFINE('_JW_STATS_HITS', "találatok");
DEFINE('_JW_STATS_TODAY', "ma");
DEFINE('_JW_STATS_FOR', "ért");
DEFINE('_JW_STATS_ALL_TIME', "minden id&#337;k");
DEFINE('_JW_STATS_EXPAND', "kib&#337;vítés");
DEFINE('_JW_STATS_COLLAPSE', "besz&#369;kítés");
DEFINE('_JW_STATS_URI', "URI Oldalak");
DEFINE('_JW_STATS_COUNTRY', "Országok");
DEFINE('_JW_STATS_USERS', "Felhasználók");
DEFINE('_JW_STATS_REFERERS', "Referensek");
DEFINE('_JW_STATS_IP', "IP-k");
DEFINE('_JW_STATS_BROWSER', "Böngész&#337;k");
DEFINE('_JW_STATS_OS', "OS");
DEFINE('_JW_STATS_KEYWORDS', "Kulcsszavak");
DEFINE('_JW_STATS_GOALS', "Célok");
DEFINE('_JW_STATS_TOTAL', "Összesen");
DEFINE('_JW_STATS_DAILY', "Napi");
DEFINE('_JW_STATS_DAILY_TITLE', "Napi statisztikák");
DEFINE('_JW_STATS_ALL_TIME_TITLE', "Összesített statisztikák");
DEFINE('_JW_STATS_LOADING', "betöltés...");
DEFINE('_JW_STATS_LOADING_WAIT', "betöltés... kérem várjon");
DEFINE('_JW_STATS_IP_BLOCKING_TITLE', "IP cím blokkolás");
DEFINE('_JW_STATS_IP_BLOCKING_ENTER', "Írja be az IP címet");
DEFINE('_JW_STATS_IP_BLOCKING_MANUALLY', "Írja be az IP címet, amit blokkolni akar. (pl. 217.242.11.54 vagy 217.* vagy 217.242.* blokkolni az összes IP-t ami így kezd&#337;dik)");
DEFINE('_JW_STATS_IP_BLOCKING_TOGGLE', "A blokkoló tényleges bekapcsolása a ");
DEFINE('_JW_STATS_PANE_LOADING', "Statisztikák betöltése...");

# Settings
DEFINE('_JW_SETTINGS_TITLE', "Beállítások");
DEFINE('_JW_SETTINGS_DEFAULT', "Alapértelmezés");
DEFINE('_JW_SETTINGS_SAVE', "Mentés");
DEFINE('_JW_SETTINGS_APPEARANCE', "Megjelenítés");
DEFINE('_JW_SETTINGS_FRONTEND', "Képerny&#337;");
DEFINE('_JW_SETTINGS_HISTORY_PERFORMANCE', "Történet és teljesítmény");
DEFINE('_JW_SETTINGS_ADVANCED', "Haladó");
DEFINE('_JW_SETTINGS_IGNORE', "Ignorálás");
DEFINE('_JW_SETTINGS_BLOCKING', "Blokkolás");
DEFINE('_JW_SETTINGS_EXPERT', "Gyakorlott");
DEFINE('_JW_SETTINGS_RESET_CONFIRM', "Valóban lenullázza az összes statisztikai és látogatói adatot?");
DEFINE('_JW_SETTINGS_RESET_ALL', "Minden adat nullázása");
DEFINE('_JW_SETTINGS_RESET_ALL_LINK', "Statisztikai adatok nullázása és látogatói adatok");
DEFINE('_JW_SETTINGS_LANGUAGE', "Nyelv");
DEFINE('_JW_SETTINGS_SAVED', "Beállítások elmentve");
DEFINE('_JW_SETTINGS_ADD_YOUR_IP', "Adja meg IP címét");
DEFINE('_JW_SETTINGS_TO_THE_LIST', "a listához.");

# Other / mostly general
DEFINE('_JW_TITLE', "Él&#337; AJAX joomla monitor");
DEFINE('_JW_BACK', "Vissza");
DEFINE('_JW_ACCESS_DENIED', "Nincs hozzáférési joga ehhez a nézethez!");
DEFINE('_JW_LICENSE_AGREE', "Egyetértek a fenti definíciókkal és feltételekkel");
DEFINE('_JW_LICENSE_CONTINUE', "Folytatás");
DEFINE('_JW_SUCCESS', "Sikeres m&#369;velet");
DEFINE('_JW_RESET_SUCCESS', "Az összes statisztikai és látogatói adat sikeresen törl&#337;dött");
DEFINE('_JW_RESET_ERROR', "Az adatok NEM törl&#337;dtek, valami hiba történt");
DEFINE('_JW_CREDITS_TITLE', "Szerz&#337;k");
DEFINE('_JW_TRENDS_DAILY_WEEKLY', "Napi és heti statisztikái a");
DEFINE('_JW_AJAX_PERMISSION_DENIED_1', "AJAX hozzáférés megtiltva: Kérem nézze a statisztikákat arról a domain-ról, amit a joomla - 'configuration.php'-ban megadott");
DEFINE('_JW_AJAX_PERMISSION_DENIED_2', "Talán elfelejtette megadni a 'www.'-ot a domain név elején. Javascript-je próbálja elérni ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_3', "tól");
DEFINE('_JW_AJAX_PERMISSION_DENIED_4', "mit&#337;l t&#369;nik úgy, hogy ez egy másik domain.");

# Header
DEFINE('_JW_HEADER_DOWNLOAD', "A program utolsó verzióját letöltheti innen");
DEFINE('_JW_HEADER_CAST_YOUR', "Kérem szavazzon ránk");
DEFINE('_JW_HEADER_VOTE', "szavazás");

# Tooltips
DEFINE('_JW_TOOLTIP_CLICK', "Klikkeljen a hasznos tippeket megmutatni");
DEFINE('_JW_TOOLTIP_MOUSE_OVER', "Mozgassa az egeret, hogy megmutassa a hasznos tippeket");
DEFINE('_JW_TOOLTIP_YESTERDAY_INCREASE', "tegnapi növekmény");
DEFINE('_JW_TOOLTIP_HELP', "Megnyit küls&#337; segítséget");
DEFINE('_JW_TOOLTIP_WINDOW_CLOSE', "Ablak becsukása");
DEFINE('_JW_TOOLTIP_PRINT', "Nyomtatás");

# Goals
DEFINE('_JW_GOALS_INSERT', "Új cél beírása");
DEFINE('_JW_GOALS_UPDATE', "Cél módosítása szám.");
DEFINE('_JW_GOALS_ACTION', "Esemény");
DEFINE('_JW_GOALS_TITLE', "Új cél");
DEFINE('_JW_GOALS_NEW', "Új cél");
DEFINE('_JW_GOALS_RELOAD', "Újratöltés");
DEFINE('_JW_GOALS_ADVANCED', "Haladó");
DEFINE('_JW_GOALS_NAME', "Név");
DEFINE('_JW_GOALS_ID', "szám");
DEFINE('_JW_GOALS_URI_CONDITION', "URI állapot");
DEFINE('_JW_GOALS_URI_INVERSED', "URI fordított állapot");
DEFINE('_JW_GOALS_GET_VAR', "GET változó bekérés");
DEFINE('_JW_GOALS_GET_CONDITION', "GET feltétel bekérés");
DEFINE('_JW_GOALS_POST_VAR', "POST változó elküldés");
DEFINE('_JW_GOALS_POST_CONDITION', "POST feltétel elküldés");
DEFINE('_JW_GOALS_TITLE_CONDITION', "Cím feltétel");
DEFINE('_JW_GOALS_USERNAME_CONDITION', "Felhasználónév feltétel");
DEFINE('_JW_GOALS_IP_CONDITION', "IP Feltétel");
DEFINE('_JW_GOALS_IP_INVERSED', "IP fordított Feltétel");
DEFINE('_JW_GOALS_CAME_FROM_CONDITION', "Feltétel érkezés");
DEFINE('_JW_GOALS_BLOCK', "Blokkolás");
DEFINE('_JW_GOALS_REDIRECT', "URL Webcím átirányítás");
DEFINE('_JW_GOALS_HITS', "Találatok");
DEFINE('_JW_GOALS_ENABLED', "Engedélyezve");
DEFINE('_JW_GOALS_EDIT', "Módosítás");
DEFINE('_JW_GOALS_DELETE', "Törlés");
DEFINE('_JW_GOALS_DELETE_CONFIRM', "El fogja veszteni a statisztikai adatokat erre a célra. Biztosan törölni akarja ezt a célt - szám.");

# Frontend
DEFINE('_JW_FRONTEND_COUNTRIES', "Országok");
DEFINE('_JW_FRONTEND_VISITORS', "Látogatók");
DEFINE('_JW_FRONTEND_TODAY', "Ma");
DEFINE('_JW_FRONTEND_YESTERDAY', "Tegnap");
DEFINE('_JW_FRONTEND_THIS_WEEK', "Mostani hét");
DEFINE('_JW_FRONTEND_LAST_WEEK', "Múlt hét");
DEFINE('_JW_FRONTEND_THIS_MONTH', "Mostani hónap");
DEFINE('_JW_FRONTEND_LAST_MONTH', "Múlt hónap");
DEFINE('_JW_FRONTEND_TOTAL', "Összesen");

# Settings description - quite long
DEFINE('_JW_DESC_DEBUG', "JoomlaWatch hibakeres&#337; állapot. Ezen az úton megtalálhatja a hiba okát. Ha ki akarja kapcsolni változtassa meg JOOMLAWATCH_DEBUG értékét /components/com_joomlawatch/config.php 1-r&#337;l 0-ra");
DEFINE('_JW_DESC_STATS_MAX_ROWS', "Maximális sorok megmutatása, ha a statisztika a kib&#337;vített módban van.");
DEFINE('_JW_DESC_STATS_IP_HITS', "Az összes IP cím, aminek kevesebb találata van az el&#337;z&#337; napokban mint a megadott szám, törl&#337;dik a rendszerb&#337;l.");
DEFINE('_JW_DESC_STATS_URL_HITS', "Az öszes URL (webcím) aminek kevesebb találata van az el&#337;z&#337; napokban mint a megadott szám, törl&#337;dik a rendszerb&#337;l.");
DEFINE('_JW_DESC_IGNORE_IP', "Bizonyos IP címek kizárása a statisztikákból. Új sorba irja &#337;ket. Használhat csillagot ha egész csoportot ki akar választani. <br/>Pl. 192.* ki fogja sz&#369;rni 192.168.51.31, 192.168.16.2, stb..");
DEFINE('_JW_DESC_UPDATE_TIME_VISITS', "Látogatók újrafrissítése milisecundunban, az alapbeállítás 2000, legyen óvatos ezzel a beállítással. Módosítás után inditsa újra a JoomlaWatch-ot.");
DEFINE('_JW_DESC_UPDATE_TIME_STATS', "Statisztika újrafrissítése milisecundumban, az alapbeállítás 4000, legyen óvatos ezzel a beállítással. Módosítás után indítsa újra a JoomlaWatch-ot.");
DEFINE('_JW_DESC_MAXID_BOTS', "Hány bot látogatót tartson meg a rendszer az adatbázisban.");
DEFINE('_JW_DESC_MAXID_VISITORS', "Hány valódi látogatót tartson meg a rendszer az adatbázisban.");
DEFINE('_JW_DESC_LIMIT_BOTS', "Hány bot legyen látható a rendszerben.");
DEFINE('_JW_DESC_LIMIT_VISITORS', "Hány valódi látogató legyen látható a rendszerben.");
DEFINE('_JW_DESC_TRUNCATE_VISITS', "A maximum karakterek száma a bemutatott címekben.");
DEFINE('_JW_DESC_TRUNCATE_STATS', "A maximális karakterek száma a jobboldali statisztikai panelen.");
DEFINE('_JW_DESC_STATS_KEEP_DAYS', "Hány napi statisztikát tároljon az adatbázis, 0 = végtelen.");
DEFINE('_JW_DESC_TIMEZONE_OFFSET', "Ha Ön másik id&#337;zónában van mint a kiszolgáló szerver. (Pozitív vagy negatív szám órákban megadva)");
DEFINE('_JW_DESC_WEEK_OFFSET', "Heti elcsúszás, az id&#337;(timestamp)/(3600*24*7) megadja a hét számát 1970.jan.1. óta, ez az elcsúszás egy korrekció, hogy a kezdés hétf&#337;re essen ");
DEFINE('_JW_DESC_DAY_OFFSET', "Napi elcsúszás, az id&#337;(timestamp)/(3600*24) megadja a nap számát 1970.jan.1. óta, ez az elcsúszás egy korrekció, hogy a kezd? id&#337; éppen éjfél 00:00 legyen");
DEFINE('_JW_DESC_FRONTEND_HIDE_LOGO', "<b>(a PRO verziónál van funkciója)</b> Egy üres 1x1px (pixel) ikon a képerny&#337;n");
DEFINE('_JW_DESC_IP_STATS', "Engedélyezni egy IP címet a statisztikákhoz. Bizonyos országokban IP címeket hosszabb ideig adatbázisban tárolni tilos (illegális). Használja saját felel&#337;sségére.");
DEFINE('_JW_DESC_HIDE_ADS', "Ez a beállítás eltünteti a hirdetéseket a rendszerb&#337;l, ha zavarnak. Ha megtartja, támogatja a rendszer további fejlesztését. Köszönjük");
DEFINE('_JW_DESC_TOOLTIP_ONCLICK', "Törölje ki, ha azt akarja, hogy a használati tippek az egér rámozgatására jelenjelenk meg klikkelés helyett.");
DEFINE('_JW_DESC_SERVER_URI_KEY', "Alapbeállítás 'REDIRECT_URL', ami általános, ha használ url újraírást, be lehet állítani 'SCRIPT_URL'-ra akkor csak a log-ba írja be magát - index.php");
DEFINE('_JW_DESC_BLOCKING_MESSAGE', "Üzenet a blokkolt felhasználóknak, vagy egyéb információ, hogy miért vannak blokkolva.");
DEFINE('_JW_DESC_TOOLTIP_WIDTH', "Használati tipp szélessége");
DEFINE('_JW_DESC_TOOLTIP_HEIGHT', "Használati tipp magassága");
DEFINE('_JW_DESC_TOOLTIP_URL', "Bármilyen URL ideírható, ha vizuálisan mutatni akarja a látogató IP címét. Az {ip} ki lesz cserélve a látogató tényleges IP címére. Pl. http://somewebsite.com/query?iplookup={ip}");
DEFINE('_JW_DESC_IGNORE_URI', "Beírhat bármilyen URI-t amit nem akar a statisztikákban megmutatni. Használhat csillag és kérd&#337;jel karaktert is (* and ?). Pl.: /freel?n* ");
DEFINE('_JW_DESC_GOALS_NAME', "Adja meg a cél nevét. Ezt a nevet fogja látni a statisztikákban.");
DEFINE('_JW_DESC_GOALS_URI_CONDITION', "Minden, ami az Ön domain neve után jön. Pl. http://www.codegravity.com/projects/ esetén az URI: /projects/ (akkor ez: <b>/projects*</b>)");
DEFINE('_JW_DESC_GOALS_GET_VAR', "A GET változó az egy változó, amit a URL-ben láthat általában egy ? or &amp; karakter után. Pl. http://www.codegravity.com/index.php?<u>name</u>=peter&amp;<u>surname</u>=smith. Használhatja <u>*</u> is, akkor az összes mez&#337; változóit végigkeresi. (Egy másik példa: <b>n*me</b>)");
DEFINE('_JW_DESC_GOALS_GET_CONDITION', "Itt meg kell adni egy azonosító értéket az el&#337;z&#337; mez&#337;vel. (Pl.: <b>p?t*r</b>) ");
DEFINE('_JW_DESC_GOALS_POST_VAR', "Itt ellen&#337;rizzük az értékeket amelyek az el&#337;z&#337; oldalak adatlapjain voltak megadva. Tehát ha van egy adatlap a weboldalán, ennek van egy mez&#337;je &lt;input type='text' name='<u>experiences</u>' /&gt;. (Akkor igy használja: <b>exper*ces</b>)");
DEFINE('_JW_DESC_GOALS_POST_CONDITION', "Azonosság egy POST tipusú mez&#337;re. Pl. meg akarjuk nézni, hogy a felhasználónak van-e java gyakorlata. (Pl.: <b>*java*</b>)");
DEFINE('_JW_DESC_GOALS_TITLE_CONDITION', "Az oldal címe aminek egyeznie kell. (Pl.: <b>*freelance programmers*</b>)");
DEFINE('_JW_DESC_GOALS_USERNAME_CONDITION', "A bejelentkezett felhasználó neve. (Pl.: <b>psmith*</b>)");
DEFINE('_JW_DESC_GOALS_IP_CONDITION', "A felhasználó IP címe: (Pl.: <b>201.9?.*.*</b>)");
DEFINE('_JW_DESC_GOALS_CAME_FROM_CONDITION', "Az URL (webcím) ahonnan a felhasználó érkezett. (Pl.: <b>*www.google.*</b>)");
DEFINE('_JW_DESC_GOALS_REDIRECT', "A felhasználó át lett irányítva egy másik URL-re amit mi adunk meg. Ennek nagyobb a prioritása, mint a blokkolásnak: (Pl.: <b>http://www.codegravity.com/goaway.html</b>)");
DEFINE('_JW_DESC_TRUNCATE_GOALS', "A levágandó karakterek száma a célok táblából");
DEFINE('_JW_DESC_FRONTEND_NO_BACKLINK', "<b>(csak a PRO verzióban m&#369;ködik)</b> Átirányítás a codegravity.com címre, le lehet tiltani, de mi örülnénk ha így hagynák. Köszönjük.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES', "Országok összes statisztikája a képerny&#337; modulban. Ha megváltozott, a változás csak akkor m&#369;ködik a képerny&#337;n, amikor az id&#337; be lett állítva a CACHE_FRONTEND_ ");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FIRST', "Ha meg akarja cserélni a Látogatók/Országok sorrendet a képerny&#337;n. Törölje ki és a Látogatók jelennek meg el&#337;ször.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NUM', "Az országok számának megjelenítése a képerny&#337;n");
DEFINE('_JW_DESC_FRONTEND_VISITORS', "Jelenítse meg a látogatókat országok szerint a képerny&#337;n. Ha megváltozott, a változás akkor érvényes a képerny&#337;n, ha az id&#337; be lett állítva a CACHE_FRONTEND_");
DEFINE('_JW_DESC_CACHE_FRONTEND_COUNTRIES', "Az id&#337; másodpercekben az összes ország összegy&#369;jtése a képerny&#337;n");
DEFINE('_JW_DESC_CACHE_FRONTEND_VISITORS', "Az id&#337; másodpercekben az összes látogató összegy&#369;jtése a képerny&#337;n");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TODAY', "A látogatók megmutatása a képerny&#337;n: ma. Ha megváltozott, a változás csak akkor m&#369;ködik a képerny&#337;n, ha az id&#337; be lett állítva a CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_YESTERDAY', "A látogatók megmutatása a képerny&#337;n: tegnap. Ha megváltozott, a változás csak akkor m&#369;ködik a képerny&#337;n, ha az id&#337; be lett állítva a CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_WEEK', "A látogatók megmutatása a képerny&#337;n: ezen a héten. Ha megváltozott, a változás csak akkor m&#369;ködik a képerny&#337;n, ha az id&#337; be lett állítva a CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_WEEK', "A látogatók megmutatása a képerny&#337;n: múlt héten. Ha megváltozott, a változás csak akkor m&#369;ködik a képerny&#337;n, ha az id&#337; be lett állítva a CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_MONTH', "A látogatók megmutatása a képerny&#337;n: ebben a hónapban. Ha megváltozott, a változás csak akkor m&#369;ködik a képerny&#337;n, ha az id&#337; be lett állítva a CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_MONTH', "A látogatók megmutatása a képerny&#337;n: múlt hónap. Ha megváltozott, a változás csak akkor m&#369;ködik a képerny&#337;n, ha az id&#337; be lett állítva a CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL', "Az összes látogató megmutatása a képerny&#337;n amióta JoomlaWatch installálva lett. Ha megváltozott, a változás csak akkor m&#369;ködik a képerny&#337;n, ha az id&#337; be lett állítva a CACHE_FRONTEND_...");
DEFINE('_JW_DESC_LANGUAGE', "A használt nyelv. Ezek helye a /components/com_joomlawatch/lang/ könyvtárban van. Ha egy teljesen új nyelvi állományt akar létrehozni, akkor nézze meg a program helyét, másolja át a english.php egy másik néven, Pl. german.php ugyanabba a könyvtárba. Ezután fordítsa le az összes szöveget - értelemszer&#369;en - a definiciók utáni helyeken, a sorok jobboldani részén.");
DEFINE('_JW_DESC_GOALS', "Célokkal be lehet állítani speciális paramétereket. Amikor ezek a paraméterek megegyeznek, a cél számláló megnövekszik. Ezen az úton nyomon követheti, ha egy felhasználó meglátogatott valamely URL-t, Elküldött-e (POST) speciális értéket, szöveget, mi a felhasználó neve, vagy melyik URL-r&#337;l jött. Adott felhasználót, felhasználókat blokkolhat, vagy átirányíthatja egy másik URL-re.");
DEFINE('_JW_DESC_GOALS_INSERT', "Minden mez&#337;ben, kivéve a nevet használhat jóker karaktereket (* és ?). Például: ?ear (egyezni fog: near, tear, ..), p*r (egyezni fog: pr, peer, pear ..) ");
DEFINE('_JW_DESC_GOALS_BLOCK', "Állítsa be 1-re, ha a látogatót blokkolni akarja. Nem fogja látni a részleteket, csak egy üzenetet, hogy blokkolva van - árirányítás nélkül, és az IP címe bekerült a blokkoltak statisztikájába (Pl.: <b>1</b>)");

/* new translations */
DEFINE('_JW_GOALS_COUNTRY_CONDITION', "Ország feltétel");
DEFINE('_JW_GOALS_CONTRY_INVERSED', "Ország fordított feltétel");
DEFINE('_JW_DESC_GOALS_COUNTRY_CONDITION', "2-bet&#369;s ország kód nagybet&#369;kkel (Pl: <b>TH</b>)");
DEFINE('_JW_STATS_INTERNAL',"Bels&#337;");
DEFINE('_JW_STATS_FROM',"Tól");
DEFINE('_JW_STATS_TO',"Ig");
DEFINE('_JW_STATS_ADD_TO_GOALS',"Adja a célokhoz");
DEFINE('_JW_VISITS_ADD_GOAL_COUNTRY',"Adja a célt ehhez az országhoz");
DEFINE('_JW_MENU_REPORT_BUG',"Jelentsen be hibát vagy javasoljon programmódosítást");
DEFINE('_JW_GOALS_COUNTRY',"Ország");


/* translations 1.2.8b_12 */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_UPPERCASE',"Ha az országok nevét nagybet&#369;kkel akarja megjeleníteni (Pl: GERMANY, UNITED KINGDOM ahelyett hogy Germany, United Kingdom)");
DEFINE('_JW_DESC_CACHE_FRONTEND_USERS',"Az id&#337; másodpercekben a felhasználók beolvasása a képerny&#337;re");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL_INITIAL', "Kezd&#337; érték az összesben megmutatni. Hasznos, ha egy másik statisztikai programból áthozható. (Pl.: 20000). Állítsa 0-re ha nem akarja használni ezt a lehet&#337;séget.");
DEFINE('_JW_DESC_IGNORE_USER', "Ignorája azokat a felhasználókat, akik itt a listán szerepelnek. Egy név soronként. (Pl.: magam {line break} mark_*) ");
DEFINE('_JW_FRONTEND_USERS_MOST', "A mai legaktívabb felhasználók összesen");
DEFINE('_JW_DESC_SPAMWORD_BANS_ENABLED',"Letiltani az alul látható tiltott szavak listáján szerepl&#337; szavakat (SPAM)");
DEFINE('_JW_DESC_SPAMWORD_LIST',"A leggyakrabban használt tiltott szavak modulja. Jóker karakterek is használhatók, (Pl.: ph?rmac*). Ha a beállítás engedélyezve lett, JoomlaWatch megvizsgálja, hogy a támadó elküldött-e adatlapot (a HTTP POST request) az Ön weboldalára ahol tiltott szavak is szerepelnek. (Akkor m&#369;ködik, ha az adatlap a Joomla-alapú web-oldalakra érkezik - fórum, megjegyzések, de meglehet&#337;sen effektív tiltott szavakat blokkolni el&#337;re gyártott kis programokkal, amik különféle trükkös adatlapokat próbálnak elküldeni.)");
DEFINE('_JW_SETTINGS_ANTI_SPAM',"Anti-Spam");
DEFINE('_JW_DESC_FRONTEND_USER_LINK',"Egy link a képerny&#337; modulban - megadhat egy URL-t, ami akkor fog m&#369;ködni, ha a felhasználó ráklikkel egy felhasználó névre. Tartalmaznia kell egy szöveget {user}, ami le lesz cserélve az éppen aktuális felhasználó nevével. (Pl. index.php?option=com_comprofiler&task=userProfile&user={user}) ");

/* translations 1.2.11b */
DEFINE('_JW_STATS_KEYPHRASE', "Kulcskifejezések");
DEFINE('_JW_DESC_HISTORY_MAX_VALUES', "Maximum értékek a múltban (Pl: <i>100</i>)");
DEFINE('_JW_DESC_ONLY_LAST_URI', "Látogatóknál az utolsó meglátogatott oldalt mutatni, nem mindet");
DEFINE('_JW_DESC_HIDE_REPETITIVE_TITLE', "Látogatóknál ne ismételje ugyanazt a címet a látogatott lapoknál");
DEFINE('_JW_DESC_HISTORY_MAX_DB_RECORDS', "A legtöbb látogató megtartása az adatbázisban. Legyen óvatos ezzel a beállítással, ha nagy forgalma van nagyon gyorsan n&#337;het. Mindig ellen&#337;rizze az adatokat a history adatbázis - Status mez&#337;jében");
DEFINE('_JW_DESC_UNINSTALL_KEEP_DATA', "Tartsa az adatbázis táblákat uninstall módban. Nézze meg ezt a beállítást miel&#337;tt a programot módosítja, frissíti ha meg akarja tartani adatait.");

/* email reports */
DEFINE('_JW_DESC_EMAIL_REPORTS_ENABLED', "Napi E-maileket fog kapni az el&#337;z&#337; napról, amit reggel elolvashat");
DEFINE('_JW_DESC_EMAIL_REPORTS_ADDRESS', "E-mail cím, amire az el&#337;z&#337; napi riportokat elküldik");
DEFINE('_JW_DESC_EMAIL_PERCENT_HIGHER_THAN', "Csak azok a tételek legyenek az E-mail riportban ahol a százalék nagyobb mint az itt megadott érték {value}. Állítsa 0-ra ha nem akarja ezt a tulajdonságot használni <i>(Pl: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_POSITIVE', "Alkalmazzon <b>pozitív egy nap</b> cserélje ki az értéket az E-mail riportban, ha az érték magasabb százalék {value}. Állítsa 0-ra ha nem akarja ezt a tulajdonságot használni <i>(Pl: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_NEGATIVE', "Alkalmazzon <b>negatív egy nap</b> cserélje ki az értéket az E-mail riportban, ha az érték kisebb százalék  {value}. Állítsa 0-ra ha nem akarja ezt a tulajdonságot használni <i>(Pl: -10)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_POSITIVE', "Alkalmazzon <b>pozitív 7 nap</b> cserélje ki az értéket az E-mail riportban, ha az érték magasabb százalék {value}. Állítsa 0-ra ha nem akarja ezt a tulajdonságot használni <i>(Pl: 2)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_NEGATIVE', "Alkalmazzon <b>negatív 7 nap</b> cserélje ki az értéket az E-mail riportban, ha az érték kisebb {value}. Állítsa 0-ra ha nem akarja ezt a tulajdonságot használni <i>(Pl: -13)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_POSITIVE', "Alkalmazzon <b>pozitív 28 nap</b> cserélje ki az értéket az E-mail riportban, ha az érték magasabb százalék {value}. Állítsa 0-ra ha nem akarja ezt a tulajdonságot használni <i>(Pl: 2)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_NEGATIVE', "Alkalmazzon <b>negatív 28 nap</b> cserélje ki az értéket az E-mail riportban, ha az érték kisebb százalék {value}. Állítsa 0-ra ha nem akarja ezt a tulajdonságot használni <i>(Pl: -13)</i>");

DEFINE('_JW_DESC_FRONTEND_NOFOLLOW', "<b>(csak a PRO verzióban m&#369;ködik)</b> Engedélyezze ezt a beállítást, ha logo-link-et a következ&#337; paraméterrel akarja ellátni rel='nofollow' ");
DEFINE('_JW_DESC_EMAIL_NAME_TRUNCATE', "Maximum karakterek száma az E-mail sorok nevében. Akkor cserélje ki, ha az E-mail prgramjában túl kicsi az ablak");

DEFINE('_JW_MENU_HISTORY', "Történet");
DEFINE('_JW_MENU_EMAILS', "E-mailek");
DEFINE('_JW_MENU_STATUS', "DB Státusz");
DEFINE('_JW_DESC_BLOCKED',"Ezek az IP címek lettek blokkolva az anti-spam által");


DEFINE('_JW_HISTORY_VISITORS',"Látogatók története");
DEFINE('_JW_HISTORY_SHOWING_ONLY', "Mutassa csak %d utolsó tételeket.
Ezt az értéket a Beállítások menüben -&gt; Történet &amp; Teljesítmény -&gt; HISTORY_MAX_DB_RECORDS . Legyen óvatos, ez a beállítás megváltoztathatja a betöltési id&#337;t az adatokban. ");
DEFINE('_JW_MENU_BUG', "Jelentsen program hibát");
DEFINE('_JW_MENU_FEATURE', "Kérjen program módosítást");

DEFINE('_JW_VISITS_CAME_FROM_KEYWORDS',"Kulcsszavak");

DEFINE('_JW_BLOCKING_UNBLOCK',"blokkolás letörlés");
DEFINE('_JW_STATS_KEYPHRASE ',"Kulcs kifejezés");

DEFINE('_JW_STATUS_DATABASE_TABLE_NAME',"tábla neve");
DEFINE('_JW_STATUS_DATABASE_ROWS',"sorok");
DEFINE('_JW_STATUS_DATABASE_DATA',"adat");
DEFINE('_JW_STATUS_DATABASE_TOTAL',"összesen");

DEFINE('_JW_EMAIL_REPORTS',"E-mail riportok");
DEFINE('_JW_EMAIL_REPORT_GENERATED',"Tegnapi sz&#369;rt E-mail riport");
DEFINE('_JW_EMAIL_REPORTS_VALUE_FILTERS',"E-mail sz&#369;rési feltételek");
DEFINE('_JW_EMAIL_REPORTS_VALUE',"érték");
DEFINE('_JW_EMAIL_REPORTS_PERCENT',"százalék");
DEFINE('_JW_EMAIL_REPORTS_1DAY_CHANGE',"1-nap változás");
DEFINE('_JW_EMAIL_REPORTS_7DAY_CHANGE',"7-nap változás");
DEFINE('_JW_EMAIL_REPORTS_28DAY_CHANGE',"28-nap változás");
DEFINE('_JW_ANTISPAM_BLOCKED',"JoomlaWatch blokkolt %d spam-kísérletet ma, összesen: %d");
DEFINE('_JW_ANTISPAM_ADDRESSES',"Blokkolt IP Címek");
DEFINE('_JW_ANTISPAM_SETTINGS',"Anti-Spam Beállítások");
DEFINE('_JW_TRAFFIC_AJAX',"AJAX frissítés forgalom (térkép kivételével)");


DEFINE('_JW_HISTORY_PREVIOUS',"el&#337;z&#337;");
DEFINE('_JW_HISTORY_NEXT',"következ&#337;");

/** additional translation for 1.2.11 for countries in more rows */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_COLUMNS',"Az országok oszlopainak száma");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_ROWS',"Az országok sorainak száma");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NAMES',"Kiírja az országok neveit, vagy sem");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FLAGS_FIRST',"Kiírja a zászlókat el&#337;ször, utána a százalékokat");

/* JoomlaWatch 1.2.14 translations */

DEFINE('_JW_GOALS_GET_INVERSED', "GET fordított feltétel");
DEFINE('_JW_GOALS_POST_INVERSED', "POST fordított feltétel");
DEFINE('_JW_GOALS_TITLE_INVERSED', "Cím fordított feltétel");
DEFINE('_JW_GOALS_USERNAME_INVERSED', "Felhasználó fordított feltétel");
DEFINE('_JW_GOALS_CAME_FROM_INVERSED', "Fordított feltételb&#337;l érkezett");

DEFINE('_JW_STATS_MAP', "Utoljára látogatott térkép");
DEFINE('_JW_STATS_MAP_ENTER_KEY',"Írja be <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a> kulcs kiírni az utoljára látogatott térképet:");
DEFINE('_JW_STATS_MAP_STORE_KEY',"eltárolás kulcs");
DEFINE('_JW_STATS_MAP_INVALID_KEY',"Írjon be egy létez&#337; ipinfodb kulcsot, amit itt kapott: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");

DEFINE('_JW_SIZEQUERY_BAD_REQUEST',"HIBÁS KÉRDÉS: ");

DEFINE('_JW_VISIT_SUBMITED_FIELDS',"Mez&#337;kr&#337;l érkez&#337; adat:");
DEFINE('_JW_VISIT_URL_PARAMETERS',"URL paraméterek:");
DEFINE('_JW_VISIT_ADD_PAGE'," Adja ezt az oldalt mint egy új cél");
DEFINE('_JW_VISIT_BLOCK_IP'," Blokkolja ezt az IP címet");
DEFINE('_JW_VISIT_SUBMITED_FROM_VARIABLE'," Adja ezt a változót mint egy cél");
DEFINE('_JW_VISIT_URL_PARAMETER_GOAL'," Adja ezt a URL paramétert mint egy cél");

DEFINE('_JW_TREND_EMPTY',"Üres");

DEFINE('_JW_NOT_NUMBER'," FIGYELEM: A megadott érték nem szám. JoomlaWatch nem fog rendesen m&#369;ködni!");
DEFINE('_JW_EVALUATION_LEFT',"&nbsp; Ez a 15-nap próbaid&#337;s verzió. Napok maradtak: <b>%d</b>. Rendelje meg a végleges verziót <a href='http://www.codegravity.com/donate/joomlawatch/' target='_blank'>JoomlaWatch license az Ön domain-jára</a> a mostani és jöv&#337;beni verziókra.");
DEFINE('_JW_TRIAL_VERSION_EXPIRED'," Az Ön próbaideje lejárt. Kérjük rendelje meg JoomlaWatch-ot");

DEFINE('_JW_CONFIG_LICENSE_ACTIVATED',"A License aktiváció sikeres volt. Köszönjük.");
DEFINE('_JW_CONFIG_LICENCE_DONT_MATCH',"<b>Hiba: A license kulcs az Ön domain-jával nem egyezik.</b><br/>Ugyanazt a domain-t írta be megrendeléskor, mint amit itt lent lát? <br/>Click '<b>Kérjen egy valós aktivációs kulcsot</b>' lent, vagy írjon: info@codegravity.com<br/>");

DEFINE('_JW_VIEW_ADMINBODY_LONG_MESSAGE',"Ha az üzenet fent tól hosszú, valami hiba van az él&#337; adatokkal. Nyissa meg a components/com_joomlawatch/config.php , és állítsa be saját adatait. Pl.:
define('JOOMLAWATCH_LIVE_SITE', 'http://www.codegravity.com');");

DEFINE('_JW_ADMINBODY_LIVE_SITE',"Figyelem: cím a böngész&#337;ben és az él&#337; cím a konfigurációban: %s és %s nem egyezik.");
DEFINE('_JW_ADMINBODY_SET_LIVE_SITE',"Állítsa be az él&#337; címet: %s és folytassa...");

DEFINE('_JW_ADMINHEADER_JW',"JoomlaWatch ");
DEFINE('_JW_ADMINHEADER_REMOVE_BACKLINK',"Hátsólink eltávolítás");
DEFINE('_JW_ADMINHEADER_KNOWLEDGE_BASE',"Tudás-bázis");
DEFINE('_JW_ADMINHEADER_FLOW',"Folyamat");
DEFINE('_JW_ADMINHEADER_GRAPHS',"Grafika");
DEFINE('_JW_ADMINHEADER_COMPONENTS',"Komponensek");
DEFINE('_JW_ADMINHEADER_REVIEW',"Nézet");
DEFINE('_JW_ADMINHEADER_WRITE',"Írjon ");

DEFINE('_JW_FLOW_TRAFFIC',"Forgalom Folyamat");
DEFINE('_JW_FLOW_SELECT_PAGE',"Válassza ki az oldalt:");
DEFINE('_JW_FLOW_OUTG_LINKS',"Gyökér kimen&#337; linkek száma:");
DEFINE('_JW_FLOW_NESTING',"Beágyazások szintje:");
DEFINE('_JW_FLOW_SCALE',"Skála:");

DEFINE('_JW_COMERCIAL_AD_FREE',"Reklámmentes verzió");
DEFINE('_JW_COMERCIAL_THANK_DONATION',"Köszönjük hozzájárulását!");
DEFINE('_JW_COMERCIAL_REGISTRATION_KEY',"A regisztrációs kulcs az Ön domain-jára %s : ");
DEFINE('_JW_COMERCIAL_BACKLINKS_REMOVE',"Most már eltávolíthatja a hátsó-linket, vagy eltüntetheti JoomlaWatch logót a képerny&#337;r&#337;l a Beállításokban ");


DEFINE('_JW_SIZES_LAST_CHECK',"Utolsó ellen&#337;rzés volt:");
DEFINE('_JW_SIZES_ADMINISTRATOR',"KÉK = A komponens mérete/modul /administrator könyvtár");

DEFINE('_JW_SIZECOMPONENTS_COMPONENT',"Komponens");
DEFINE('_JW_SIZECOMPONENTS_TOTAL',"Összesen:");
DEFINE('_JW_SIZECOMPONENTS_SIZE',"Méret");
DEFINE('_JW_SIZECOMPONENTS_REFRESH_ALL',"Mindent újraír");

DEFINE('_JW_SIZEDATABASE_TABLE',"Tábla");
DEFINE('_JW_SIZEDATABASE_SIZE',"Méret");
DEFINE('_JW_SIZEDATABASE_1DAY',"1-Nap Változás");
DEFINE('_JW_SIZEDATABASE_7DAY',"7-Nap Változás");
DEFINE('_JW_SIZEDATABASE_28DAY',"28-Nap Változás");
DEFINE('_JW_SIZEDATABASE_NO_DATA',"nincs adat");
DEFINE('_JW_SIZEDATABASE_TOTAL',"Összesen:");

DEFINE('_JW_SIZEMODULES_REFRESH_ALL',"Mindent újraír");
DEFINE('_JW_SIZEMODULES_TOTAL',"Összesen:");
DEFINE('_JW_SIZEMODULES_MODULE',"Modul");
DEFINE('_JW_SIZEMODULES_SIZE',"Méret");

DEFINE('_JW_SIZES_FILES',"Állományok és Könyvtárak");
DEFINE('_JW_SIZES_BYTES',"byte-ok");
DEFINE('_JW_SIZES_KB',"KB");
DEFINE('_JW_SIZES_MB',"MB");
DEFINE('_JW_SIZES_GB',"GB");
DEFINE('_JW_SIZES_REFRESH',"Újraolvas");

DEFINE('_JW_STATS_FOOTER',"JoomlaWatch &copy;2006-@YEAR@ by Matej Koval");

DEFINE('_JW_STATUS_MB',"MB");
DEFINE('_JW_STATUS_DATABASE',"Adatbázis tábla méretek");


DEFINE('_JW_DESC_IPINFODB_KEY',"Utolsó látogatás ipinfodb.com kulcs: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");
DEFINE('_JW_SETTINGS_FORCE_TIMEZONE_OFFSET',"Er&#337;ltetett Id&#337;zóna Eltérés");


/* JoomlaWatch 1.2.17 translations */
DEFINE('_JW_MENU_UPDATE', "Program Frissítés");
DEFINE('_JW_MENU_UPDATE_TITLE', "Mentés & Program frissítés");
DEFINE('_JW_ADMINHEADER_NA_IN_THIS_VERSION',"Ingyenes verzióban nem m&#369;ködik, nézze meg a License üzenetet");
DEFINE('_JW_SPAMWORD_BANS_ENABLED', "Spam szavak letiltás engedélyezése");
DEFINE('_JW_SPAMWORD_LIST', "Spam szavak listája");
DEFINE('_JW_HIDE_REPETITIVE_TITLE', "Ismételt címek elrejtése");
DEFINE('_JW_TRUNCATE_VISITS', "Látogatók lerövödítése");
DEFINE('_JW_TRUNCATE_STATS', "Statisztikák lerövidítése");
DEFINE('_JW_TRUNCATE_GOALS', "Célok lerövidítése");
DEFINE('_JW_LIMIT_BOTS', "Programok (bot) limitálása");
DEFINE('_JW_LIMIT_VISITORS', "Látogatók limitálása");
DEFINE('_JW_TOOLTIP_WIDTH', "Használati tippek szélessége");
DEFINE('_JW_TOOLTIP_HEIGHT', "Használati tippek magassága");
DEFINE('_JW_TOOLTIP_URL', "Használati tipp URL");
DEFINE('_JW_TOOLTIP_ONCLICK', "Használati tipp klikkelése");
DEFINE('_JW_IP_STATS', "IP statisztikák");
DEFINE('_JW_IPINFODB_KEY', "IP információ adatbázis kulcs ");
DEFINE('_JW_ONLY_LAST_URI', "Csak az utolsó URI ");

DEFINE('_JW_FRONTEND_HIDE_LOGO', "Logo eltüntetése a képerny&#337;n ");
DEFINE('_JW_FRONTEND_NOFOLLOW', "Követés eltüntetése a képerny&#337;n");
DEFINE('_JW_FRONTEND_NO_BACKLINK', "Link eltüntetése a képerny&#337;n");
DEFINE('_JW_FRONTEND_USER_LINK', "Látható felhasználók linkjei");
DEFINE('_JW_FRONTEND_COUNTRIES_FIRST', "Országok el&#337;ször");
DEFINE('_JW_FRONTEND_COUNTRIES_NAMES', "Országok nevei");
DEFINE('_JW_FRONTEND_COUNTRIES_UPPERCASE', "Országok nevei nagybet&#369;kkel");
DEFINE('_JW_FRONTEND_COUNTRIES_FLAGS_FIRST', "Országok zászlói el&#337;ször ");
DEFINE('_JW_FRONTEND_COUNTRIES_NUM', "Látható országok száma");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_COLUMNS', "Országok maximális oszlopai");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_ROWS', "Országok maximális sorai");
DEFINE('_JW_FRONTEND_VISITORS_TODAY', "Látható látogatók ma ");
DEFINE('_JW_FRONTEND_VISITORS_YESTERDAY', "Látogatók tegnap ");
DEFINE('_JW_FRONTEND_VISITORS_THIS_WEEK', "Látogatók ezen a héten ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_WEEK', "Látogatók múlt héten ");

DEFINE('_JW_FRONTEND_VISITORS_THIS_MONTH', "Látogatók ebben a hónapban ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_MONTH', "Látogatók a múlt hónapban");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL', "Nem látható látogatók összesen");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL ', "Látogató összes kezd&#337;érték");
DEFINE('_JW_HISTORY_MAX_VALUES', "Történeti maximum értékek");
DEFINE('_JW_HISTORY_MAX_DB_RECORDS', "Történeti maximum adatbázis értékek");
DEFINE('_JW_UPDATE_TIME_VISITS', "Látogatások idejének felülírása");
DEFINE('_JW_UPDATE_TIME_STATS', "Statisztikák idejének felülírása");
DEFINE('_JW_STATS_MAX_ROWS', "Maximális sorok száma");
DEFINE('_JW_STATS_IP_HITS', "IP találatok száma");
DEFINE('_JW_MAXID_BOTS', "Maximum ID bots");
DEFINE('_JW_MAXID_VISITORS', "Maximum látogatók");
DEFINE('_JW_STATS_KEEP_DAYS', "Statisztikák tárolásának ideje napokban ");
DEFINE('_JW_CACHE_FRONTEND_COUNTRIES', "Képerny&#337; országok tárolása ");
DEFINE('_JW_CACHE_FRONTEND_VISITORS', "Képerny&#337; látogatók tárolása ");

DEFINE('_JW_UNINSTALL_KEEP_DATA ', "Adatok megtartásának letiltása ");
DEFINE('_JW_IGNORE_IP', "IP ignorálása");
DEFINE('_JW_IGNORE_URI', "URI ignorálása");
DEFINE('_JW_IGNORE_USER', "Felhasználó ignorálása");
DEFINE('_JW_BLOCKING_MESSAGE', "Üzenet blokkolása");
DEFINE('_JW_SERVER_URI_KEY', "Szerver URI kulcs");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL', "Látogatók összes kezd&#337;érték");
DEFINE('_JW_SIZEDATABASE_RECORDS', "Adattételek");
/***********EDITs******************/
DEFINE('_JW_ANTISPAM_BLOCKING_TEXT'," A blokkolás úgy lesz effektív, ha publikálja JoomlaWatch agent-et MIEL&#336;TT tartalom vagy adatlapok. Pl. a template baloldalán.
<br/>
Go to Module Manager -> JoomlaWatch agent -> select position as left");

DEFINE('_JW_EMAIL_SEO_REPORTS', "SEO Riportok");
DEFINE('_JW_DESC_EMAIL_SEO_REPORTS_ENABLED',"SEO Éjszakai riportok engedélyezése");
DEFINE('_JW_WATCH_INSTALLATION_DEMO',"Nézze meg az installálási demo-t.");

?>

