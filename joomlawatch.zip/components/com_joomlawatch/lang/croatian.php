﻿<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version @VERSION@
 * @revision @REVISION@
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) @YEAR@ by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/
defined( '_JEXEC' ) or die( 'Ograničen pristup' );

#JoomlaWatch language file - to create a new language file, just copy the english.php to eg. german.php and place into /components/com_joomlawatch/lang/

# Main Menu
DEFINE('_JW_MENU_STATS', "Statistika uživo");
DEFINE('_JW_MENU_GOALS', "Ciljevi");
DEFINE('_JW_MENU_SETTINGS', "Postavke");
DEFINE('_JW_MENU_CREDITS', "Credits");
DEFINE('_JW_MENU_FAQ', "CPP");
DEFINE('_JW_MENU_DOCUMENTATION', "Dokumentacija");
DEFINE('_JW_MENU_LICENSE', "Licenca");
DEFINE('_JW_MENU_DONATORS', "Donatori");
DEFINE('_JW_MENU_SUPPORT', "Podrži JoomlaWatch i makni reklame sa backenda.");


# Left visitors real-time window
DEFINE('_JW_VISITS_VISITORS', "Najnoviji posjetitelji");
DEFINE('_JW_VISITS_BOTS', "Botovi");
DEFINE('_JW_VISITS_CAME_FROM', "Dolazi iz");
DEFINE('_JW_VISITS_MODULE_NOT_PUBLISHED', "Vas JoomlaWatch module nije objavljen! Nove statistike se ne bilježe. Za objavljivanje idite na sekciju Moduli i objavite na svim stranicama");
DEFINE('_JW_VISITS_PANE_LOADING', "Učitavanje posjeta...");

# Right stats window
DEFINE('_JW_STATS_TITLE', "Tjedna statistika posjetitelja.");
DEFINE('_JW_STATS_WEEK', "Tjedan");
DEFINE('_JW_STATS_THIS_WEEK', "ovaj tjedan");
DEFINE('_JW_STATS_UNIQUE', "jedinstveni");
DEFINE('_JW_STATS_LOADS', "opterećenja");
DEFINE('_JW_STATS_HITS', "pregledi");
DEFINE('_JW_STATS_TODAY', "danas");
DEFINE('_JW_STATS_FOR', "za");
DEFINE('_JW_STATS_ALL_TIME', "Ukupno vrijeme");
DEFINE('_JW_STATS_EXPAND', "proširi");
DEFINE('_JW_STATS_COLLAPSE', "uruši");
DEFINE('_JW_STATS_URI', "Stranice");
DEFINE('_JW_STATS_COUNTRY', "Države");
DEFINE('_JW_STATS_USERS', "Korisnici");
DEFINE('_JW_STATS_REFERERS', "Pozivatelji");
DEFINE('_JW_STATS_IP', "IP adrese");
DEFINE('_JW_STATS_BROWSER', "Preglednici");
DEFINE('_JW_STATS_OS', "Operacijski sustavi");
DEFINE('_JW_STATS_KEYWORDS', "Ključne riječi");
DEFINE('_JW_STATS_GOALS', "Ciljevi");
DEFINE('_JW_STATS_TOTAL', "Ukupno");
DEFINE('_JW_STATS_DAILY', "Dnevno");
DEFINE('_JW_STATS_DAILY_TITLE', "Dnevna statistika");
DEFINE('_JW_STATS_ALL_TIME_TITLE', "Ukupna statistika");
DEFINE('_JW_STATS_LOADING', "učitavanje...");
DEFINE('_JW_STATS_LOADING_WAIT', "učitavanje... molimo pričekajte");
DEFINE('_JW_STATS_IP_BLOCKING_TITLE', "IP blokiranje");
DEFINE('_JW_STATS_IP_BLOCKING_ENTER', "Unesi IP");
DEFINE('_JW_STATS_IP_BLOCKING_MANUALLY', "Unesite IP koji želite blokirati. (npr. 217.242.11.54 ili 217.* ili 217.242.* za blokiranje svih IP adresa koje odgovaraju zamjenskom znaku)");
DEFINE('_JW_STATS_IP_BLOCKING_TOGGLE', "Podešavanje blokiranja");
DEFINE('_JW_STATS_PANE_LOADING', "Učitavanje statistike...");

# Settings
DEFINE('_JW_SETTINGS_TITLE', "Postavke");
DEFINE('_JW_SETTINGS_DEFAULT', "Početne postavke");
DEFINE('_JW_SETTINGS_SAVE', "Spremi");
DEFINE('_JW_SETTINGS_APPEARANCE', "Izgled");
DEFINE('_JW_SETTINGS_FRONTEND', "Frontend");
DEFINE('_JW_SETTINGS_HISTORY_PERFORMANCE', "Povijest &amp;amp; Performansa");
DEFINE('_JW_SETTINGS_ADVANCED', "Napredno");
DEFINE('_JW_SETTINGS_IGNORE', "Ignoriraj");
DEFINE('_JW_SETTINGS_BLOCKING', "Blokiranje");
DEFINE('_JW_SETTINGS_EXPERT', "Najnaprednije");
DEFINE('_JW_SETTINGS_RESET_CONFIRM', "Želite li zaista poništiti podatke o posjetiteljima i statistiku?");
DEFINE('_JW_SETTINGS_RESET_ALL', "Poništi sve");
DEFINE('_JW_SETTINGS_RESET_ALL_LINK', "Poništi sve statistike &amp;amp; podatke posjetitelja");
DEFINE('_JW_SETTINGS_LANGUAGE', "Jezik");
DEFINE('_JW_SETTINGS_SAVED', "Postavke spremljene");
DEFINE('_JW_SETTINGS_ADD_YOUR_IP', "Dodaj IP");
DEFINE('_JW_SETTINGS_TO_THE_LIST', "na listu.");

# Other / mostly general
DEFINE('_JW_TITLE', "AJAX joomla monitor uživo");
DEFINE('_JW_BACK', "Natrag");
DEFINE('_JW_ACCESS_DENIED', "Nemate ovlasti za pregledavanje ovog!");
DEFINE('_JW_LICENSE_AGREE', "Prihvaćam odredbe &amp;amp; uvjete korištenja");
DEFINE('_JW_LICENSE_CONTINUE', "Nastavak");
DEFINE('_JW_SUCCESS', "Rad uspješno obavljen");
DEFINE('_JW_RESET_SUCCESS', "Statistike i podaci posjetitelja su uspješno obrisani");
DEFINE('_JW_RESET_ERROR', "Podaci NISU uspješno obrisani, nešto je pošlo po krivu");
DEFINE('_JW_CREDITS_TITLE', "Zasluge");
DEFINE('_JW_TRENDS_DAILY_WEEKLY', "Dnevna i tjedna statistika");
DEFINE('_JW_AJAX_PERMISSION_DENIED_1', "AJAX dozvola odbijena: Molimo pogledajte statistike domene koja je navedena u configuration.php joomle - ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_2', "Možda ste zaboravili www. ispred domene. Vas javascript pokušava pristupiti ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_3', "iz");
DEFINE('_JW_AJAX_PERMISSION_DENIED_4', "zbog čega misli da je to druga domena.");

# Header
DEFINE('_JW_HEADER_DOWNLOAD', "Preuzmite posljednji kod proširenja");
DEFINE('_JW_HEADER_CAST_YOUR', "Molimo, dajte svoj");
DEFINE('_JW_HEADER_VOTE', "glas");

# Tooltips
DEFINE('_JW_TOOLTIP_CLICK', "Kliknite za prikaz opisa alata");
DEFINE('_JW_TOOLTIP_MOUSE_OVER', "Usmjerite pokazivač preko za pregled opisa alata");
DEFINE('_JW_TOOLTIP_YESTERDAY_INCREASE', "jučerašnji porast");
DEFINE('_JW_TOOLTIP_HELP', "Otvara online pomoć za");
DEFINE('_JW_TOOLTIP_WINDOW_CLOSE', "Zatvori prozor");
DEFINE('_JW_TOOLTIP_PRINT', "Printaj");

# Goals
DEFINE('_JW_GOALS_INSERT', "Unesite novi cilj");
DEFINE('_JW_GOALS_UPDATE', "Azurirajte cilj br.");
DEFINE('_JW_GOALS_ACTION', "Radnja");
DEFINE('_JW_GOALS_TITLE', "Novi cilj");
DEFINE('_JW_GOALS_NEW', "Novi cilj");
DEFINE('_JW_GOALS_RELOAD', "Učitaj ponovno");
DEFINE('_JW_GOALS_ADVANCED', "Napredno");
DEFINE('_JW_GOALS_NAME', "Naziv");
DEFINE('_JW_GOALS_ID', "id");
DEFINE('_JW_GOALS_URI_CONDITION', "URI uvjet");
DEFINE('_JW_GOALS_URI_INVERSED', "URI suprotan uvjet");
DEFINE('_JW_GOALS_GET_VAR', "GET varijabla");
DEFINE('_JW_GOALS_GET_CONDITION', "GET uvjet");
DEFINE('_JW_GOALS_POST_VAR', "POST Varijabla");
DEFINE('_JW_GOALS_POST_CONDITION', "POST uvjet");
DEFINE('_JW_GOALS_TITLE_CONDITION', "Uvjet naslova");
DEFINE('_JW_GOALS_USERNAME_CONDITION', "Uvjet korisničkog imena");
DEFINE('_JW_GOALS_IP_CONDITION', "IP uvjet");
DEFINE('_JW_GOALS_IP_INVERSED', "IP suprotan uvjet");
DEFINE('_JW_GOALS_CAME_FROM_CONDITION', "Dolazi iz uvjeta");
DEFINE('_JW_GOALS_BLOCK', "Blokiraj");
DEFINE('_JW_GOALS_REDIRECT', "Preusmjeri na URL");
DEFINE('_JW_GOALS_HITS', "Sadržaj pregledan");
DEFINE('_JW_GOALS_ENABLED', "Omogućeno");
DEFINE('_JW_GOALS_EDIT', "Uredi");
DEFINE('_JW_GOALS_DELETE', "Obriši");
DEFINE('_JW_GOALS_DELETE_CONFIRM', "Izgubit ćete sve statističke podatke za ovaj cilj. Jeste li sigurni da želite obrisati cilj br.");

# Frontend
DEFINE('_JW_FRONTEND_COUNTRIES', "Države");
DEFINE('_JW_FRONTEND_VISITORS', "Posjetitelji");
DEFINE('_JW_FRONTEND_TODAY', "Danas");
DEFINE('_JW_FRONTEND_YESTERDAY', "Jučer");
DEFINE('_JW_FRONTEND_THIS_WEEK', "Ovaj tjedan");
DEFINE('_JW_FRONTEND_LAST_WEEK', "Prošli tjedan");
DEFINE('_JW_FRONTEND_THIS_MONTH', "Ovaj mjesec");
DEFINE('_JW_FRONTEND_LAST_MONTH', "Prošli mjesec");
DEFINE('_JW_FRONTEND_TOTAL', "Ukupno");

# Settings description - quite long
DEFINE('_JW_DESC_DEBUG', "JoomlaWatch je u debug načinu rada. Ovim načinom možete otkriti uzrok grešaka. Za isključivanje ovog načina rada promijenite vrijednost JOOMLAWATCH_DEBUG u /components/com_joomlawatch/config.php sa 1 na 0");
DEFINE('_JW_DESC_STATS_MAX_ROWS', "Najveći broj redova koji se prikazuju kad su statistike u proširenom načinu rada.");
DEFINE('_JW_DESC_STATS_IP_HITS', "Sve IP adrese koje prethodnih dana imaju manje pregleda od zadane vrijednosti bit će obrisane iz povijesti IP adresa.");
DEFINE('_JW_DESC_STATS_URL_HITS', "Svi URL-ovi koji prethodnih dana imaju manje pregleda od zadane vrijednosti bit će obrisane iz povijesti IP adresa.");
DEFINE('_JW_DESC_IGNORE_IP', "Izuzmi određenu IP adresu iz statistike. Razmaknuti novim redom. Možete koristiti zamjenske znakove. &lt;br/&gt;npr. 192.* će ignorirati 192.168.51.31, 192.168.16.2, itd..");
DEFINE('_JW_DESC_UPDATE_TIME_VISITS', "Vrijeme osvježavanja za posjetitelje u milisekundama, zadana vrijednost je 2000, oprez s ovim. Na kraju ponovno učitajte JoomlaWatch backend.");
DEFINE('_JW_DESC_UPDATE_TIME_STATS', "Vrijeme osvježavanja statistike u milisekundama,zadana vrijednost je 4000, oprez s ovim. Na kraju ponovno učitajte JoomlaWatch backend.");
DEFINE('_JW_DESC_MAXID_BOTS', "Koliko posjeta botova sačuvati u bazi podataka.");
DEFINE('_JW_DESC_MAXID_VISITORS', "Koliko stvarnih posjeta sačuvati u bazi podataka.");
DEFINE('_JW_DESC_LIMIT_BOTS', "Količina vidljivih botova u backend-u.");
DEFINE('_JW_DESC_LIMIT_VISITORS', "Količina stvarnih posjeta vidljivih u backend-u.");
DEFINE('_JW_DESC_TRUNCATE_VISITS', "Najveća količina znakova vidljivih u dugim naslovima i adresama.");
DEFINE('_JW_DESC_TRUNCATE_STATS', "Najveća količina znakova vidljiva u desnoj statističkoj ploči.");
DEFINE('_JW_DESC_STATS_KEEP_DAYS', "Količina dana za čuvanje statistike u bazi podataka, 0 = beskonačno.");
DEFINE('_JW_DESC_TIMEZONE_OFFSET', "Ukoliko se nalazite u drukčijoj vremenskoj zoni od servera. (pozitivne ili negativne vrijednosti u satima)");
DEFINE('_JW_DESC_WEEK_OFFSET', "Tjedni pomak, vremenska oznaka/(3600*24*7) daje tjednu broj od 1.1.1970, ovaj pomak je ispravka kako bi polazilo od ponedjeljka ");
DEFINE('_JW_DESC_DAY_OFFSET', "Dnevni pomak, vremenska oznaka/(3600*24) daje danu broj od 1.1.1970, ovaj pomak je ispravka kako bi polazilo od 00:00 ");
DEFINE('_JW_DESC_FRONTEND_HIDE_LOGO', "&lt;b&gt;(radi u PRO verzoji)&lt;/b&gt; Korištenje prazne 1x1px ikone u frontend-u");
DEFINE('_JW_DESC_IP_STATS', "Za omogućavanje statistike IP adresa. U nekim je državama čuvanje IP adrese u bazi podataka na duže vrijeme zakonom zabranjeno. Korištenje na vlastitu odgovornost.");
DEFINE('_JW_DESC_HIDE_ADS', "Ova postavka skriva reklame u backend-u, ukoliko Vam zaista smetaju. Ako ih ostavite, podržavate daljnje razvijanje ovog alata. Hvala");
DEFINE('_JW_DESC_TOOLTIP_ONCLICK', "Odznačite ukoliko želite vidjeti opis alata usmjerivanjem pokazivača umjesto klikom.");
DEFINE('_JW_DESC_SERVER_URI_KEY', "Zadana vrijednost je 'REDIRECT_URL', sto je norma za prepisivanje url-a, može se postaviti 'SCRIPT_URL' ukoliko bilježi samo index.php");
DEFINE('_JW_DESC_BLOCKING_MESSAGE', "Poruka vidljiva blokiranim korisnicima ili objašnjenje razloga blokiranja.");
DEFINE('_JW_DESC_TOOLTIP_WIDTH', "Širina opisa alata");
DEFINE('_JW_DESC_TOOLTIP_HEIGHT', "Visina opisa alata");
DEFINE('_JW_DESC_TOOLTIP_URL', "Za vizualiziranje posjetiteljeve IP adrese, ovdje možete postaviti bilo koji URL. IP adresa {ip} bit će zamijenjena posjetiteljevom IP adresom. Npr. http://somewebsite.com/query?iplookup={ip}");
DEFINE('_JW_DESC_IGNORE_URI', "Ovdje možete postaviti bilo koji URI za kojeg želite da bude izuzet iz statistike. Možete koristiti zamjenske znakove (* i ?). Npr.: /freel?n* ");
DEFINE('_JW_DESC_GOALS_NAME', "Upisite naziv cilja. Ovaj naziv bit će prikazan u statistikama.");
DEFINE('_JW_DESC_GOALS_URI_CONDITION', "Sve što je iza imena domene. Za http://www.codegravity.com/projects/ URI je: /projects/ (Primjer korištenja: &lt;b&gt;/projects*&lt;/b&gt;)");
DEFINE('_JW_DESC_GOALS_GET_VAR', "GET varijabla je varijabla koju možete vidjeti u URL-u iza ? ili &amp;amp; znaka. Npr. http://www.codegravity.com/index.php?&lt;u&gt;name&lt;/u&gt;=peter&amp;amp;&lt;u&gt;surname&lt;/u&gt;=smith. Smijete koristiti i &lt;u&gt;*&lt;/u&gt; u ovom polju kako bi pretražili sve get vrijednosti. (Primjer korištenja: &lt;b&gt;n*me&lt;/b&gt;)");
DEFINE('_JW_DESC_GOALS_GET_CONDITION', "Ovdje morate navesti podudarnost za vrijednost s prethodnog polja. (Primjer korištenja: &lt;b&gt;p?t*r&lt;/b&gt;) ");
DEFINE('_JW_DESC_GOALS_POST_VAR', "Slično ali ovdje se provjeravaju vrijednosti poslane obrascima. Ako imate obrazac koji ima polje &amp;lt;input type='text' name='&lt;u&gt;experiences&lt;/u&gt;' /&amp;gt;. (Primjer korištenja: &lt;b&gt;exper*ces&lt;/b&gt;)");
DEFINE('_JW_DESC_GOALS_POST_CONDITION', "Podudarnost za vrijednost ovog POST polja. Npr. želimo provjeriti ako korisnik ima iskustva u javi. (Primjer korištenja: &lt;b&gt;*java*&lt;/b&gt;)");
DEFINE('_JW_DESC_GOALS_TITLE_CONDITION', "Naziv stranice koja se mora podudarati. (Primjer korištenja: &lt;b&gt;*freelance programmers*&lt;/b&gt;)");
DEFINE('_JW_DESC_GOALS_USERNAME_CONDITION', "Ime ulogiranog korisnika. (Primjer korištenja: &lt;b&gt;psmith*&lt;/b&gt;)");
DEFINE('_JW_DESC_GOALS_IP_CONDITION', "IP adresa s koje korisnik pristupa: (Primjer korištenja: &lt;b&gt;201.9?.*.*&lt;/b&gt;)");
DEFINE('_JW_DESC_GOALS_CAME_FROM_CONDITION', "URL s kojeg korisnik pristupa. (Primjer korištenja: &lt;b&gt;*www.google.*&lt;/b&gt;)");
DEFINE('_JW_DESC_GOALS_REDIRECT', "Korisnik je preusmjeren na URL koji ste naveli. Veći prioritet od blokiranja: (Primjer korištenja: &lt;b&gt;http://www.codegravity.com/goaway.html&lt;/b&gt;)");
DEFINE('_JW_DESC_TRUNCATE_GOALS', "Koliko znakova odrezati u tablici ciljeva");
DEFINE('_JW_DESC_FRONTEND_NO_BACKLINK', "&lt;b&gt;(radi u PRO verziji)&lt;/b&gt; Povratna poveznica na codegravity.com, mozete onemogućiti ali mi bi radije da to ostavite. Hvala");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES', "Prikaži ukupne statistike država u frontend modulu. Ako je promijenjeno, ova će postavka biti na snazi nakon vremena postavljenog u CACHE_FRONTEND_ ");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FIRST', "Ukoliko želite zamijeniti redoslijed Posjeta/Država u frontend-u. Ako odznačite, Posjetitelj će se prikazivati prvi.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NUM', "Broj država prikazanih u frontend-u");
DEFINE('_JW_DESC_FRONTEND_VISITORS', "Prikaži posjetitelje države u frontend modulu. Ako je promijenjeno, ova će postavka biti na snazi nakon vremena postavljenog u CACHE_FRONTEND_");
DEFINE('_JW_DESC_CACHE_FRONTEND_COUNTRIES', "Vrijeme u sekundama za spremanje u predmemoriju ukupnih država na frontend-u");
DEFINE('_JW_DESC_CACHE_FRONTEND_VISITORS', "Vrijeme u sekundama za spremanje u predmemoriju posjetitelja na frontend-u");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TODAY', "Za prikazivanje posjetitelja na frontend-u za: danas. Ako je promijenjeno, ova će postavka biti na snazi nakon vremena postavljenog u CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_YESTERDAY', "Za prikazivanje posjetitelja na frontend-u za: jučer. Ako je promijenjeno, ova će postavka biti na snazi nakon vremena postavljenog u CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_WEEK', "Za prikazivanje posjetitelja na frontend-u za: ovaj tjedan. Ako je promijenjeno, ova će postavka biti na snazi nakon vremena postavljenog u CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_WEEK', "Za prikazivanje posjetitelja na frontend-u za: prošli tjedan. Ako je promijenjeno, ova će postavka biti na snazi nakon vremena postavljenog u CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_MONTH', "Za prikazivanje posjetitelja na frontend-u za: ovaj mjesec. Ako je promijenjeno, ova će postavka biti na snazi nakon vremena postavljenog u CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_MONTH', "Za prikazivanje posjetitelja na frontend-u za: prošli mjesec. Ako je promijenjeno, ova će postavka biti na snazi nakon vremena postavljenog u CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL', "Za prikazivanje ukupnog broja posjetitelja od JoomlaWatch instalacije. Ako je promijenjeno, ova će postavka biti na snazi nakon vremena postavljenog u CACHE_FRONTEND_...");
DEFINE('_JW_DESC_LANGUAGE', "Datoteka jezika koja se koristi. Smještene su u /components/com_joomlawatch/lang/. Ako želite napraviti novu datoteku jezika, prvo provjerite stranicu projekta, a ako je tamo nema, kopirajte i preimenujte sa english.php na pr. german.php i smjestite u ovu mapu. Tada prevedite sve vrijednosti sa desne strane.");
DEFINE('_JW_DESC_GOALS', "Ciljevi Vam omogućavaju da precizirate posebne parametre. Kad se ti parametri podudaraju, brojač ciljeva se uvećava. Ovim načinom možete provjeravati ako je korisnik posjetio određeni URL, odaslao određenu vrijednost, ima određeno korisničko ime ili stiže s određene adrese. Tim možete blokirati ili preusmjeriti korisnike na neki drugi URL.");
DEFINE('_JW_DESC_GOALS_INSERT', "U svim poljima osim naziva možete koristiti * i ? kao zamjenske znakove. Npr: ?ear (podudarat će se: near, tear, ..),  p*r (podudarat će se: pr, peer, pear ..) ");
DEFINE('_JW_DESC_GOALS_BLOCK', "Podesiti na 1 ukoliko želite blokirati posjetitelja. Tada neće vidjeti sadržaj već samo obavijest da je blokiran - bez preusmjeravanja i njegova IP adresa je dodana u blokirane statistike (Primjer za korištenje: &lt;b&gt;1&lt;/b&gt;)");

/* new translations */
DEFINE('_JW_GOALS_COUNTRY_CONDITION', "Uvjet za državu");
DEFINE('_JW_GOALS_CONTRY_INVERSED', "Suprotni uvjet za državu");
DEFINE('_JW_DESC_GOALS_COUNTRY_CONDITION', "Dvoslovni kod države velikim slovima (Npr: &lt;b&gt;TH&lt;/b&gt;)");
DEFINE('_JW_STATS_INTERNAL',"Interno");
DEFINE('_JW_STATS_FROM',"Od");
DEFINE('_JW_STATS_TO',"Za");
DEFINE('_JW_STATS_ADD_TO_GOALS',"Dodaj ciljevima");
DEFINE('_JW_VISITS_ADD_GOAL_COUNTRY',"Dodaj cilj za ovu državu");
DEFINE('_JW_MENU_REPORT_BUG',"Prijavi grešku ili značajku");
DEFINE('_JW_GOALS_COUNTRY',"Država");


/* translations 1.2.8b_12 */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_UPPERCASE',"Ukoliko želite imena država velikim slovima u frontend-u (Npr: GERMANY, UNITED KINGDOM umjesto Germany, United Kingdom)");
DEFINE('_JW_DESC_CACHE_FRONTEND_USERS',"Vrijeme u sekundama za spremanje u predmemoriju korisnika u frontend-u");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL_INITIAL', "Početna vrijednost prikaza u Ukupno: na frontend-u. Korisno ako migrirate sa drugog statističkog alata. (Npr.: 20000). Vratiti na 0 ukoliko ne želite koristiti ovu mogućnost.");
DEFINE('_JW_DESC_IGNORE_USER', "Ignoriraj korisnike navedene u ovom tekstnom okviru. Jedan po liniji. (Npr.: myself {nova linija} mark_*) ");
DEFINE('_JW_FRONTEND_USERS_MOST', "Najviše aktivnih korisnika danas od ukupnog");
DEFINE('_JW_DESC_SPAMWORD_BANS_ENABLED',"Omogući blokiranje u odnosu na riječi iz spam liste ispod ?");
DEFINE('_JW_DESC_SPAMWORD_LIST',"Najčešće spam riječi korištene od strane spam botova. Možete koristiti zamjenske znakove, (Npr.: ph?rmac*). Ako je postavka omogućena, JoomlaWatch će provjeriti je li napadač poslao obrazac sa spam riječima (HTTP POST zahtjev) na Vašoj stranici. (Odnosi se na to ako je obrazac na stranici koja se temelji na Joomli - forum, komentari, ali je prilično učinkovita za blokiranje spam botova koji pokušavaju poslati svaki obrazac)");
DEFINE('_JW_SETTINGS_ANTI_SPAM',"Anti-Spam");
DEFINE('_JW_DESC_FRONTEND_USER_LINK',"Poveznica na frontend korisničkom modulu - omogućava određivanje određenog URL-a koji je otvoren kad korisnik klikne na korisničko ime. Mora sadržavati niz podataka {korisnik}, koji ce biti zamijenjen stvarnim korisničkim imenom. (Npr. index.php?option=com_comprofiler&amp;task=userProfile&amp;user={user}) ");

/* translations 1.2.11b */
DEFINE('_JW_STATS_KEYPHRASE', "Ključni izrazi");
DEFINE('_JW_DESC_HISTORY_MAX_VALUES', "Najveća moguća vrijednost u kartici povijesti (Primjer: &lt;i&gt;100&lt;/i&gt;)");

DEFINE('_JW_DESC_ONLY_LAST_URI', "U posjetama prikaži samo posljednju stranicu, ne sve");
DEFINE('_JW_DESC_HIDE_REPETITIVE_TITLE', "U posjetama sakrij imena stranica koja se ponavljaju u naslovima posjećenih stranica");
DEFINE('_JW_DESC_HISTORY_MAX_DB_RECORDS', "Najveći mogući broj posjeta spremljenih u bazi podataka za prikaz povjesti posjetitelja. Oprezno s ovom postavkom, ako imate velik promet može jako brzo narasti. Uvijek provjerite koliko podataka sadrži tablica povijesti u Statusu");
DEFINE('_JW_DESC_UNINSTALL_KEEP_DATA', "Sačuvaj tablice baze podataka pri deinstalaciji. Označite ovu opciju prije deinstalacije ako želite sačuvati podatke pri nadogradnji.");

/* email reports */
DEFINE('_JW_DESC_EMAIL_REPORTS_ENABLED', "Primat ćete elektroničku poštu noću sa izviješćem o prethodnom danu koju možete pročitati ujutro");
DEFINE('_JW_DESC_EMAIL_REPORTS_ADDRESS', "Adresa elektroničke pošte na koju želite primati izviješća");
DEFINE('_JW_DESC_EMAIL_PERCENT_HIGHER_THAN', "Uključi redove u izviješću samo ako je postotak veći od {vrijednosti}. Podesiti na 0 ako ne želite koristiti ovu mogućnost &lt;i&gt;(primjer: 5)&lt;/i&gt;");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_POSITIVE', "Uključi samo &lt;b&gt;pozitivne dnevne&lt;/b&gt; promjene vrijednosti u izviješćima veće od {vrijednost} postotka. Podesiti na 0 ako ne želite koristiti ovu mogućnost &lt;i&gt;(primjer: 5)&lt;/i&gt;");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_NEGATIVE', "Uključi samo &lt;b&gt;negativne dnevne&lt;/b&gt; promjene vrijednosti u izviješćima manje od {vrijednost} postotka. Podesiti na 0 ako ne želite koristiti ovu mogućnost &lt;i&gt;(primjer: -10)&lt;/i&gt;");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_POSITIVE', "Uključi samo &lt;b&gt;pozitivne sedmodnevne&lt;/b&gt; promjene vrijednosti u izviješćima veće od {vrijednost} postotka. Podesiti na 0 ako ne želite koristiti ovu mogućnost &lt;i&gt;(primjer: 2)&lt;/i&gt;");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_NEGATIVE', "Uključi samo &lt;b&gt;negativne sedmodnevne&lt;/b&gt; promjene vrijednosti u izviješćima manje od {vrijednost} postotka. Podesiti na 0 ako ne želite koristiti ovu mogućnost &lt;i&gt;(primjer: -13)&lt;/i&gt;");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_POSITIVE', "Uključi samo &lt;b&gt;pozitivne 28-dnevne&lt;/b&gt; promjene vrijednosti u izviješćima veće od {vrijednost} postotka. Podesiti na 0 ako ne želite koristiti ovu mogućnost &lt;i&gt;(primjer: 2)&lt;/i&gt;");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_NEGATIVE', "Uključi samo &lt;b&gt;negativne 28-dnevne&lt;/b&gt; promjene vrijednosti u izviješćima manje od {vrijednost} postotka. Podesiti na 0 ako ne želite koristiti ovu mogućnost &lt;i&gt;(primjer: -13)&lt;/i&gt;");

DEFINE('_JW_DESC_FRONTEND_NOFOLLOW', "&lt;b&gt;(radi u PRO verziji)&lt;/b&gt; Omogućite ovu postavku ukoliko želite da poveznica loga ima atribut rel='nofollow' ");
DEFINE('_JW_DESC_EMAIL_NAME_TRUNCATE', "Najveći mogući broj znakova u nazivlju retka u elektroničkoj pošti. Promijenite ovo ukoliko je prozor Vašeg klijenta elektroničke pošte premalen");

DEFINE('_JW_MENU_HISTORY', "Povijest");
DEFINE('_JW_MENU_EMAILS', "Elektronička pošta");
DEFINE('_JW_MENU_STATUS', "Status baze podataka");
DEFINE('_JW_DESC_BLOCKED',"Anti-spam je blokirao ove IP adrese");


DEFINE('_JW_HISTORY_VISITORS',"Povjest posjetitelja");
DEFINE('_JW_HISTORY_SHOWING_ONLY', "Prikazuje samo %d posljednih zapisa.
                Za mijenjanje ove vrijednosti idite na postavke -&amp;gt; Povijest &amp;amp; Performanse -&amp;gt; HISTORY_MAX_DB_RECORDS . Pažljivo, ova postavka utječe na vrijeme učitavanja podataka ispod.  ");
DEFINE('_JW_MENU_BUG', "Prijavi grešku");
DEFINE('_JW_MENU_FEATURE', "Zatraži značajku");

DEFINE('_JW_VISITS_CAME_FROM_KEYWORDS',"Ključne riječi");

DEFINE('_JW_BLOCKING_UNBLOCK',"odblokiraj");
DEFINE('_JW_STATS_KEYPHRASE ',"Ključni izraz");

DEFINE('_JW_STATUS_DATABASE_TABLE_NAME',"ime tablice");
DEFINE('_JW_STATUS_DATABASE_ROWS',"redovi");
DEFINE('_JW_STATUS_DATABASE_DATA',"podatak");
DEFINE('_JW_STATUS_DATABASE_TOTAL',"ukupno");

DEFINE('_JW_EMAIL_REPORTS',"Izviješća elektroničke pošte");
DEFINE('_JW_EMAIL_REPORT_GENERATED',"Generira jučerašnja filtrirana izviješća elektroničke pošte");
DEFINE('_JW_EMAIL_REPORTS_VALUE_FILTERS',"Vrijednosti filtera e-pošte");
DEFINE('_JW_EMAIL_REPORTS_VALUE',"vrijednost");
DEFINE('_JW_EMAIL_REPORTS_PERCENT',"postotak");
DEFINE('_JW_EMAIL_REPORTS_1DAY_CHANGE',"dnevna promjena");
DEFINE('_JW_EMAIL_REPORTS_7DAY_CHANGE',"sedmodnevna promjena");
DEFINE('_JW_EMAIL_REPORTS_28DAY_CHANGE',"28-dnevna promjena ");
DEFINE('_JW_ANTISPAM_BLOCKED',"JoomlaWatch je blokirao %d spam pregleda danas, ukupno: %d");
DEFINE('_JW_ANTISPAM_ADDRESSES',"Blokirane IP adrese");
DEFINE('_JW_ANTISPAM_SETTINGS',"Anti-Spam postavke");
DEFINE('_JW_TRAFFIC_AJAX',"AJAX ažurira promet (osim mapa)");


DEFINE('_JW_HISTORY_PREVIOUS',"prethodno");
DEFINE('_JW_HISTORY_NEXT',"iduće");

/** additional translation for 1.2.11 for countries in more rows */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_COLUMNS',"Broj stupaca država");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_ROWS',"Broj redaka država");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NAMES',"Prikaži ime države ili ne");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FLAGS_FIRST',"Prikaži prvo zastave pa postotke");

/* JoomlaWatch 1.2.14 translations */

DEFINE('_JW_GOALS_GET_INVERSED', "GET suprotni uvjet");
DEFINE('_JW_GOALS_POST_INVERSED', "POST suprotni uvjet");
DEFINE('_JW_GOALS_TITLE_INVERSED', "Naziv suprotni uvjet");
DEFINE('_JW_GOALS_USERNAME_INVERSED', "Korisničko ime suprotni uvjet");
DEFINE('_JW_GOALS_CAME_FROM_INVERSED', "Dolazi iz suprotni uvjet");

DEFINE('_JW_STATS_MAP', "Mapa posljednje posjete");
DEFINE('_JW_STATS_MAP_ENTER_KEY',"Molimo unesite &lt;a href='http://www.ipinfodb.com/register.php' target='_blank'&gt;ipinfodb.com&lt;/a&gt; ključ za prikaz mape posljednje posjete:");
DEFINE('_JW_STATS_MAP_STORE_KEY',"spremi ključ");
DEFINE('_JW_STATS_MAP_INVALID_KEY',"Molimo unesite pravovaljani ipinfodb ključ koji ste dobili od: &lt;a href='http://www.ipinfodb.com/register.php' target='_blank'&gt;ipinfodb.com&lt;/a&gt;");

DEFINE('_JW_SIZEQUERY_BAD_REQUEST',"POGREŠAN ZAHTJEV: ");

DEFINE('_JW_VISIT_SUBMITED_FIELDS',"Poslana polja obrazaca:");
DEFINE('_JW_VISIT_URL_PARAMETERS',"URL parametri:");
DEFINE('_JW_VISIT_ADD_PAGE'," Dodaj stranicu kao cilj");
DEFINE('_JW_VISIT_BLOCK_IP'," Blokiraj ovu IP adresu");
DEFINE('_JW_VISIT_SUBMITED_FROM_VARIABLE'," Dodaj varijablu poslanu obrascem kao cilj");
DEFINE('_JW_VISIT_URL_PARAMETER_GOAL'," Dodaj ovaj URL parametar kao cilj");

DEFINE('_JW_TREND_EMPTY',"Prazno");

DEFINE('_JW_NOT_NUMBER'," POZOR: Vrijednost koju ste unijeli nije broj. JoomlaWatch neće raditi kako treba!");
DEFINE('_JW_EVALUATION_LEFT',"&amp;nbsp; Ovo je 15-dnevna probna verzija. Ostalo dana: &lt;b&gt;%d&lt;/b&gt;. Molimo kupite doživotnu &lt;a href='http://www.codegravity.com/donate/joomlawatch/' target='_blank'&gt;JoomlaWatch licencu za svoju domenu za ovu i nadolazeće verzije.");
DEFINE('_JW_TRIAL_VERSION_EXPIRED'," Vaša probna verzija je istekla. Molimo kupite JoomlaWatch");

DEFINE('_JW_CONFIG_LICENSE_ACTIVATED',"Licenca uspješno aktivirana. Hvala");
DEFINE('_JW_CONFIG_LICENCE_DONT_MATCH',"&lt;b&gt;Greška: ključ licence i Vaša domena ne odgovaraju.&lt;/b&gt;&lt;br/&gt;Jeste li unijeli isto ime domene u obrazac kao što se vidi ispod? &lt;br/&gt;Click '&lt;b&gt;zatražite točan aktivacijski ključ&lt;/b&gt;' ispod, ili kontaktirajte: info@codegravity.com&lt;br/&gt;");

DEFINE('_JW_VIEW_ADMINBODY_LONG_MESSAGE',"Ako predugo vidite poruku iznad, možda je vasa aktivna stranica kriva.
                    Otvorite components/com_joomlawatch/config.php
                    maknite komentare i postavite svoju pravu aktivnu stranicu. Npr.:
                    define('JOOMLAWATCH_LIVE_SITE', 'http://www.codegravity.com');");

DEFINE('_JW_ADMINBODY_LIVE_SITE',"Pozor: stranica u Vašem pregledniku i aktivna stranica u konfiguraciji: %s i %s se ne podudaraju.");
DEFINE('_JW_ADMINBODY_SET_LIVE_SITE',"Podesite aktivnu stranicu na: %s i nastavite...");

DEFINE('_JW_ADMINHEADER_JW',"JoomlaWatch ");
DEFINE('_JW_ADMINHEADER_REMOVE_BACKLINK',"Obriši povratnu poveznicu");
DEFINE('_JW_ADMINHEADER_KNOWLEDGE_BASE',"Baza znanja");
DEFINE('_JW_ADMINHEADER_FLOW',"Tijek");
DEFINE('_JW_ADMINHEADER_GRAPHS',"Grafovi");
DEFINE('_JW_ADMINHEADER_COMPONENTS',"Komponente");
DEFINE('_JW_ADMINHEADER_REVIEW',"Osvrt");
DEFINE('_JW_ADMINHEADER_WRITE',"Napiši ");

DEFINE('_JW_FLOW_TRAFFIC',"Tijek prometa");
DEFINE('_JW_FLOW_SELECT_PAGE',"Označi stranicu:");
DEFINE('_JW_FLOW_OUTG_LINKS',"Broj izvora odlazećih poveznica:");
DEFINE('_JW_FLOW_NESTING',"Nivo gniježđenja:");
DEFINE('_JW_FLOW_SCALE',"Razmjer:");

DEFINE('_JW_COMERCIAL_AD_FREE',"Verzija bez reklama");
DEFINE('_JW_COMERCIAL_THANK_DONATION',"Puno Vam hvala na Vašoj donaciji!");
DEFINE('_JW_COMERCIAL_REGISTRATION_KEY',"Registracijski ključ Vase domene %s je: ");
DEFINE('_JW_COMERCIAL_BACKLINKS_REMOVE',"Sad možete maknuti povratnu poveznicu ili sakriti JoomlaWatch logo u frontend-u u Postavkama ");


DEFINE('_JW_SIZES_LAST_CHECK',"Posljednja provjera bila je:");
DEFINE('_JW_SIZES_ADMINISTRATOR',"BLUE = Veličina component/module u /administrator direktoriju");

DEFINE('_JW_SIZECOMPONENTS_COMPONENT',"Komponenta");
DEFINE('_JW_SIZECOMPONENTS_TOTAL',"Ukupno:");
DEFINE('_JW_SIZECOMPONENTS_SIZE',"Veličina");
DEFINE('_JW_SIZECOMPONENTS_REFRESH_ALL',"Osvježi sve");

DEFINE('_JW_SIZEDATABASE_TABLE',"Tablica");
DEFINE('_JW_SIZEDATABASE_SIZE',"Veličina");
DEFINE('_JW_SIZEDATABASE_1DAY',"Dnevna promjena");
DEFINE('_JW_SIZEDATABASE_7DAY',"Sedmodnevna promjena");
DEFINE('_JW_SIZEDATABASE_28DAY',"28-dnevna promjena");
DEFINE('_JW_SIZEDATABASE_NO_DATA',"nema podataka");
DEFINE('_JW_SIZEDATABASE_TOTAL',"Ukupno:");

DEFINE('_JW_SIZEMODULES_REFRESH_ALL',"Osvježi sve");
DEFINE('_JW_SIZEMODULES_TOTAL',"Ukupno:");
DEFINE('_JW_SIZEMODULES_MODULE',"Modul");
DEFINE('_JW_SIZEMODULES_SIZE',"Veličina");

DEFINE('_JW_SIZES_FILES',"Datoteke &amp;amp; Direktoriji");
DEFINE('_JW_SIZES_BYTES',"bajtovi");
DEFINE('_JW_SIZES_KB',"KB");
DEFINE('_JW_SIZES_MB',"MB");
DEFINE('_JW_SIZES_GB',"GB");
DEFINE('_JW_SIZES_REFRESH',"Osvježi");

DEFINE('_JW_STATS_FOOTER',"JoomlaWatch &amp;copy;2006-@YEAR@ by Matej Koval");

DEFINE('_JW_STATUS_MB',"MB");
DEFINE('_JW_STATUS_DATABASE',"Veličina tablica baze podataka");


DEFINE('_JW_DESC_IPINFODB_KEY',"Mapa posljednje posjete ipinfodb.com ključ: &lt;a href='http://www.ipinfodb.com/register.php' target='_blank'&gt;ipinfodb.com&lt;/a&gt;");
DEFINE('_JW_SETTINGS_FORCE_TIMEZONE_OFFSET',"Prisili pomak vremenske zone");


/* JoomlaWatch 1.2.17 translations */
DEFINE('_JW_MENU_UPDATE', "Ažuriraj");
DEFINE('_JW_MENU_UPDATE_TITLE', "Sigurnosna kopija &amp; Nadogradnja");
DEFINE('_JW_ADMINHEADER_NA_IN_THIS_VERSION',"Nije omogućeno u besplatnim verzijama, molimo pogledajte karticu Licenca");
DEFINE('_JW_SPAMWORD_BANS_ENABLED', "Omogući blokiranja sa spam riječima");
DEFINE('_JW_SPAMWORD_LIST', "Lista spam riječi");
DEFINE('_JW_HIDE_REPETITIVE_TITLE', "Sakrij repetitivni naslov");
DEFINE('_JW_TRUNCATE_VISITS', "Odsijeci posjete");
DEFINE('_JW_TRUNCATE_STATS', "Odsijeci statistike");
DEFINE('_JW_TRUNCATE_GOALS', "Odsijeci ciljeve");
DEFINE('_JW_LIMIT_BOTS', "Ograniči botove");
DEFINE('_JW_LIMIT_VISITORS', "Ograniči posjete");
DEFINE('_JW_TOOLTIP_WIDTH', "Širina opisa alata");
DEFINE('_JW_TOOLTIP_HEIGHT', "Visina opisa alata");
DEFINE('_JW_TOOLTIP_URL', "URL opisa alata");
DEFINE('_JW_TOOLTIP_ONCLICK', "Opis alata OnClick");
DEFINE('_JW_IP_STATS', "IP statistike");
DEFINE('_JW_IPINFODB_KEY', "IP Informacijski ključ baze podataka ");
DEFINE('_JW_ONLY_LAST_URI', "Samo posljednji URI ");

DEFINE('_JW_FRONTEND_HIDE_LOGO', "Frontend sakrij logo ");
DEFINE('_JW_FRONTEND_NOFOLLOW', "Frontend ne prati");
DEFINE('_JW_FRONTEND_NO_BACKLINK', "Frontend bez povratne poveznice");
DEFINE('_JW_FRONTEND_USER_LINK', "Korisnikove poveznice");
DEFINE('_JW_FRONTEND_COUNTRIES_FIRST', "Frontend države prve");
DEFINE('_JW_FRONTEND_COUNTRIES_NAMES', "Frontend imena država");
DEFINE('_JW_FRONTEND_COUNTRIES_UPPERCASE', "Frontend države velikim slovima");
DEFINE('_JW_FRONTEND_COUNTRIES_FLAGS_FIRST', "Frontend zastave država prve");
DEFINE('_JW_FRONTEND_COUNTRIES_NUM', "Frontend brojevi država");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_COLUMNS', "Frontend najveći mogući broj stupaca država");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_ROWS', "Frontend najveći mogući broj redaka država");
DEFINE('_JW_FRONTEND_VISITORS_TODAY', "Frontend podjetitelji danas ");
DEFINE('_JW_FRONTEND_VISITORS_YESTERDAY', "Frontend posjetitelji jučer ");
DEFINE('_JW_FRONTEND_VISITORS_THIS_WEEK', "Frontend posjetitelji ovaj tjedan ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_WEEK', "Frontend posjetitelji prošli tjedan ");

DEFINE('_JW_FRONTEND_VISITORS_THIS_MONTH', "Frontend posjetitelji ovaj mjesec ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_MONTH', "Frontend posjetitelji prošli mjesec ");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL', "Frontend sakrij ukupan broj posjetitelja");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL	', "Frontend početni broj ukupnog");
DEFINE('_JW_HISTORY_MAX_VALUES', "Najveće vrijednosti povijesti");
DEFINE('_JW_HISTORY_MAX_DB_RECORDS', "Najviše zapisa povijesti");
DEFINE('_JW_UPDATE_TIME_VISITS', "Ažuriraj vrijeme posjete");
DEFINE('_JW_UPDATE_TIME_STATS', "Ažuriraj vrijeme statistike");
DEFINE('_JW_STATS_MAX_ROWS', "Statistike najviše redaka");
DEFINE('_JW_STATS_IP_HITS', "Statistike IP pregledi");
DEFINE('_JW_MAXID_BOTS', "Najviše ID botova");
DEFINE('_JW_MAXID_VISITORS', "Najviše ID posjeta");
DEFINE('_JW_STATS_KEEP_DAYS', "Koliko se dana čuvaju statistike ");
DEFINE('_JW_CACHE_FRONTEND_COUNTRIES', "Spremi frontend države u predmemoriju ");
DEFINE('_JW_CACHE_FRONTEND_VISITORS', "Spremi frontend posjete u predmemoriju ");

DEFINE('_JW_UNINSTALL_KEEP_DATA	', "Sačuvaj podatke pri deinstalaciji ");
DEFINE('_JW_IGNORE_IP', "Ignoriraj IP");
DEFINE('_JW_IGNORE_URI', "Ignoriraj URI");
DEFINE('_JW_IGNORE_USER', "Ignoriraj korisnika");
DEFINE('_JW_BLOCKING_MESSAGE', "Poruka za blokirane");
DEFINE('_JW_SERVER_URI_KEY', "Serverski URI ključ");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL', "Frontend početni broj ukupnih posjeta");
DEFINE('_JW_SIZEDATABASE_RECORDS', "Zapisi");
/***********EDITs******************/
DEFINE('_JW_ANTISPAM_BLOCKING_TEXT'," Kako bi blokiranje bilo omogućeno morate objaviti JoomlaWatch agenta PRIJE sadržaja ili obrazaca. Pr. na lijevoj strani predloška.
                    &lt;br/&gt;
                    Otiđite na Module Manager -&gt; JoomlaWatch agent -&gt; označite lijevi položaj");

DEFINE('_JW_EMAIL_SEO_REPORTS', "SEO izviješća");
DEFINE('_JW_DESC_EMAIL_SEO_REPORTS_ENABLED',"SEO noćna izviješća elektroničkom poštom omogućena");
DEFINE('_JW_WATCH_INSTALLATION_DEMO',"Pogledajte demo instalacije");

?>