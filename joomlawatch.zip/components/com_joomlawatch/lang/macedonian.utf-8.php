<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version @VERSION@
 * @revision @REVISION@
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) @YEAR@ by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/
defined( '_JEXEC' ) or die( 'Restricted access' );

#JoomlaWatch language file - to create a new language file, just copy the english.php to eg. german.php and place into /components/com_joomlawatch/lang/

# Main Menu
DEFINE('_JW_MENU_STATS', "Статистика во живо");
DEFINE('_JW_MENU_GOALS', "Цели");
DEFINE('_JW_MENU_SETTINGS', "Подесувања");
DEFINE('_JW_MENU_CREDITS', "Заслуги");
DEFINE('_JW_MENU_FAQ', "ЧПП");
DEFINE('_JW_MENU_DOCUMENTATION', "Документација");
DEFINE('_JW_MENU_LICENSE', "Лиценца");
DEFINE('_JW_MENU_DONATORS', "Подржувачи");
DEFINE('_JW_MENU_SUPPORT', "Подржи ја JoomlaWatch и отрстрани ги рекламите од позадината.");


# Left visitors real-time window
DEFINE('_JW_VISITS_VISITORS', "Последни посетители");
DEFINE('_JW_VISITS_BOTS', "Ботови");
DEFINE('_JW_VISITS_CAME_FROM', "Дојде од");
DEFINE('_JW_VISITS_MODULE_NOT_PUBLISHED', "Вашиот JoomlaWatch модул не е објавен! Не зачувува нови статистики. За да ја објавите, одете во секцијата за модули и објавете ја на сите страни.");
DEFINE('_JW_VISITS_PANE_LOADING', "Вчитува посети...");

# Right stats window
DEFINE('_JW_STATS_TITLE', "Неделна статистика за посетеност");
DEFINE('_JW_STATS_WEEK', "Недела");
DEFINE('_JW_STATS_THIS_WEEK', "оваа недела");
DEFINE('_JW_STATS_UNIQUE', "уникатни");
DEFINE('_JW_STATS_LOADS', "вчитувања");
DEFINE('_JW_STATS_HITS', "посети");
DEFINE('_JW_STATS_TODAY', "денес");
DEFINE('_JW_STATS_FOR', "за");
DEFINE('_JW_STATS_ALL_TIME', "Сите времиња");
DEFINE('_JW_STATS_EXPAND', "прошири");
DEFINE('_JW_STATS_COLLAPSE', "собери");
DEFINE('_JW_STATS_URI', "Страни");
DEFINE('_JW_STATS_COUNTRY', "Земји");
DEFINE('_JW_STATS_USERS', "Корисници");
DEFINE('_JW_STATS_REFERERS', "Препраќачи");
DEFINE('_JW_STATS_IP', "IP-а");
DEFINE('_JW_STATS_BROWSER', "Прелистувачи");
DEFINE('_JW_STATS_OS', "OS");
DEFINE('_JW_STATS_KEYWORDS', "Клучни зборови");
DEFINE('_JW_STATS_GOALS', "Цели");
DEFINE('_JW_STATS_TOTAL', "Вкупно");
DEFINE('_JW_STATS_DAILY', "Дневно");
DEFINE('_JW_STATS_DAILY_TITLE', "Дневна статистика");
DEFINE('_JW_STATS_ALL_TIME_TITLE', "Статистика на сите времиња");
DEFINE('_JW_STATS_LOADING', "се вчитува...");
DEFINE('_JW_STATS_LOADING_WAIT', "се вчитува... ве молиме почекајте");
DEFINE('_JW_STATS_IP_BLOCKING_TITLE', "IP Блокирање");
DEFINE('_JW_STATS_IP_BLOCKING_ENTER', "Внеси рачно IP");
DEFINE('_JW_STATS_IP_BLOCKING_MANUALLY', "Внеси ја IP адресата која сакаш да ја блокираш. (на пр. 217.242.11.54 или 217.* или 217.242.* за да ги блокираш сите IP адреси кој соодвествуваат со * карактерот.)");
DEFINE('_JW_STATS_IP_BLOCKING_TOGGLE', "Вклучи блокирање на ");
DEFINE('_JW_STATS_PANE_LOADING', "Вчитува статистика...");

# Settings
DEFINE('_JW_SETTINGS_TITLE', "Подесувања");
DEFINE('_JW_SETTINGS_DEFAULT', "Стандардно");
DEFINE('_JW_SETTINGS_SAVE', "Зачувај");
DEFINE('_JW_SETTINGS_APPEARANCE', "Изглед");
DEFINE('_JW_SETTINGS_FRONTEND', "Предна страна");
DEFINE('_JW_SETTINGS_HISTORY_PERFORMANCE', "Историја и Перформанси");
DEFINE('_JW_SETTINGS_ADVANCED', "Напредно");
DEFINE('_JW_SETTINGS_IGNORE', "Игнорирај");
DEFINE('_JW_SETTINGS_BLOCKING', "Блокирање");
DEFINE('_JW_SETTINGS_EXPERT', "Експерт");
DEFINE('_JW_SETTINGS_RESET_CONFIRM', "Дали навистина сакате да ги ресетирате сите статистики и посети?");
DEFINE('_JW_SETTINGS_RESET_ALL', "Ресетирај ги сите");
DEFINE('_JW_SETTINGS_RESET_ALL_LINK', "Ресетирај ги сите статистики и дата на посетители");
DEFINE('_JW_SETTINGS_LANGUAGE', "Јазик");
DEFINE('_JW_SETTINGS_SAVED', "Подесувањата се зачувани");
DEFINE('_JW_SETTINGS_ADD_YOUR_IP', "Додади ја твојата IP");
DEFINE('_JW_SETTINGS_TO_THE_LIST', "во листата.");

# Other / mostly general
DEFINE('_JW_TITLE', "Вистински AJAX џумла монитор");
DEFINE('_JW_BACK', "Назад");
DEFINE('_JW_ACCESS_DENIED', "Немате дозвола за да го погледнете ова !");
DEFINE('_JW_LICENSE_AGREE', "Се согласувам со горенаведените начини и услови");
DEFINE('_JW_LICENSE_CONTINUE', "Продолжи");
DEFINE('_JW_SUCCESS', "Процесот е успешен");
DEFINE('_JW_RESET_SUCCESS', "Сите статистики и дата од посетителу е успешно избришана");
DEFINE('_JW_RESET_ERROR', "Датата НЕ Е успешно избришана, нешто е погрешно");
DEFINE('_JW_CREDITS_TITLE', "Заслуги");
DEFINE('_JW_TRENDS_DAILY_WEEKLY', "Дневни и неделни статистики за");
DEFINE('_JW_AJAX_PERMISSION_DENIED_1', "Дозвола за AJAX забранета: Ве молиме видете ги статистиките од вашиот поддомен на вашата џумла кој што сте го навеле во configuration.php - ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_2', "Можеби сте заборавиле да додадете www. пред вашиот поддомен. Вашиот javascript се обидува да пристапи ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_3', "од");
DEFINE('_JW_AJAX_PERMISSION_DENIED_4', "тоа што го мисли дека е друг различен поддомен.");

# Header
DEFINE('_JW_HEADER_DOWNLOAD', "Земете го последниот код на екстензијата од");
DEFINE('_JW_HEADER_CAST_YOUR', "Ве молиме дајте го својот");
DEFINE('_JW_HEADER_VOTE', "глас");

# Tooltips
DEFINE('_JW_TOOLTIP_CLICK', "Кликни за да се покаже совет");
DEFINE('_JW_TOOLTIP_MOUSE_OVER', "Поминете со глувчето за да се покаже совет");
DEFINE('_JW_TOOLTIP_YESTERDAY_INCREASE', "вчерашно зголемување");
DEFINE('_JW_TOOLTIP_HELP', "Отвара надворешна помош за");
DEFINE('_JW_TOOLTIP_WINDOW_CLOSE', "Затворете го прозорецов");
DEFINE('_JW_TOOLTIP_PRINT', "Принтај");

# Goals
DEFINE('_JW_GOALS_INSERT', "Внеси нова цел");
DEFINE('_JW_GOALS_UPDATE', "Ажурирај ја целта бр.");
DEFINE('_JW_GOALS_ACTION', "Акција");
DEFINE('_JW_GOALS_TITLE', "Нова цел");
DEFINE('_JW_GOALS_NEW', "Нова цел");
DEFINE('_JW_GOALS_RELOAD', "Превчитај");
DEFINE('_JW_GOALS_ADVANCED', "Напредно");
DEFINE('_JW_GOALS_NAME', "Име");
DEFINE('_JW_GOALS_ID', "id");
DEFINE('_JW_GOALS_URI_CONDITION', "Услов за URI");
DEFINE('_JW_GOALS_URI_INVERSED', "Спротивен услов за URI");
DEFINE('_JW_GOALS_GET_VAR', "GET var");
DEFINE('_JW_GOALS_GET_CONDITION', "GET услов");
DEFINE('_JW_GOALS_POST_VAR', "POST Var");
DEFINE('_JW_GOALS_POST_CONDITION', "POST услов");
DEFINE('_JW_GOALS_TITLE_CONDITION', "Наслов");
DEFINE('_JW_GOALS_USERNAME_CONDITION', "Корисничко име");
DEFINE('_JW_GOALS_IP_CONDITION', "IP услов");
DEFINE('_JW_GOALS_IP_INVERSED', "IP спротивен услов");
DEFINE('_JW_GOALS_CAME_FROM_CONDITION', "Дојден од");
DEFINE('_JW_GOALS_BLOCK', "Блокирај");
DEFINE('_JW_GOALS_REDIRECT', "Пренасочи URL");
DEFINE('_JW_GOALS_HITS', "Посети");
DEFINE('_JW_GOALS_ENABLED', "Овозможено");
DEFINE('_JW_GOALS_EDIT', "Измени");
DEFINE('_JW_GOALS_DELETE', "Избриши");
DEFINE('_JW_GOALS_DELETE_CONFIRM', "Ќе ги изгубите сите скорешни статистики од оваа цел. Дали навистина сакате да ја избришете целта со бр.");

# Frontend
DEFINE('_JW_FRONTEND_COUNTRIES', "Држави");
DEFINE('_JW_FRONTEND_VISITORS', "Посетители");
DEFINE('_JW_FRONTEND_TODAY', "Денес");
DEFINE('_JW_FRONTEND_YESTERDAY', "Вчера");
DEFINE('_JW_FRONTEND_THIS_WEEK', "Оваа Недела");
DEFINE('_JW_FRONTEND_LAST_WEEK', "Минатата Недела");
DEFINE('_JW_FRONTEND_THIS_MONTH', "Овој Месец");
DEFINE('_JW_FRONTEND_LAST_MONTH', "Минатиот Месец");
DEFINE('_JW_FRONTEND_TOTAL', "Вкупно");

# Settings description - quite long
DEFINE('_JW_DESC_DEBUG', "JoomlaWatch е во режим на поправка. На овој начин можете да откриете што ги предизвикува грешките. За да го исклучите, ве молиме сменете ја вредноста JOOMLAWATCH_DEBUG во /components/com_joomlawatch/config.php од 1 во 0");
DEFINE('_JW_DESC_STATS_MAX_ROWS', "Да се покажуваат максимум редови кога статистиките се во издолжен режим.");
DEFINE('_JW_DESC_STATS_IP_HITS', "Сите IP адреси кој што имале помалку посети во изминатите денови од оваа вредност ќе бидат избришани од IP историјата.");
DEFINE('_JW_DESC_STATS_URL_HITS', "Сите URL-а кој што имале помалку посети во изминатите денови од оваа вредност ќе бидат избришани од IP историјата.");
DEFINE('_JW_DESC_IGNORE_IP', "Отфрли извесни IP-а од статистиката. Одвои ги со нова линија. Тука може да користите помошен карактер. <br/>На пр. 192.* ќе игнорира 192.168.51.31, 192.168.16.2, итн..");
DEFINE('_JW_DESC_UPDATE_TIME_VISITS', "Времето на посетители во милисекунди, стандардно е 2000, бидете внимателни. Потоа освежете ја JoomlaWatch во администрација.");
DEFINE('_JW_DESC_UPDATE_TIME_STATS', "Времето на статистики во милисекунди, стандардно е 4000, бидете внимателни. Потоа освежете ја JoomlaWatch во администрација.");
DEFINE('_JW_DESC_MAXID_BOTS', "Колку посети од ботови да чува во датабаза.");
DEFINE('_JW_DESC_MAXID_VISITORS', "Колку вистински посетители да чува во датабаза.");
DEFINE('_JW_DESC_LIMIT_BOTS', "Колку бота да гледате во администрација.");
DEFINE('_JW_DESC_LIMIT_VISITORS', "Колку вистински посетители да гледате во администрација.");
DEFINE('_JW_DESC_TRUNCATE_VISITS', "Максимум карактери да се покажуваат во долгите наслови и во урито.");
DEFINE('_JW_DESC_TRUNCATE_STATS', "Максимум карактери да се покажуваат во десниот панел за статистика.");
DEFINE('_JW_DESC_STATS_KEEP_DAYS', "Денови да чува статистиката во датабаза, 0 = бесконечно.");
DEFINE('_JW_DESC_TIMEZONE_OFFSET', "Кога сте во различна временска зона од вашиот хостинг сервер. (позитивна или негативна вредност во часови)");
DEFINE('_JW_DESC_WEEK_OFFSET', "Неделен офсет, точното време/(3600*24*7) го дава бројот на неделата од 1.1.1970, овој офсет е исправка за да почне со понеделник ");
DEFINE('_JW_DESC_DAY_OFFSET', "Дневен офсет, точното време/(3600*24) го дава бројот на денот од 1.1.1970, овој офсет е исправка за да почне со 00:00 ");
DEFINE('_JW_DESC_FRONTEND_HIDE_LOGO', "<b>(функционално во PRO верзијата)</b> За да користите празна 1x1px иконка на предната страна");
DEFINE('_JW_DESC_IP_STATS', "За да овозможите статистики за IP адреси. Во некој држави чувањето на IP адреса во датабаза на подолг период е забрането со закон. Користете на свој ризик.");
DEFINE('_JW_DESC_HIDE_ADS', "Ако ви сметаат рекламите, тогаш ова подесување ги крие рекламите во администрација. Ако ги чувате, со тоа и го подржувате развојот на оваа алатка. Ви Благодариме");
DEFINE('_JW_DESC_TOOLTIP_ONCLICK', "Одштиклирај, ако сакаш советот да се прикаже со надминување на поинтерот, наспроти клик.");
DEFINE('_JW_DESC_SERVER_URI_KEY', "Стандардно е 'REDIRECT_URL', кое користи url препишување, може да биде подесено на 'SCRIPT_URL' ако го логира само index.php");
DEFINE('_JW_DESC_BLOCKING_MESSAGE', "Порака која се прикажува на блокиран корисник или информација со образложение зашто се блокирани банираните корисници.");
DEFINE('_JW_DESC_TOOLTIP_WIDTH', "Должина на советот(балончето)");
DEFINE('_JW_DESC_TOOLTIP_HEIGHT', "Висина на советот(балончето)");
DEFINE('_JW_DESC_TOOLTIP_URL', "Тука можете да ставите било кое URL, за да го визуализирате ip-то на посетителот. Овој {ip} ќе биде сменет од ip-то на посетителот. На пр. http://somewebsite.com/query?iplookup={ip}");
DEFINE('_JW_DESC_IGNORE_URI', "Тука може да пишете било кое URI кое сакате да биде игнорирано од статистиките. Тука може да користите помошни карактери (* и ?). На пр.: /freel?n* ");
DEFINE('_JW_DESC_GOALS_NAME', "Тука наведи име за целта. Ова име ќе го гледате во статистиката.");
DEFINE('_JW_DESC_GOALS_URI_CONDITION', "Се што е после вашиот поддомен. За http://www.codegravity.com/projects/ URI-то е: /projects/ (Пример: <b>/projects*</b>)");
DEFINE('_JW_DESC_GOALS_GET_VAR', "GET променлива е променлива која може да ја видите во URL-то после карактерот ? или &amp; знакот. На пр. http://www.codegravity.com/index.php?<u>name</u>=peter&amp;<u>surname</u>=smith. Исто така може да користите <u>*</u> во ова поле за да ги скенира сите get вредности. (Пример: <b>n*me</b>)");
DEFINE('_JW_DESC_GOALS_GET_CONDITION', "Тука мора да наведете соодветност за вредност од претходното поле. (Пример: <b>p?t*r</b>) ");
DEFINE('_JW_DESC_GOALS_POST_VAR', "Прилично слично, но ние ги проверуваме вредностите внесени во формите. Така да, кога имате форма на вашата веб-страна, и има поле &lt;input type='text' name='<u>experiences</u>' /&gt;. (Пример: <b>exper*ces</b>)");
DEFINE('_JW_DESC_GOALS_POST_CONDITION', "Совпаѓање на вредност од POST полето. Пр. сакаме да провериме, дали корисникот има искуство во java. (Пример: <b>*java*</b>)");
DEFINE('_JW_DESC_GOALS_TITLE_CONDITION', "Наслов на страна кој нема совпаѓање. (Пример: <b>*freelance programmers*</b>)");
DEFINE('_JW_DESC_GOALS_USERNAME_CONDITION', "Име на логиран корисник. (Пример: <b>psmith*</b>)");
DEFINE('_JW_DESC_GOALS_IP_CONDITION', "IP од која корисникот доаѓа: (Пример: <b>201.9?.*.*</b>)");
DEFINE('_JW_DESC_GOALS_CAME_FROM_CONDITION', "URL од која корисникот доаѓа. (Пример: <b>*www.google.*</b>)");
DEFINE('_JW_DESC_GOALS_REDIRECT', "Корисникот е пренасочен до URL специфициран од тебе. Има поголем приоритет отколу 'блокирање': Пример: <b>http://www.codegravity.com/goaway.html</b>)");
DEFINE('_JW_DESC_TRUNCATE_GOALS', "Колку карактери да скрати во табелата за цели");
DEFINE('_JW_DESC_FRONTEND_NO_BACKLINK', "<b>(функционално во PRO верзија)</b> Позадински линк до codegravity.com, можете да го оневозможите, но би го ценеле тоа ако стои непроменет. Ви Благодариме");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES', "Прикажи ги вкупните статистики за држави на модулот од предната страна. Ако е променет, ова подесување ќе биде ефективно на предната страна откога времето ќе биде сетирано во CACHE_FRONTEND_ ");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FIRST', "Ако сакте да го смените редот на Посетители/Држави на предна страна. Одштиклирајте го, и посетителите први ќе се појават.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NUM', "Да прикаже број на држави на предна страна");
DEFINE('_JW_DESC_FRONTEND_VISITORS', "Прикажи посетители од држави во модулот на предната страна.  Ако е променет, ова подесување ќе биде ефективно на предната страна откога времето ќе биде сетирано во CACHE_FRONTEND_ ");
DEFINE('_JW_DESC_CACHE_FRONTEND_COUNTRIES', "Број на секунди за да ги кешира вкупниот број на држави од предната страна");
DEFINE('_JW_DESC_CACHE_FRONTEND_VISITORS', "Број на секунди за да ги кешира посетителите од предната страна");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TODAY', "Да прикаже посетители на предна страна за: денес. Ако е променет, ова подесување ќе биде ефективно на предната страна откога времето ќе биде сетирано во CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_YESTERDAY', "Да прикаже посетители на предна страна за: вчера. Ако е променет, ова подесување ќе биде ефективно на предната страна откога времето ќе биде сетирано во CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_WEEK', "Да прикаже посетители на предна страна за: оваа недела. Ако е променет, ова подесување ќе биде ефективно на предната страна откога времето ќе биде сетирано во CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_WEEK', "Да прикаже посетители на предна страна за: минатата недела. Ако е променет, ова подесување ќе биде ефективно на предната страна откога времето ќе биде сетирано во CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_MONTH', "Да прикаже посетители на предна страна за: овој месец. Ако е променет, ова подесување ќе биде ефективно на предната страна откога времето ќе биде сетирано во CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_MONTH', "Да прикаже посетители на предна страна за: минатиот месец. Ако е променет, ова подесување ќе биде ефективно на предната страна откога времето ќе биде сетирано во CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL', "Да прикаже вкупен број на посетители од последната JoomlaWatch инсталација. Ако е променет, ова подесување ќе биде ефективно на предната страна откога времето ќе биде сетирано во CACHE_FRONTEND_...");
DEFINE('_JW_DESC_LANGUAGE', "Кој фајл за јазик. Тие се наоѓаат во /components/com_joomlawatch/lang/. Ако сакате да направите превод, прво проверете на домашната страна од овој проект, и ако тој превод не постои, само копирајте го english.php во на пр. german.php и внесете го во овој директориум. Потоа, само преведете ги сите клучни вредности од десно.");
DEFINE('_JW_DESC_GOALS', "Целите ви овозможуваат да специфицирате специјални периметри. Кога овие параметри ќе се совпаднат, бројачот се зголемува. На овој начин можете да следите дали корисникот посетил специфична URL, постирал специфична вредност, има специфицно корисничко име или дошол од специфична адреса. Исто така таквите корисници можете да блокирате или да пренасочите кон некое друго URL.");
DEFINE('_JW_DESC_GOALS_INSERT', "Во сите полиња, освен тоа за име, можете да користите * и ? како помошни карактери. На пример: ?ear (will match: near, tear, ..),  p*r (ќе се совпадне со: pr, peer, pear ..) ");
DEFINE('_JW_DESC_GOALS_BLOCK', "Намести на 1, ако сакаш корисникот да биде блокиран. Тој нема да го гледа остатокот од содржината, туку само пораката дека е блокиран - без никакво пренасочување и неговата IP ќе биде додадена во 'блокирани' статистики (Пример: <b>1</b>)");

/* new translations */
DEFINE('_JW_GOALS_COUNTRY_CONDITION', "Услов за Држава");
DEFINE('_JW_GOALS_CONTRY_INVERSED', "Спротивен услов за Држава");
DEFINE('_JW_DESC_GOALS_COUNTRY_CONDITION', "Код на држава со 2 две големи букви (На пр: <b>TH</b>)");
DEFINE('_JW_STATS_INTERNAL',"Внатрешен");
DEFINE('_JW_STATS_FROM',"Од");
DEFINE('_JW_STATS_TO',"До");
DEFINE('_JW_STATS_ADD_TO_GOALS',"Додади во целите");
DEFINE('_JW_VISITS_ADD_GOAL_COUNTRY',"Додади цел за оваа држава");
DEFINE('_JW_MENU_REPORT_BUG',"Пријави грешка или можност");
DEFINE('_JW_GOALS_COUNTRY',"Држава");


/* translations 1.2.8b_12 */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_UPPERCASE',"Ако сакате имињата на државите да се прикажуваат со големи букви на предната страна (Пр: GERMANY, UNITED KINGDOM наспроти Germany, United Kingdom)");
DEFINE('_JW_DESC_CACHE_FRONTEND_USERS',"Време во секунди за да ги искешира корисниците на предната страна.");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL_INITIAL', "Почетна вредност која се покажува: на предна страна. Корисно кога мигрира од друга алатка за статистика. (Пр.: 20000). Намести назад на 0 ако не сакате да ја користите оваа можност.");
DEFINE('_JW_DESC_IGNORE_USER', "Игнорирај ги корисниците напишани во формава за текст. По еден на линија. (Пример.: myself {line break} mark_*) ");
DEFINE('_JW_FRONTEND_USERS_MOST', "Најактивни корисници денес од вкупно");
DEFINE('_JW_DESC_SPAMWORD_BANS_ENABLED',"Овозможи ги бановите базирани на зборовите од листата на спам зборови подоле ?");
DEFINE('_JW_DESC_SPAMWORD_LIST',"Најчесто користени спам зборови од спам ботови. Тука можете да користите помошен карактер, (Пр.: ph?rmac*). Ако подесувањето од погоре е овозможено, JoomlaWatch ќе провери дали напаѓачот ја поднел формата (HTTP POST побарување) на вашата веб-страна со некој од спам зборовите. (Се однесува само ако формата вчитува Џумла базирана веб-страна - форум, коментари, но е прилично ефикасна за да ги блокира спам ботовите кој пробуваат да се вметнат и поднесат содржина во секоја достапна форма)");
DEFINE('_JW_SETTINGS_ANTI_SPAM',"Анти-спам");
DEFINE('_JW_DESC_FRONTEND_USER_LINK',"Линк на предната страна на модулот за корисници - дозволува да наведете URL, кој се отвара кога корисникот ќе кликне на корисничкото име. Мора да има низа {user}, која ќе биде заменета со актуелното корисничко име. (Пр. index.php?option=com_comprofiler&task=userProfile&user={user}) ");

/* translations 1.2.11b */
DEFINE('_JW_STATS_KEYPHRASE', "Клучни фрази");
DEFINE('_JW_DESC_HISTORY_MAX_VALUES', "Максимум вредности во табот кај историја (Пример: <i>100</i>)");

DEFINE('_JW_DESC_ONLY_LAST_URI', "Во посети покажи ги само последните посетени страни, а не сите");
DEFINE('_JW_DESC_HIDE_REPETITIVE_TITLE', "Во посети скриј ги повторувачките имиња на страни");
DEFINE('_JW_DESC_HISTORY_MAX_DB_RECORDS', "Максимум број на посетители да се чуваат во датабаза за историја на посети. Бидете внимателни со ова подесување, ако имате голем сообраќај, може да расте премногу брзо. Секогаш проверувај во статус колку дата се содржи во табелата за историја");
DEFINE('_JW_DESC_UNINSTALL_KEEP_DATA', "Држи ги табелите од датабазата на деинсталација. Штиклирај ја оваа опција пред деинсталација ако правиш ажурирање и сакаш да си ја зачуваш датата.");

/* email reports */
DEFINE('_JW_DESC_EMAIL_REPORTS_ENABLED', "Ќе добиете ноќни извештаи на е-пошта за претходниот ден, кој што ќе можете да ги прочитате изутрината");
DEFINE('_JW_DESC_EMAIL_REPORTS_ADDRESS', "Адреса за е-пошта на која ќе добивате извештаи");
DEFINE('_JW_DESC_EMAIL_PERCENT_HIGHER_THAN', "Вклучи само редови во извештаите од е-пошта кога процентот е поголем од {value}. Намести назад на 0 ако не сакате да ја користите оваа можност. <i>(пример: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_POSITIVE', "Вклучи само <b>позитивен еден ден</b> во извештаите од е-пошта кога процентот е поголем од {value} процент. Намести назад на 0 ако не сакате да ја користите оваа можност. <i>(пример: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_NEGATIVE', "Вклучи само <b>негативен еден ден</b> во извештаите од е-пошта кога процентот е помал од {value} процент. Намести назад на 0 ако не сакате да ја користите оваа можност. <i>(пример: -10)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_POSITIVE', "Вклучи само <b>позитивен седми ден</b> во извештаите од е-пошта кога процентот е поголем од {value} процент. Намести назад на 0 ако не сакате да ја користите оваа можност. <i>(пример: 2)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_NEGATIVE', "Вклучи само <b>негативен седми ден</b> во извештаите од е-пошта кога процентот е помал од {value} процент. Намести назад на 0 ако не сакате да ја користите оваа можност. <i>(пример: -13)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_POSITIVE', "Вклучи само <b>позитивен дваесет и осми ден</b> во извештаите од е-пошта кога процентот е поголем од {value} процент. Намести назад на 0 ако не сакате да ја користите оваа можност. <i>(пример: 2)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_NEGATIVE', "Вклучи само <b>негативен дваесет и осми ден</b> во извештаите од е-пошта кога процентот е помал од {value} процент. Намести назад на 0 ако не сакате да ја користите оваа можност. <i>(пример: -13)</i>");

DEFINE('_JW_DESC_FRONTEND_NOFOLLOW', "<b>(фунцкионално во PRO верзијата)</b> Овозможи го ова подесување ако сакаш да го направиш линкот на логото да биде рендериран со атрибутот rel='nofollow' ");
DEFINE('_JW_DESC_EMAIL_NAME_TRUNCATE', "Максимум карактери на е-пошта име. Смени го ова ако вашиот прозорец за е-пошта е премногу мал.");

DEFINE('_JW_MENU_HISTORY', "Историја");
DEFINE('_JW_MENU_EMAILS', "Е-пошти");
DEFINE('_JW_MENU_STATUS', "DB Статус");
DEFINE('_JW_DESC_BLOCKED',"Овие IP-а беа блокирани од анти-спам");


DEFINE('_JW_HISTORY_VISITORS',"Историја на посетители");
DEFINE('_JW_HISTORY_SHOWING_ONLY', "Прикажува само %d последни регистри.
                За да ја смените оваа вредност, идете во Подесувања -&gt; Историја и Перформанси -&gt; HISTORY_MAX_DB_RECORDS . Бидете внимателни, ова подесување влијае на времето на вчитување на датата.  ");
DEFINE('_JW_MENU_BUG', "Пријави грешка");
DEFINE('_JW_MENU_FEATURE', "Побарај можност");

DEFINE('_JW_VISITS_CAME_FROM_KEYWORDS',"Клучни зборови");

DEFINE('_JW_BLOCKING_UNBLOCK',"одблокирај");
DEFINE('_JW_STATS_KEYPHRASE ',"Клучна фраза");

DEFINE('_JW_STATUS_DATABASE_TABLE_NAME',"име на табела");
DEFINE('_JW_STATUS_DATABASE_ROWS',"редови");
DEFINE('_JW_STATUS_DATABASE_DATA',"дата");
DEFINE('_JW_STATUS_DATABASE_TOTAL',"вкупно");

DEFINE('_JW_EMAIL_REPORTS',"Извештаи од е-пошта");
DEFINE('_JW_EMAIL_REPORT_GENERATED',"Филтриран е-пошта извештај од вчера");
DEFINE('_JW_EMAIL_REPORTS_VALUE_FILTERS',"Вредност за филтер на е-пошта");
DEFINE('_JW_EMAIL_REPORTS_VALUE',"вредност");
DEFINE('_JW_EMAIL_REPORTS_PERCENT',"процент");
DEFINE('_JW_EMAIL_REPORTS_1DAY_CHANGE',"1-ден измена");
DEFINE('_JW_EMAIL_REPORTS_7DAY_CHANGE',"7-дена измена");
DEFINE('_JW_EMAIL_REPORTS_28DAY_CHANGE',"28-дена измена");
DEFINE('_JW_ANTISPAM_BLOCKED',"JoomlaWatch денеска блокираше %d посети од спам, вкупно: %d");
DEFINE('_JW_ANTISPAM_ADDRESSES',"Блокирани IP адреси");
DEFINE('_JW_ANTISPAM_SETTINGS',"Анти-спам подесувања");
DEFINE('_JW_TRAFFIC_AJAX',"AJAX ажурирања на сообраќај (освен мапи)");


DEFINE('_JW_HISTORY_PREVIOUS',"претходен");
DEFINE('_JW_HISTORY_NEXT',"следен");

/** additional translation for 1.2.11 for countries in more rows */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_COLUMNS',"Број на колони од држави");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_ROWS',"Број на редови од држави");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NAMES',"Прикажи или не, имиња на држави");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FLAGS_FIRST',"Прикажи прво знамиња, потоа проценти");

/* JoomlaWatch 1.2.14 translations */

DEFINE('_JW_GOALS_GET_INVERSED', "GET спротивен услов");
DEFINE('_JW_GOALS_POST_INVERSED', "POST спротивен услов");
DEFINE('_JW_GOALS_TITLE_INVERSED', "Спротивен услов за Наслов");
DEFINE('_JW_GOALS_USERNAME_INVERSED', "Спротивен услов за Корисничко име");
DEFINE('_JW_GOALS_CAME_FROM_INVERSED', "Дојдено од спротиен услов");

DEFINE('_JW_STATS_MAP', "Последна посета од мапа");
DEFINE('_JW_STATS_MAP_ENTER_KEY',"Молиме внесете <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a> клуч за да се прикаже последниот посетител од мапа:");
DEFINE('_JW_STATS_MAP_STORE_KEY',"клуч");
DEFINE('_JW_STATS_MAP_INVALID_KEY',"Молиме внесете валиден ipinfodb клуч кој го добивте од: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");

DEFINE('_JW_SIZEQUERY_BAD_REQUEST',"ЛОШО ПОБАРУВАЊЕ: ");

DEFINE('_JW_VISIT_SUBMITED_FIELDS',"Внесени полиња од формата:");
DEFINE('_JW_VISIT_URL_PARAMETERS',"URL параметри:");
DEFINE('_JW_VISIT_ADD_PAGE'," Додади ја страната како цел");
DEFINE('_JW_VISIT_BLOCK_IP'," Блокирајте ја оваа IP адреса");
DEFINE('_JW_VISIT_SUBMITED_FROM_VARIABLE'," Внесете ја оваа внесена променлива од формата како цел");
DEFINE('_JW_VISIT_URL_PARAMETER_GOAL'," Внесете ги параметрите на ова URL како цел");

DEFINE('_JW_TREND_EMPTY',"Празно");

DEFINE('_JW_NOT_NUMBER'," ВНИМАНИЕ: Вредноста која ја внесовте не е број. JoomlaWatch нема да работи исправноw!");
DEFINE('_JW_EVALUATION_LEFT',"&nbsp; Ова е 15 дневна пробна верзија. Останати денови: <b>%d</b>. Ве молиме купете ја вечната <a href='http://www.codegravity.com/donate/joomlawatch/' target='_blank'>JoomlaWatch лиценца за вашиот поддомен</a> за оваа и за наредните верзии кој следат.");
DEFINE('_JW_TRIAL_VERSION_EXPIRED'," Вашата пробна верзија е истечена. Ве молиме купете ја JoomlaWatch");

DEFINE('_JW_CONFIG_LICENSE_ACTIVATED',"Лиценцата е активирана успешно. Ви Благодариме");
DEFINE('_JW_CONFIG_LICENCE_DONT_MATCH',"<b>Грешка: Клучот за лиценца и вашиот поддомен не се совпаѓаат.</b><br/>Дали го внесовте истиот поддомен во формата за донација исто како што го гледате подоле? <br/>Кликни на '<b>побарај го точниот клуч за активација</b>' подоле, или контактирајте не на: info@codegravity.com<br/>");

DEFINE('_JW_VIEW_ADMINBODY_LONG_MESSAGE',"Ако ја гледате горната порака веќе подолго време, тогаш вашата страна во живо можеби е погрешна.
                    Отворете во components/com_joomlawatch/config.php
                    одкоментирајте, и наместете ја вашата актуелна страна во живо. На пр.:
                    define('JOOMLAWATCH_LIVE_SITE', 'http://www.codegravity.com');");

DEFINE('_JW_ADMINBODY_LIVE_SITE',"Внимание: страната во вашиот прелистувач и страната во живо во конфигурација: %s и %s не се совпаѓаат.");
DEFINE('_JW_ADMINBODY_SET_LIVE_SITE',"Намести ја живата страна во: %s и продолжи...");

DEFINE('_JW_ADMINHEADER_JW',"JoomlaWatch ");
DEFINE('_JW_ADMINHEADER_REMOVE_BACKLINK',"Отстрани заднински линк");
DEFINE('_JW_ADMINHEADER_KNOWLEDGE_BASE',"База на знаење");
DEFINE('_JW_ADMINHEADER_FLOW',"Проток");
DEFINE('_JW_ADMINHEADER_GRAPHS',"Графикони");
DEFINE('_JW_ADMINHEADER_COMPONENTS',"Компоненти");
DEFINE('_JW_ADMINHEADER_REVIEW',"Рецензија");
DEFINE('_JW_ADMINHEADER_WRITE',"Напиши ");

DEFINE('_JW_FLOW_TRAFFIC',"Промет на сообраќај");
DEFINE('_JW_FLOW_SELECT_PAGE',"Одбери страна:");
DEFINE('_JW_FLOW_OUTG_LINKS',"Број на надворешни линкови:");
DEFINE('_JW_FLOW_NESTING',"Ниво на гнездење:");
DEFINE('_JW_FLOW_SCALE',"Размер:");

DEFINE('_JW_COMERCIAL_AD_FREE',"Верзија слободна од рекламирање");
DEFINE('_JW_COMERCIAL_THANK_DONATION',"Ви благодариме многу за вашата донација!");
DEFINE('_JW_COMERCIAL_REGISTRATION_KEY',"Регистарскиот клуч за вашиот поддомен %s е: ");
DEFINE('_JW_COMERCIAL_BACKLINKS_REMOVE',"Сега можете да го отстраните заднинскиот линкот или да го скриете логото на JoomlaWatch на предната страна од подесувања ");


DEFINE('_JW_SIZES_LAST_CHECK',"Последна проверка е направена на:");
DEFINE('_JW_SIZES_ADMINISTRATOR',"BLUE = Големина на component/module во /administrator директориум");

DEFINE('_JW_SIZECOMPONENTS_COMPONENT',"Компонента");
DEFINE('_JW_SIZECOMPONENTS_TOTAL',"Вкупно:");
DEFINE('_JW_SIZECOMPONENTS_SIZE',"Големина");
DEFINE('_JW_SIZECOMPONENTS_REFRESH_ALL',"Освежи ги сите");

DEFINE('_JW_SIZEDATABASE_TABLE',"Табела");
DEFINE('_JW_SIZEDATABASE_SIZE',"Големина");
DEFINE('_JW_SIZEDATABASE_1DAY',"1-ден измена");
DEFINE('_JW_SIZEDATABASE_7DAY',"7-дена измена");
DEFINE('_JW_SIZEDATABASE_28DAY',"28-дена измена");
DEFINE('_JW_SIZEDATABASE_NO_DATA',"нема дата");
DEFINE('_JW_SIZEDATABASE_TOTAL',"Вкупно:");

DEFINE('_JW_SIZEMODULES_REFRESH_ALL',"Освежи ги сите");
DEFINE('_JW_SIZEMODULES_TOTAL',"Вкупно:");
DEFINE('_JW_SIZEMODULES_MODULE',"Модул");
DEFINE('_JW_SIZEMODULES_SIZE',"Големина");

DEFINE('_JW_SIZES_FILES',"Фајлови и Директориуми");
DEFINE('_JW_SIZES_BYTES',"бајти");
DEFINE('_JW_SIZES_KB',"Кб");
DEFINE('_JW_SIZES_MB',"Мб");
DEFINE('_JW_SIZES_GB',"Гб");
DEFINE('_JW_SIZES_REFRESH',"Освежи");

DEFINE('_JW_STATS_FOOTER',"JoomlaWatch &copy;2006-@YEAR@ од Матеј Ковал");

DEFINE('_JW_STATUS_MB',"Mб");
DEFINE('_JW_STATUS_DATABASE',"Големина на табелите во датабаза");


DEFINE('_JW_DESC_IPINFODB_KEY',"Последна посета на мапа од ipinfodb.com со клуч од: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");
DEFINE('_JW_SETTINGS_FORCE_TIMEZONE_OFFSET',"Форсирај ја временската зона");


/* JoomlaWatch 1.2.17 translations */
DEFINE('_JW_MENU_UPDATE', "Ажурирај");
DEFINE('_JW_MENU_UPDATE_TITLE', "Бекап и Надгради");
DEFINE('_JW_ADMINHEADER_NA_IN_THIS_VERSION',"Не е достапно во слободната верзија, ве молиме проверете го јазичето за лиценца");
DEFINE('_JW_SPAMWORD_BANS_ENABLED', "Овозможи банирање на спам зборови");
DEFINE('_JW_SPAMWORD_LIST', "Листа на спам зборови");
DEFINE('_JW_HIDE_REPETITIVE_TITLE', "Сокри ги повторувачките наслови");
DEFINE('_JW_TRUNCATE_VISITS', "Скрати ги посетите");
DEFINE('_JW_TRUNCATE_STATS', "Скрати ги статистиките");
DEFINE('_JW_TRUNCATE_GOALS', "Скрати ги целите");
DEFINE('_JW_LIMIT_BOTS', "Лимитирај Ботови");
DEFINE('_JW_LIMIT_VISITORS', "Лимитирај Посетители");
DEFINE('_JW_TOOLTIP_WIDTH', "Должина на советот");
DEFINE('_JW_TOOLTIP_HEIGHT', "Висина на советот");
DEFINE('_JW_TOOLTIP_URL', "Совет URL");
DEFINE('_JW_TOOLTIP_ONCLICK', "Совет на клик");
DEFINE('_JW_IP_STATS', "IP статистика");
DEFINE('_JW_IPINFODB_KEY', "IP инфо DB клуч ");
DEFINE('_JW_ONLY_LAST_URI', "Само последното URI ");

DEFINE('_JW_FRONTEND_HIDE_LOGO', "Скриј лого на предна страна ");
DEFINE('_JW_FRONTEND_NOFOLLOW', "Без следење на предна страна");
DEFINE('_JW_FRONTEND_NO_BACKLINK', "Без заднински линк на предна страна");
DEFINE('_JW_FRONTEND_USER_LINK', "Линкови на предна страна за корисник");
DEFINE('_JW_FRONTEND_COUNTRIES_FIRST', "Прво држави на предна страна");
DEFINE('_JW_FRONTEND_COUNTRIES_NAMES', "Имиња на држави на предна страна");
DEFINE('_JW_FRONTEND_COUNTRIES_UPPERCASE', "Држави со големи букви на предна страна");
DEFINE('_JW_FRONTEND_COUNTRIES_FLAGS_FIRST', "Прво знамињата на државите на предна страна ");
DEFINE('_JW_FRONTEND_COUNTRIES_NUM', "Број на држави на предна страна");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_COLUMNS', "Максимум колони на држави на предна страна");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_ROWS', "Максимум редови на држави на предна страна");
DEFINE('_JW_FRONTEND_VISITORS_TODAY', "Денешни посетители на предна страна ");
DEFINE('_JW_FRONTEND_VISITORS_YESTERDAY', "Вчерашни посетители на предна страна ");
DEFINE('_JW_FRONTEND_VISITORS_THIS_WEEK', "Посетители од оваа недела на предна страна ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_WEEK', "Посетители од минатата недела на предна страна ");

DEFINE('_JW_FRONTEND_VISITORS_THIS_MONTH', "Посетители од овој месец на предна страна ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_MONTH', "Посетители од минатиот месец на предна страна");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL', "Скриј вкупен број на посетители на предна страна");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL	', "Вкупно на предна страна");
DEFINE('_JW_HISTORY_MAX_VALUES', "Историски максимум вредности");
DEFINE('_JW_HISTORY_MAX_DB_RECORDS', "Историски максимум регистри");
DEFINE('_JW_UPDATE_TIME_VISITS', "Ажурирај ги временските посети");
DEFINE('_JW_UPDATE_TIME_STATS', "Ажурирај ги временските статистики");
DEFINE('_JW_STATS_MAX_ROWS', "Статистика максимум редови");
DEFINE('_JW_STATS_IP_HITS', "Статистика за IP посети");
DEFINE('_JW_MAXID_BOTS', "Максимум ID ботови");
DEFINE('_JW_MAXID_VISITORS', "Максимум id Посетители");
DEFINE('_JW_STATS_KEEP_DAYS', "Статистика зачувај денови ");
DEFINE('_JW_CACHE_FRONTEND_COUNTRIES', "Кеширај ги државите од предната страна ");
DEFINE('_JW_CACHE_FRONTEND_VISITORS', "Кеширај ги посетителите од предната страна ");

DEFINE('_JW_UNINSTALL_KEEP_DATA	', "Деинсталирај Keep Data ");
DEFINE('_JW_IGNORE_IP', "Игнорирај IP");
DEFINE('_JW_IGNORE_URI', "Игнорирај URI");
DEFINE('_JW_IGNORE_USER', "Игнорирај Корисник");
DEFINE('_JW_BLOCKING_MESSAGE', "Блокирана Порака");
DEFINE('_JW_SERVER_URI_KEY', "Сервер URI клуч");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL', "Вкупно посетители на предна страна");
DEFINE('_JW_SIZEDATABASE_RECORDS', "Регистар");
/***********EDITs******************/
DEFINE('_JW_ANTISPAM_BLOCKING_TEXT'," За да биде блокирањето успешно, мора да го објавите JoomlaWatch агентот ПРЕД било која содржина или форма. На пр. на левата страна од вашиот шаблон.
                    <br/>
                    Иди во менаџерот за модули -> JoomlaWatch агент -> одбери позиција за лево");

DEFINE('_JW_EMAIL_SEO_REPORTS', "SEO Извештаи");
DEFINE('_JW_DESC_EMAIL_SEO_REPORTS_ENABLED',"Овозможени SEO ноќни е-пошта извештаи");
DEFINE('_JW_WATCH_INSTALLATION_DEMO',"Погледни го демото за инсталација");

?>