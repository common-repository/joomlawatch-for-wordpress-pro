﻿<?php

/**
 * JoomlaWatch - برنامج جوملا للمتابعة الفورية والحصول على بيانات المواقع مباشرةً
 * @package JoomlaWatch
 * @version @VERSION@
 * @revision @REVISION@
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) @YEAR@ by Matej Koval - جميع الحقوق محفوظة!
 * @website http://www.codegravity.com
 **/
defined( '_JEXEC' ) or die( 'تصريح حصري' );

#JoomlaWatch ملف اللغة - لعمل ملف خاص للغة, فقط قم بنسخ ملف (english.php) إلى eg. german.php وقم بوضعه في /components/com_joomlawatch/lang/

# القائمة الرئيسية
DEFINE('_JW_MENU_STATS', "بيانات فورية");
DEFINE('_JW_MENU_GOALS', "أهداف");
DEFINE('_JW_MENU_SETTINGS', "إعدادات");
DEFINE('_JW_MENU_CREDITS', "أسماء المشرفين");
DEFINE('_JW_MENU_FAQ', "أسئلة متكررة");
DEFINE('_JW_MENU_DOCUMENTATION', "تدوين");
DEFINE('_JW_MENU_LICENSE', "ترخيص");
DEFINE('_JW_MENU_DONATORS', "المساندين");
DEFINE('_JW_MENU_SUPPORT', "أخرج إعلاناتم من مخرجات البرنامج JoomlaWatch ساند");


# الإطار الشمالي للزوار الفوريين
DEFINE('_JW_VISITS_VISITORS', "أحدث نسخة");
DEFINE('_JW_VISITS_BOTS', "روبوت");
DEFINE('_JW_VISITS_CAME_FROM', "أتى من");
DEFINE('_JW_VISITS_MODULE_NOT_PUBLISHED', "لم يتم نشر الوحدة النمطية بعد! لم يتم تسجيل أية بيانات ، للنشر توجه إلى قطاع الوحدات النمطية وقم بنشر وحدك النمطية في كل الصفحات");
DEFINE('_JW_VISITS_PANE_LOADING', "جاري تحميل الزيارات");

# إطار البيانات والإحصاءات على اليمين
DEFINE('_JW_STATS_TITLE', "بيانات الزيارات للأسبوع");
DEFINE('_JW_STATS_WEEK', "أسبوع");
DEFINE('_JW_STATS_THIS_WEEK', "هذا الأسبوع");
DEFINE('_JW_STATS_UNIQUE', "فريد");
DEFINE('_JW_STATS_LOADS', "تحميلات");
DEFINE('_JW_STATS_HITS', "عدد الزيارات");
DEFINE('_JW_STATS_TODAY', "لبيوم");
DEFINE('_JW_STATS_FOR', "لأجل");
DEFINE('_JW_STATS_ALL_TIME', "فوري");
DEFINE('_JW_STATS_EXPAND', "توسيع");
DEFINE('_JW_STATS_COLLAPSE', "طي");
DEFINE('_JW_STATS_URI', "صفحات");
DEFINE('_JW_STATS_COUNTRY', "دول");
DEFINE('_JW_STATS_USERS', "مستخدمين");
DEFINE('_JW_STATS_REFERERS', "المرجعات");
DEFINE('_JW_STATS_IP', "بروتوكولات الإنترنت");
DEFINE('_JW_STATS_BROWSER', "المتصفحات");
DEFINE('_JW_STATS_OS', "نظم التشغيل");
DEFINE('_JW_STATS_KEYWORDS', "كلمات مرشدة");
DEFINE('_JW_STATS_GOALS', "أهداف");
DEFINE('_JW_STATS_TOTAL', "مجموع كلي");
DEFINE('_JW_STATS_DAILY', "يومي");
DEFINE('_JW_STATS_DAILY_TITLE', "بيانات يومية");
DEFINE('_JW_STATS_ALL_TIME_TITLE', "بيانات فورية");
DEFINE('_JW_STATS_LOADING', "جاري التحميل");
DEFINE('_JW_STATS_LOADING_WAIT', "جاري التحميل برجاء الانتظار");
DEFINE('_JW_STATS_IP_BLOCKING_TITLE', "منع بروتوكول الإنترنت");
DEFINE('_JW_STATS_IP_BLOCKING_ENTER', "الدخول إلى بروتوكول الإنترنت يدوياً");
DEFINE('_JW_STATS_IP_BLOCKING_MANUALLY', "أدخل رقم الحاسوب المرغوب منع دخوله (على سبيل المثال 217.242.11.54 أو 217.242. لمنع دخول كل العناوين المطابقة لحروف الإحلال");
DEFINE('_JW_STATS_IP_BLOCKING_TOGGLE', "إبدال منع");
DEFINE('_JW_STATS_PANE_LOADING', "تحميل البيانات");

# الإعدادات
DEFINE('_JW_SETTINGS_TITLE', "إعدادات");
DEFINE('_JW_SETTINGS_DEFAULT', "االوضع الافاتراضي");
DEFINE('_JW_SETTINGS_SAVE', "حفظ");
DEFINE('_JW_SETTINGS_APPEARANCE', "المظهر");
DEFINE('_JW_SETTINGS_FRONTEND', "الواجهة الأمامية");
DEFINE('_JW_SETTINGS_HISTORY_PERFORMANCE', "المحفوظات وآداء خيار المعالجة المتعددة الغير متزامنة");
DEFINE('_JW_SETTINGS_ADVANCED', "خيارات متقدمة");
DEFINE('_JW_SETTINGS_IGNORE', "تجاهل");
DEFINE('_JW_SETTINGS_BLOCKING', "منع دخول");
DEFINE('_JW_SETTINGS_EXPERT', "خبير");
DEFINE('_JW_SETTINGS_RESET_CONFIRM', "هل تريد بالفعل إعادة ضبط كل بيانات الزائر؟");
DEFINE('_JW_SETTINGS_RESET_ALL', "إعادة ضبط الكل");
DEFINE('_JW_SETTINGS_RESET_ALL_LINK', "إعادة ضبط كل بيانات الزائر ومعلوماته");
DEFINE('_JW_SETTINGS_LANGUAGE', "اللغة");
DEFINE('_JW_SETTINGS_SAVED', "تم حفظ الإعدادت");
DEFINE('_JW_SETTINGS_ADD_YOUR_IP', "أضف عنوان حاسوبك الرقمي");
DEFINE('_JW_SETTINGS_TO_THE_LIST', "إلى القائمة.");

# غير ذلك / بيانات عامة في العموم
DEFINE('_JW_TITLE', "برنامج جوملا للمتابعة الفورية والحصول على بيانات المواقع مباشرة");
DEFINE('_JW_BACK', "عودة");
DEFINE('_JW_ACCESS_DENIED', "ليس لديك أي تصريح لرؤية هذا!");
DEFINE('_JW_LICENSE_AGREE', "أوافق على الشروط واللوائح أعلاه");
DEFINE('_JW_LICENSE_CONTINUE', "استمرار");
DEFINE('_JW_SUCCESS', "تمت العملية بنجاح");
DEFINE('_JW_RESET_SUCCESS', "تم مسح كل بيانات وإحصائيات الزائر");
DEFINE('_JW_RESET_ERROR', "لم يتم مسح البيانات، لقد وقع خطأ ما");
DEFINE('_JW_CREDITS_TITLE', "أسماء المشرفين");
DEFINE('_JW_TRENDS_DAILY_WEEKLY', "بيانات وإحصاءات يومية وأسبوعية لـ...");
DEFINE('_JW_AJAX_PERMISSION_DENIED_1', " Joomla لبرنامج configuration.php برجاء رؤية هذه الإحصائية من النطاق الذي حددته في AJAX تم رفض إعطاء الإذن من قبل برنامج ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_2', " قبل اسم النطاق الخاص بكwww. ربما نسيت أن تضع . الجافا سكريبت الخاص بك يحاول الدخول ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_3', "من");
DEFINE('_JW_AJAX_PERMISSION_DENIED_4', "ما سبب ظنك أنه نطاق آخر");

# رأس الصفحة
DEFINE('_JW_HEADER_DOWNLOAD', "احصل على أحدث شفرة لملح الاسم من خلال");
DEFINE('_JW_HEADER_CAST_YOUR', "من فضلك ادلو");
DEFINE('_JW_HEADER_VOTE', "بصوتك");

# تعريف الأدوات
DEFINE('_JW_TOOLTIP_CLICK', "أنقر لإظهار تعريف الأدوات");
DEFINE('_JW_TOOLTIP_MOUSE_OVER', "حرك الفأرة عليها لإظهار تعريف الأدوات");
DEFINE('_JW_TOOLTIP_YESTERDAY_INCREASE', "زيادة الأمس");
DEFINE('_JW_TOOLTIP_HELP', "فتح المساعدة الخارجية على الإنترنت لأجل");
DEFINE('_JW_TOOLTIP_WINDOW_CLOSE', "أغلق هذا الإطار");
DEFINE('_JW_TOOLTIP_PRINT', "اطبع");

# الأهداف
DEFINE('_JW_GOALS_INSERT', "ادراج هدف جديد");
DEFINE('_JW_GOALS_UPDATE', "تحديد رقم الهدف");
DEFINE('_JW_GOALS_ACTION', "إجراءات");
DEFINE('_JW_GOALS_TITLE', "هدف جديد");
DEFINE('_JW_GOALS_NEW', "هدف جديد");
DEFINE('_JW_GOALS_RELOAD', "إعادة تحميل");
DEFINE('_JW_GOALS_ADVANCED', "إعداد متقدم");
DEFINE('_JW_GOALS_NAME', "اسم");
DEFINE('_JW_GOALS_ID', "تعريف");
DEFINE('_JW_GOALS_URI_CONDITION', "حالة معرف المصدر المنتظم");
DEFINE('_JW_GOALS_URI_INVERSED', "الحالة العكسية لمعرف المصدر المنتظم");
DEFINE('_JW_GOALS_GET_VAR', "GET تباين الـ");
DEFINE('_JW_GOALS_GET_CONDITION', "GETحالة الـ");
DEFINE('_JW_GOALS_POST_VAR', "تباين التوزيع");
DEFINE('_JW_GOALS_POST_CONDITION', "حالة التوزيع");
DEFINE('_JW_GOALS_TITLE_CONDITION', "حالة العنوان");
DEFINE('_JW_GOALS_USERNAME_CONDITION', "حالة اسم المستخدم");
DEFINE('_JW_GOALS_IP_CONDITION', "حالة العنوان الرقمي");
DEFINE('_JW_GOALS_IP_INVERSED', "حالة العنوان الرقمي العكسية");
DEFINE('_JW_GOALS_CAME_FROM_CONDITION', "ناتج عن الحالة");
DEFINE('_JW_GOALS_BLOCK', "منع");
DEFINE('_JW_GOALS_REDIRECT', "إعادة توجيه لمحدد موقع المعلومات");
DEFINE('_JW_GOALS_HITS', "عدد الزيارات");
DEFINE('_JW_GOALS_ENABLED', "تم التفعيل");
DEFINE('_JW_GOALS_EDIT', "تحرير");
DEFINE('_JW_GOALS_DELETE', "مسح");
DEFINE('_JW_GOALS_DELETE_CONFIRM', "ستفقد كل البيانات الأخيرة لإحصائيات هذا الهدف، هل أنت واثق من أنك تود مسح رقم الهدف؟");

# واجهة أمامية
DEFINE('_JW_FRONTEND_COUNTRIES', "دول");
DEFINE('_JW_FRONTEND_VISITORS', "زائرين");
DEFINE('_JW_FRONTEND_TODAY', "اليوم");
DEFINE('_JW_FRONTEND_YESTERDAY', "أمس");
DEFINE('_JW_FRONTEND_THIS_WEEK', "هذا الأسبوع");
DEFINE('_JW_FRONTEND_LAST_WEEK', "الأسبوع الماضي");
DEFINE('_JW_FRONTEND_THIS_MONTH', "هذا الشهر");
DEFINE('_JW_FRONTEND_LAST_MONTH', "الشهر الماضي");
DEFINE('_JW_FRONTEND_TOTAL', "المجموع الكلي");

# Settings description - quite long
DEFINE('_JW_DESC_DEBUG', "0 -1 من /components/com_joomlawatch/config.php في JOOMLAWATCH_DEBUGبهذه الطريقة يمكنك اكتشاف سبب الخطأ وللإغلاق برجاء تغيير قيمة JoomlaWatch في وضع معالجة الأخطاء");
DEFINE('_JW_DESC_STATS_MAX_ROWS', "أقصى عدد للصفوف يظهر حين تكون الإحصائيات في النمط الموسع");
DEFINE('_JW_DESC_STATS_IP_HITS', ".كل العنواين الرقمية التي حصلت على عدد زائرين أقل من هذه القيمة في الأيام السابقة ستمسح تلقائياً من محفوظات العناوين الرقمية");
DEFINE('_JW_DESC_STATS_URL_HITS', ".جميع محددات مواقع المعلومات التي تتلقى عدد زائرين أقل في لأيام السابقة من قيمة هذا اليوم سوف يتم محوها من محفوظات العناوين الرقمية");
DEFINE('_JW_DESC_IGNORE_IP', ".استبعد عناوين رقمية محددة من البيانات الإحصائية وقم بالفصل بخط جديد ويمكنك استخدام الإحلال هنا <br/>Eg. 192.* يتم تجاهل 192.168.51.31, 192.168.16.2, etc..");
DEFINE('_JW_DESC_UPDATE_TIME_VISITS', "JoomlaWatchوقت التحديث للزائرين يقاس بالملليثانية والافتراضي هو 2000 وكن حذراً أثناء ذلك ثم أعد تحميل البيانات الخلفية لـ");
DEFINE('_JW_DESC_UPDATE_TIME_STATS', "JoomlaWatch وقت تحديث البيانات الإحصائية يقاس بالملليثانية والمفترض هو 4000 وكن حذراً أثناء ذلك ثم أعد تحميل البيانات الخلفية لـ");
DEFINE('_JW_DESC_MAXID_BOTS', "كم عدد زيارات الروبوتات التي يمكن الإبقاء عليها بقاعدة البيانات");
DEFINE('_JW_DESC_MAXID_VISITORS', "كم عدد الزيارات الحقيقية التي يمكن الإباقء عليها في قاعدة البيانات");
DEFINE('_JW_DESC_LIMIT_BOTS', "كم عدد الروبوتات التي ستراها في البيانات الخلفية");
DEFINE('_JW_DESC_LIMIT_VISITORS', "كم عدد الزيارات الحقيقية التي ستراها في البيانات الخلفية");
DEFINE('_JW_DESC_TRUNCATE_VISITS', "أقصى عدد للأحرف يمكن أن تظهر في العناوين الطويلة ومعرفات المصادر المنتظمة");
DEFINE('_JW_DESC_TRUNCATE_STATS', "أقصى عدد أحرف تظهر في لوحة البيانات الإحصائية على اليمين");
DEFINE('_JW_DESC_STATS_KEEP_DAYS', "عدد الأيام التي يتم الإبقاء فيها على الإحصائيات في قاعدة البيانات، صفر يساوي ما لا نهاية ");
DEFINE('_JW_DESC_TIMEZONE_OFFSET', "حين تكون في نطاق زمني مختلف عن الملقم المضيف سواء كان يسبقك أو يقل عنك بالساعات");
DEFINE('_JW_DESC_WEEK_OFFSET', "إزاحة الأسبوع, الطابع الزمني/(3600*24*7) يعطي رقم الأسبوه بداءً من 1.1.1970, هذه الإزاحة بمثابة تصحيح لجعله يبدأ من الاثنين ");
DEFINE('_JW_DESC_DAY_OFFSET', "إزاحة اليوم, الطابع الزمني/(3600*24) gives يعطي رقم اليوم بداءً من 1.1.1970, هذه الإزاحة بمثابة تصحيح ليجعل اليوم يبدأ من 00:00 ");
DEFINE('_JW_DESC_FRONTEND_HIDE_LOGO', "<b>(تعمل في النسخة الاحترافية)</b> استخدام علامة فارغة 1x1px أيقونة في البيانات الأمامية");
DEFINE('_JW_DESC_IP_STATS', "لتشفعيل إحصائيات العنوان الرقمي. في بعض الدول يكون الاحتفاظ بالعنوان الرقمي في قاعدة البيانات مخالفاً للقانون. استخدم الخاصية على مسؤوليتك الخاصة.");
DEFINE('_JW_DESC_HIDE_ADS', "هذا الإعداد يخفي الإعلانات في البيانات الخلفية, إذا كانت تزعجك كثيراً. بالإبقاء عليها, أنت تساند تطوير هذه الأداة أكثر. شكراً");
DEFINE('_JW_DESC_TOOLTIP_ONCLICK', "أزل العلامةإذا كنت تريد إظهار تعريف الأدوات عند القيام بتحريك الفأرة عليها بدلاً من النقر بالفأرة عليها");
DEFINE('_JW_DESC_SERVER_URI_KEY', "الوضع الافتراضي هو 'REDIRECT_URL', وهذا هو الأمر القياسي لإعادة كتابة عناوين الـURL, يمكن الضبط على 'SCRIPT_URL' إذا تم التسجيل إلى index.php");
DEFINE('_JW_DESC_BLOCKING_MESSAGE', "الرسالة التي تظهر للمستخدمين الممنوعين من الدخول أو أية معلومات أخرى عن سبب منعك لدخول أولئك المستخدمين.");
DEFINE('_JW_DESC_TOOLTIP_WIDTH', "عرض تعريف الأدوات");
DEFINE('_JW_DESC_TOOLTIP_HEIGHT', "ارتفاع تعريف الأدوات");
DEFINE('_JW_DESC_TOOLTIP_URL', "هنا URL يمكنك وضع أي عنوان, لرؤية العنوان الرقمي لأي زائر. سيتم استبدال {ip} بالعنوان الرقمي للزائر. على سبيل المثال. http://somewebsite.com/query?iplookup={ip}");
DEFINE('_JW_DESC_IGNORE_URI', "يمكنك طباعة أي عنوان معرف مصدر منتظم ترغب في منعه من منطقة البيانات الإحصائية. يمكنك استخدام حروف الإحلال (* and ?) هنا. مثلاً.: /freel?n* ");
DEFINE('_JW_DESC_GOALS_NAME', "حدد اسم الهدف هنا وسيظهر الاسم في البيانات الإحصائية");
DEFINE('_JW_DESC_GOALS_URI_CONDITION', "أي شيء يعقب اسم نطاقك. لأجل http://www.codegravity.com/projects/ معرف المصادر المنتظم يكون: /projects/ (مثال على الاستخدام: <b>/projects*</b>)");
DEFINE('_JW_DESC_GOALS_GET_VAR', "متغير الـGET هو متغير يمكنك رؤيته بعد عنوان الـURL عادة بعد ? أو &amp; علامة. مثال. http://www.codegravity.com/index.php?<u>name</u>=peter&amp;<u>surname</u>=smith. يمكنك استخدام أيضاً <u>*</u> في هذا المجال لعمل مسح لكل قيم الـGET. (Example to use: <b>n*me</b>)");
DEFINE('_JW_DESC_GOALS_GET_CONDITION', "هنا عليك أن تحدد معادل معين لقيمة المجال السابق. (على سبيل المثال استخدام: <b>p?t*r</b>) ");
DEFINE('_JW_DESC_GOALS_POST_VAR', "مماثل جداً, لكننا نتحقق من القيم المعطاة من النماذج. لذا حين يكون لديك نموذج على موقعك الإلكتروني, وبه مجال &lt;نوع المدخلات='text' اسم='<u>خبرات</u>' /&gt;. (مثال الاستخدام: <b>exper*ces</b>)");
DEFINE('_JW_DESC_GOALS_POST_CONDITION', "معادل لقيمة مجال الإرسال. مثال. نود أن نتحقق من كون المستخدم لديه java ex                                                                                                         periences. (Example to use: <b>*java*</b>)");
DEFINE('_JW_DESC_GOALS_TITLE_CONDITION', "عنوان صفحة يجب أن يكون معادلاً. (مثال الاستخدام: <b>*مبرمجين مستقلين*</b>)");
DEFINE('_JW_DESC_GOALS_USERNAME_CONDITION', "اسم مستخدم قام بتسجيل دخوله. (مثلاً اسنخدام: <b>psmith*</b>)");
DEFINE('_JW_DESC_GOALS_IP_CONDITION', "عنوان رقمي يدل على أن المستخدم آت من: (مثلاً استخدام: <b>201.9?.*.*</b>)");
DEFINE('_JW_DESC_GOALS_CAME_FROM_CONDITION', "عنوان الـURL الذي يأتي منه المستخدم. (مثال الاستخدام: <b>*www.google.*</b>)");
DEFINE('_JW_DESC_GOALS_REDIRECT', "يتم إعادة توجيه المستخدم إلى عنوان URL حددته أنت. له أولية أكثر من منع الدخول: (مثال الاستخدام: <b>http://www.codegravity.com/goaway.html</b>)");
DEFINE('_JW_DESC_TRUNCATE_GOALS', "كم عدد الأحرف التي ستقطع في جدول الأهداف");
DEFINE('_JW_DESC_FRONTEND_NO_BACKLINK', "<b>(يعمل في نسخة المحترفين)</b> رابط عودة إلى codegravity.com, يمكنك إبطال هذا, لكننا سنكون ممتنين لك لو استبقيت عليه. شكراً");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES', "اعرض مجموع البيانات الإحصائية للدول في الوحدة النمطية للبيانات الأمامية. إذا تم التغيير, هذا الإعداد سيكون قيد التشغيل في البيانات الأمامية عقب الوقت المحدد في ذاكرة التخزين المؤقت CACHE_FRONTEND_ ");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FIRST', "إذا أردت أن تقوم بإبدال ترتيب الزائرين والدول في البيانات الأمامية. قم بإلغاء الاختيار وحينها سيظهر الزائرين أولاً.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NUM', "عدد البلدان التي ستظهر في البيانات الأمامية");
DEFINE('_JW_DESC_FRONTEND_VISITORS', "اعرض الزائرين الدول في الوحدة النمطية للبيانات الأمامية. لو تم التغيير سيكون هذا الإعداد قيد التطبيق في البيانات الأمامية بعد الوقت الذي تم ضبطه في ذاكرة التخزين المؤقت في CACHE_FRONTEND_");
DEFINE('_JW_DESC_CACHE_FRONTEND_COUNTRIES', "الوقت بالثانية لجلب مجموع عدد الدول في البيانات الأميمية من ذاكرة التخزين المؤقتة");
DEFINE('_JW_DESC_CACHE_FRONTEND_VISITORS', "الوقت بالثانية لجلب عدد الزائرين في البيانات الأمامية من ذاكرة التخزين المؤقتة");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TODAY', "لعرض الزائرين في البيانات الأمامية لـ: اليوم. لو تم التغيير سيكون هذا الإعداد قيد التطبيق في البيانات الأمامية بعد الوقت الذي تم ضبطه في ذاكرة التخزين المؤقتة CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_YESTERDAY', "لعرض الزائرين في البيانات الأمامية لـ: أمس. لو تم التغيير سيكون هذا الإعداد قيد التطبيق في البيانات الأمامية بعد الوقت الذي تم ضبطه في ذاكرة التخزين المؤقتة CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_WEEK', "لعرض الزائرين في البيانات الأمامية لـ: هذا الأسبوع. لو تم التغيير سيكون هذا الإعداد قيد التطبيق في البيانات الأمامية بعد الوقت الذي تم ضبطه في ذاكرة التخزين المؤقتة CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_WEEK', "لعرض الزائرين في البيانات الأمامية لـ: الأسبوع الماضي. لو تم التغيير سيكون هذا الإعداد قيد التطبيق في البيانات الأمامية بعد الوقت الذي تم ضبطه في ذاكرة التخزين المؤقتة CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_MONTH', "لعرض الزائرين في البيانات الأمامية لـ: هذا الشهر. لو تم التغيير سيكون هذا الإعداد قيد التطبيق في البيانات الأمامية بعد الوقت الذي تم ضبطه في ذاكرة التخزين المؤقتة CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_MONTH', "لعرض الزائرين في البيانات الأمامية لـ: الشهر الماضي. لو تم التغيير سيكون هذا الإعداد قيد التطبيق في البيانات الأمامية بعد الوقت الذي تم ضبطه في ذاكرة التخزين المؤقتة CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL', "لعرض مجموع الزائرين منذ تثبيت برنامج JoomlaWatch. لو تم التغيير سيكون هذا الإعداد قيد التطبيق في البيانات الأمامية بعد الوقت الذي تم ضبطه في ذاكرة التخزين المؤقتة CACHE_FRONTEND_...");
DEFINE('_JW_DESC_LANGUAGE', "ملف اللغة المتاح للاستخدام. إنها متاحة في /components/com_joomlawatch/lang/. إذا أردا إدخال ملف لغة آخر, أولاً تحقق من الصفحة الرئيسية للمشروع, وإذا كان ملف اللغة لا يزال غير موجود هناك, فقط انسخ الملف الافاتراضي english.php إلى على سبيل المثال. german.php and وضعه في هذا الدليل. ثم قم بترجمة كل مفاتيح القيم على اليمين.");
DEFINE('_JW_DESC_GOALS', "الأهداف تتيح لك تحديد معلمات محددة. حين تتطابق هذه المعلمات, يزداد عداد الأهداف. بهذه الطريقة يمكنك مراقبة ما إذا كان المستخدم بزيارة عنوان URL معين أو كونه أرسل قيمة معينة أو كونه لديه اسم مستخدم معين أو كونه جاء من عنوان معين ويمكنك كذلك منع دخول أو إعادة توجيه مثل أولئك المستخدمين إلى  عنوان URL آخر.");
DEFINE('_JW_DESC_GOALS_INSERT', "في كل هذه المجالات عدا الاسم يمكنك استخدام * أو ? كحروف الإحلال. على سبيل المثال: ?ear (ستطابق: near, tear, ..),  p*r (ستطابق: pr, peer, pear ..) ");
DEFINE('_JW_DESC_GOALS_BLOCK', "اضبط على 1, لو أردت منع دخول هذا المستخدم. لن يرى بقية المحتوى, بل فقط رسالة تعلمه بأنه تم منعه من الدخول - بدون إعادة توجيه وسيتم إضافة عنوانه الرقمي إلى قائمة المنع في البيانات الإحصائية (مثال على الاستخدام: <b>1</b>)");

/* new الترجمات */
DEFINE('_JW_GOALS_COUNTRY_CONDITION', "حالة الدولة");
DEFINE('_JW_GOALS_CONTRY_INVERSED', "حالة الدولة العكسية");
DEFINE('_JW_DESC_GOALS_COUNTRY_CONDITION', "الدول ذات الرموز ثنائية الرقم تكون بالأعلى (Eg: <b>TH</b>)");
DEFINE('_JW_STATS_INTERNAL',"دلخلي");
DEFINE('_JW_STATS_FROM',"من");
DEFINE('_JW_STATS_TO',"إلى");
DEFINE('_JW_STATS_ADD_TO_GOALS',"أضف إلى الأهداف");
DEFINE('_JW_VISITS_ADD_GOAL_COUNTRY',"أضف هدف لهذه الدولة");
DEFINE('_JW_MENU_REPORT_BUG',"الإبلاغ عن خطأ ما أو ميزة ما");
DEFINE('_JW_GOALS_COUNTRY',"دولة");


/* translations 1.2.8b_12 */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_UPPERCASE',"لو أنك تريد أسماء الدول في أعلى قائمة البيانات الأمامية (مثال: GERMANY, UNITED KINGDOM instead of Germany, United Kingdom)");
DEFINE('_JW_DESC_CACHE_FRONTEND_USERS',"الوقت بالثانية لجلب المستخدمين من ذاكرة البيانات المؤقتة إلى البيانات الأمامية");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL_INITIAL', "تم عرض مجمل القيمة الأولية: في البيانات الأمامية. هذا يفيد حين تنتقل من أداة بيانات أخرى. (مثال.: 20000). أعد الضبط إلى 0 إذا لم تكن تريد هذه الخاصية.");
DEFINE('_JW_DESC_IGNORE_USER', "تجاهل المستخدمين الموجودين في الصندوق النصي. كل واحد بسطر وحده. (مثال.: myself {line break} mark_*) ");
DEFINE('_JW_FRONTEND_USERS_MOST', "المستخدمين الأكثر نشاطاً من بين مجموع كلي");
DEFINE('_JW_DESC_SPAMWORD_BANS_ENABLED',"تفعيل الموانع بناءً على الكلمات المذكورة في قائمة منع الإحالات الغير مرغوبة بالأسفل؟");
DEFINE('_JW_DESC_SPAMWORD_LIST',"معظم كلمات الإحالة الغير مرغوب بها المستخدمة من قبل روبوتات الإحالات. يمكنك استخدام الإحلال هنا, (مثال.: ph?rmac*). لو أن الإعداد أعلاه قيد التطبيق, سيقوم برنامج JoomlaWatch بالتحقق ما إذا كان المهاجم قد قدم نموذجاً (طلب إرسال HTTP) على موقعك ببعض من نفس كلمات الإحالة الغير مرغوبة وهذا ينطبق في حالة أن النموذج يحمل على موقع إلكتروني واقع في Joomla فقط إذا كانت منتديات أو تعليقات لكنه سيكون فعال جداً في منع دخول روبوتات الإحالات الغير مرغوبة والتي تحاول تسجيل كل النماذج الممكنة");
DEFINE('_JW_SETTINGS_ANTI_SPAM',"مضاد الإحالات الغير مرغوبة");
DEFINE('_JW_DESC_FRONTEND_USER_LINK'," (Eg. index.php?option=com_comprofiler&task=userProfile&user={user})يوجد رابط في الوحدة النمطية بالبيانات الأمامية يتيح لك تحديد الـيو آر إل والذي يكون مفتوحاً حين يقوم المستخدم بالنقر على عنوان اسم المستخدم والذي يجب أن يحتوي على تسلسل أحرف كلمة مستخدم والتي ستستبدل باسم المستخدم الحقيقي وعلى سبيل المثال ");

/* ترجمات 1.2.11b */
DEFINE('_JW_STATS_KEYPHRASE', "عبارة مرشدة");
DEFINE('_JW_DESC_HISTORY_MAX_VALUES', "القيمة القصوى في جدول المحفوظات (مثال: <i>100</i>)");

DEFINE('_JW_DESC_ONLY_LAST_URI', "في الزيارات أظهر فقط آخر صفحة تمت زيارتها وليس كل الصفحات");
DEFINE('_JW_DESC_HIDE_REPETITIVE_TITLE', "افي الزيارات قم بإخفاء أسماء المواقع المكررة في عنوان الصفحة التي تم زيارتها");
DEFINE('_JW_DESC_HISTORY_MAX_DB_RECORDS', "أقصى عدد زوار يسجل في قاعدة بيانات محفوظات الزيارات. كن حذراً في التعامل مع هذا الإعداد, لو أن موقعك يحظى بكثير من الزيارات, يمكن أن تيكاثر هذا بسرعة كبيرة. Statusدائماً تفقد كم البيانات الموجود في جدول المحفوظات في قسم ");
DEFINE('_JW_DESC_UNINSTALL_KEEP_DATA', "احتفظ بجداول قاعدة البيانات في إزالة التثبيت وضع علامة على هذا الاختيار قبل إزالة التثبيت في حال رغبتك في القيام بتحسين وتود الاحتفاظ بالبيانات");

/* email reports */
DEFINE('_JW_DESC_EMAIL_REPORTS_ENABLED', "ستتلقى رسالة إلكترونية ليلية تحوي تقرير عن نشاط اليوم السابق ويمكنك قراءتها صباحاً");
DEFINE('_JW_DESC_EMAIL_REPORTS_ADDRESS', "عنوان البريد الإلكتروني الذي ستتلقى عليه هذه التقارير");
DEFINE('_JW_DESC_EMAIL_PERCENT_HIGHER_THAN', "في تقارير البريد الإلكتروني تضمن الصفوف التي تحوي نسبة مئوية أكثر من  {value}. اضبط على 0 إذا كنت لا تود استعمال هذه الخاصية <i>(مثال: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_POSITIVE', "تضمن فقط <b>زائد يوم واحد</b> غير القيمة في تقارير البريد الإلكتروني لتكون أعلى من (القيمة) مئوية. اضبط على 0 إذا كنت لا تود استعمال هذه الخاصية <i>(مثال: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_NEGATIVE', "تضمن فقط <b>سالب يوم واحد</b> غير القيمة في تقارير البريد الإلكتروني لتكون أقل من (القيمة) مئوية. اضبط على صفر إذا كنت لا تود استعمال هذه الخاصية <i>(مثال: -10)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_POSITIVE', "تضمن فقط <b>زائد سبعة أيام</b> غير القيمة في تقارير البريد الإلكتروني لتكون أعلى من (القيمة) مئوية. اضبط على صفر إذا كنت لا تود استعمال هذه الخاصية <i>(مثال: 2)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_NEGATIVE', "تضمن فقط <b>سالب سبعة أيام</b> غير القيمة في تقارير البريد الإلكتروني لتكون أقل من (القيمة) مئوية. اضبط على 0 إذا كنت لا تود استعمال هذه الخاصية <i>(مثال: -13)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_POSITIVE', "تضمن فقط <b>زائد 28 يوم</b> غير القيمة في تقارير البريد الإلكتروني لتكون أعلى من (القيمة) مئوية. اضبط على 0 إذا كنت لا تود استعمال هذه الخاصية <i>(مثال: 2)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_NEGATIVE', "تضمن فقط <b>سالب 28 يوم</b> غير القيمة في تقارير البريد الإلكتروني لتكون أقل من (القيمة) مئوية. اضبط على 0 إذا كنت لا تود استعمال هذه الخاصية <i>(مثال: -13)</i>");

DEFINE('_JW_DESC_FRONTEND_NOFOLLOW', "<b>(يعمل في نسخة المحترفين)</b> قم بتفعيل هذه الخاصية لو أنك تود إظهار الشعار المشير للبرنامج rel='nofollow' ");
DEFINE('_JW_DESC_EMAIL_NAME_TRUNCATE', "هذا هو الحد الأقصى لعدد أحر اسم صف الرسالة الإلكترونية قم بتغيير هذا لو أن إطار الرسائل لدى عميل الالرسائل الإلكترونية الخاص بك أصغر كثيراً");

DEFINE('_JW_MENU_HISTORY', "المحفوظات");
DEFINE('_JW_MENU_EMAILS', "رشائل إلكترونية");
DEFINE('_JW_MENU_STATUS', "وضع قاعدة البيانات");
DEFINE('_JW_DESC_BLOCKED',"هذه العناوين الرقمية تم منعها من قبل مضاد الإحالات الغير مرغوبة");


DEFINE('_JW_HISTORY_VISITORS',"محفوظات الزوار");
DEFINE('_JW_HISTORY_SHOWING_ONLY', "إظهار آخر التقارير فقط.
                لتغيير هذه القيمة اذهب للإعدادات -&gt; محفوظات &amp; آداء -&gt; HISTORY_MAX_DB_RECORDS . كن حذراً لأن هذا الإعداد يؤثر على وقت تحميل البيانات المبينة أدناه  ");
DEFINE('_JW_MENU_BUG', "الإبلاغ عن شائبة");
DEFINE('_JW_MENU_FEATURE', "طلب هذه الخاصية");

DEFINE('_JW_VISITS_CAME_FROM_KEYWORDS',"كلمات مرشدة");

DEFINE('_JW_BLOCKING_UNBLOCK',"إلغاء المنع");
DEFINE('_JW_STATS_KEYPHRASE ',"عبارة مرشدة");

DEFINE('_JW_STATUS_DATABASE_TABLE_NAME',"اسم الجدول");
DEFINE('_JW_STATUS_DATABASE_ROWS',"صفوف");
DEFINE('_JW_STATUS_DATABASE_DATA',"بيانات");
DEFINE('_JW_STATUS_DATABASE_TOTAL',"مجموع كلي");

DEFINE('_JW_EMAIL_REPORTS',"تقارير البريد الإلكتروني");
DEFINE('_JW_EMAIL_REPORT_GENERATED',"تقرير مصفي الرسائل الإلكترونية لأمي وفقاً للإعداد");
DEFINE('_JW_EMAIL_REPORTS_VALUE_FILTERS',"مصفيات الرسائل الإلكترونية بناءً على القيمة");
DEFINE('_JW_EMAIL_REPORTS_VALUE',"قيمة");
DEFINE('_JW_EMAIL_REPORTS_PERCENT',"مئوية");
DEFINE('_JW_EMAIL_REPORTS_1DAY_CHANGE',"تغيير ليوم واحد");
DEFINE('_JW_EMAIL_REPORTS_7DAY_CHANGE',"تغيير لسبعة أيام");
DEFINE('_JW_EMAIL_REPORTS_28DAY_CHANGE',"تغيير لثمتنية وعشرون يوماً");
DEFINE('_JW_ANTISPAM_BLOCKED',"منعت دخول عدد من إحالات غير مرغوبة JoomlaWatch, المجموع الكلي: %d");
DEFINE('_JW_ANTISPAM_ADDRESSES',"أرقام العنواين الممنوعة من الدخول");
DEFINE('_JW_ANTISPAM_SETTINGS',"الإعدادات المضادة للإحالات الغير مرغوب فيها");
DEFINE('_JW_TRAFFIC_AJAX',"لمقدار الزيارات عدا الخرائط AJAX تحديث");


DEFINE('_JW_HISTORY_PREVIOUS',"السابق");
DEFINE('_JW_HISTORY_NEXT',"التالي");

/** ترجمات إضافية 1.2.11 لأجل دول في صفوفو أكثر */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_COLUMNS',"عدد أعمدة الدول الأقصى");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_ROWS'," اأقصى عدد صفوف أسماء الدول");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NAMES',"لإظهار اسم الدولة أو إخفاءه");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FLAGS_FIRST',"لإظهار إشارة الرسائل أولاً ثم المئويات");

/* JoomlaWatch 1.2.14 ترجمات */

DEFINE('_JW_GOALS_GET_INVERSED', "GET الحالة المعكوسة للـ");
DEFINE('_JW_GOALS_POST_INVERSED', "الحالة المعكوسة لأمر الإرسال");
DEFINE('_JW_GOALS_TITLE_INVERSED', "الحالة المعكوسة للعنوان");
DEFINE('_JW_GOALS_USERNAME_INVERSED', "الحالة المعكوسة لاسم المستخدم");
DEFINE('_JW_GOALS_CAME_FROM_INVERSED', "نتج عن الحالة المعكوسة");

DEFINE('_JW_STATS_MAP', "خريطة آخر زيارة");
DEFINE('_JW_STATS_MAP_ENTER_KEY'," لعرض خريطة آخر زيارة<a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a> :برجاء إدخال مفتاح");
DEFINE('_JW_STATS_MAP_STORE_KEY',"مفتاح تخزين");
DEFINE('_JW_STATS_MAP_INVALID_KEY',"برجاء إدخال مفتاح العنوان الرقمي بقاعدة البيانات بشكل صحيح كما رأيته في: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");

DEFINE('_JW_SIZEQUERY_BAD_REQUEST',"طلب غير صالح: ");

DEFINE('_JW_VISIT_SUBMITED_FIELDS',"تم التسليم من مجالات:");
DEFINE('_JW_VISIT_URL_PARAMETERS',"URL معلمات الـ");
DEFINE('_JW_VISIT_ADD_PAGE'," أضف الصفحة كهدف");
DEFINE('_JW_VISIT_BLOCK_IP'," امنع دخول هذا العنوان الرقمي");
DEFINE('_JW_VISIT_SUBMITED_FROM_VARIABLE'," أضف هذا التسليم من المتغير كهدف");
DEFINE('_JW_VISIT_URL_PARAMETER_GOAL'," كهدف URL أضف معلمات الـ");

DEFINE('_JW_TREND_EMPTY',"فارغ");

DEFINE('_JW_NOT_NUMBER',"لن يعمل بشكل صحيح JoomlaWatch تحذير: القيمة التي أدخلتها ليست برقم صحيح، برنامج");
DEFINE('_JW_EVALUATION_LEFT',"&nbsp; هذه نسخة للتجربة مدتها 15 يوماً. الأيام الباقيةt: <b>%d</b>. برجاء شراء النسخة الدائمة <a href='http://www.codegravity.com/donate/joomlawatch/' target='_blank'>JoomlaWatch license for your domain</a> for this and upcoming versions.");
DEFINE('_JW_TRIAL_VERSION_EXPIRED',"JoomlaWatchنسخة التجربة الخاصة بك انتهت برجاء شراء برنامج");

DEFINE('_JW_CONFIG_LICENSE_ACTIVATED',"تم تفعيل الترخيص بنجاح، شكراً");
DEFINE('_JW_CONFIG_LICENCE_DONT_MATCH',"<b>Error: مفتاح الترخيص ومجالك لا يتطابقان.</b><br/>هل اسم المجال الذي أدخلته في وثيقة التبرع يطابق ذلك الذي تراه بأسفل؟ <br/>Click '<b>اطلب مفتاح التفعيل المناسب</b>' بأسفل أو اتصل بـ: info@codegravity.com<br/>");

DEFINE('_JW_VIEW_ADMINBODY_LONG_MESSAGE',"إذا كنت ترى الرسالة أعلاه لوقت أطول من اللازم فقد يكون موقعك الحالي غير صحيح
                    افتح العناصر/com_joomlawatch/config.php
                    أزل التعليق واضبط موقعك الحالي كالآتي على سبيل المثال:
                    define('JOOMLAWATCH_LIVE_SITE', 'http://www.codegravity.com');");

DEFINE('_JW_ADMINBODY_LIVE_SITE',"تحذير: الموقع الموجود في متصفحك وموقعك الحالي لا يتطابقان");
DEFINE('_JW_ADMINBODY_SET_LIVE_SITE',"اضبط الموقع الفوري على... ثم استمر إلى...");

DEFINE('_JW_ADMINHEADER_JW',"JoomlaWatch ");
DEFINE('_JW_ADMINHEADER_REMOVE_BACKLINK',"إزالة رابط العودة");
DEFINE('_JW_ADMINHEADER_KNOWLEDGE_BASE',"قاعدة معلوماتية");
DEFINE('_JW_ADMINHEADER_FLOW',"تدفق");
DEFINE('_JW_ADMINHEADER_GRAPHS',"رسوم بيانية");
DEFINE('_JW_ADMINHEADER_COMPONENTS',"المعناصر");
DEFINE('_JW_ADMINHEADER_REVIEW',"مراجعة");
DEFINE('_JW_ADMINHEADER_WRITE',"اكتب ");

DEFINE('_JW_FLOW_TRAFFIC',"تدفق الزيارات للموقع");
DEFINE('_JW_FLOW_SELECT_PAGE',"اختيار الصفحة:");
DEFINE('_JW_FLOW_OUTG_LINKS',"التعداد الجذري للروابط الصادرة:");
DEFINE('_JW_FLOW_NESTING',"مستوى التضمين:");
DEFINE('_JW_FLOW_SCALE',"مقياس:");

DEFINE('_JW_COMERCIAL_AD_FREE',"نسخة خالية من الإعلانات");
DEFINE('_JW_COMERCIAL_THANK_DONATION',"شكراً جزيلاً على تبرعك!");
DEFINE('_JW_COMERCIAL_REGISTRATION_KEY',"مفتاح تسجيل مجالك في: ");
DEFINE('_JW_COMERCIAL_BACKLINKS_REMOVE',"الآن يمكنك إزالة رابط العودة لموقعك أو إخفاء شعار جوملاواتش من البيانات الأمامية من خلال الإعدادت ");


DEFINE('_JW_SIZES_LAST_CHECK',"آخر تفتيش حدث في:");
DEFINE('_JW_SIZES_ADMINISTRATOR',"أزرق = حجم العنصر/الوحدة النمطية في/دليل المدراء");

DEFINE('_JW_SIZECOMPONENTS_COMPONENT',"عنصر أساسي");
DEFINE('_JW_SIZECOMPONENTS_TOTAL',"المجموع:");
DEFINE('_JW_SIZECOMPONENTS_SIZE',"حجم");
DEFINE('_JW_SIZECOMPONENTS_REFRESH_ALL',"تحديث الكل");

DEFINE('_JW_SIZEDATABASE_TABLE',"جدول");
DEFINE('_JW_SIZEDATABASE_SIZE',"حجم");
DEFINE('_JW_SIZEDATABASE_1DAY',"تغيير ليوم واحد");
DEFINE('_JW_SIZEDATABASE_7DAY',"تغيير لـ7 أيام");
DEFINE('_JW_SIZEDATABASE_28DAY',"تغيير لـ28 يوماً");
DEFINE('_JW_SIZEDATABASE_NO_DATA',"لا توجد بيانات");
DEFINE('_JW_SIZEDATABASE_TOTAL',"المجموع:");

DEFINE('_JW_SIZEMODULES_REFRESH_ALL',"تحديث الكل");
DEFINE('_JW_SIZEMODULES_TOTAL',"المجموع:");
DEFINE('_JW_SIZEMODULES_MODULE',"الوحدة النمطية");
DEFINE('_JW_SIZEMODULES_SIZE',"الحجم");

DEFINE('_JW_SIZES_FILES',"الملفات والدلائل");
DEFINE('_JW_SIZES_BYTES',"وحدات البايت");
DEFINE('_JW_SIZES_KB',"KB");
DEFINE('_JW_SIZES_MB',"MB");
DEFINE('_JW_SIZES_GB',"GB");
DEFINE('_JW_SIZES_REFRESH',"تحديث");

DEFINE('_JW_STATS_FOOTER',"JoomlaWatch &copy;2006-@YEAR@ by Matej Koval");

DEFINE('_JW_STATUS_MB',"MB");
DEFINE('_JW_STATUS_DATABASE',"أحجام جداول قاعدة البيانات");


DEFINE('_JW_DESC_IPINFODB_KEY',"خريطة الزيارة الأخيرة ipinfodb.com مفتاح من: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");
DEFINE('_JW_SETTINGS_FORCE_TIMEZONE_OFFSET',"فرض إزاحة المنطقة الزمنية");


/* JoomlaWatch 1.2.17 ترجمات */
DEFINE('_JW_MENU_UPDATE', "تحديث");
DEFINE('_JW_MENU_UPDATE_TITLE', "المساعدة والتحديث");
DEFINE('_JW_ADMINHEADER_NA_IN_THIS_VERSION',"هذا البرنامج غير متاح له نسخة مجانية برجاء الدخول لعلامة جدول الترخيص");
DEFINE('_JW_SPAMWORD_BANS_ENABLED', "تفعيل حظر كلمات الإحالات الغير مرغوبة");
DEFINE('_JW_SPAMWORD_LIST', "قائمة بكلمات الإحالات الغير مرغوبة");
DEFINE('_JW_HIDE_REPETITIVE_TITLE', "إخفاء العنوان المتكرر");
DEFINE('_JW_TRUNCATE_VISITS', "قطع الزيارات");
DEFINE('_JW_TRUNCATE_STATS', "قطع البيانات الإحصائية");
DEFINE('_JW_TRUNCATE_GOALS', "قطع الأهداف");
DEFINE('_JW_LIMIT_BOTS', "الحد من الروبوتات");
DEFINE('_JW_LIMIT_VISITORS', "الحد من الزائرين");
DEFINE('_JW_TOOLTIP_WIDTH', "عرض تعريف الأدوات");
DEFINE('_JW_TOOLTIP_HEIGHT', "ارتفاع تعريف الأدوات");
DEFINE('_JW_TOOLTIP_URL', " URLتعريف أدوات الـ");
DEFINE('_JW_TOOLTIP_ONCLICK', "تعريف الأدوات عند النقر");
DEFINE('_JW_IP_STATS', "بيانات إحصائية للعنوان الرقمي");
DEFINE('_JW_IPINFODB_KEY', "مفتاح قاعدة البيانات لمعلومات العنوان الرقمي ");
DEFINE('_JW_ONLY_LAST_URI', "الأخيرة فقط URI الـ");

DEFINE('_JW_FRONTEND_HIDE_LOGO', "إخفاء شعار البيانات الأمامية ");
DEFINE('_JW_FRONTEND_NOFOLLOW', "عدم اتباع البيانات الأمامية");
DEFINE('_JW_FRONTEND_NO_BACKLINK', "عدم وجود رابط عودة بالبيانات الأمامية");
DEFINE('_JW_FRONTEND_USER_LINK', "روابط مستخدمي البيانات الأمامية");
DEFINE('_JW_FRONTEND_COUNTRIES_FIRST', "دول البيانات الأمامية أولاً");
DEFINE('_JW_FRONTEND_COUNTRIES_NAMES', "أسماء دول البيانات الأمامية");
DEFINE('_JW_FRONTEND_COUNTRIES_UPPERCASE', "دول البيانات الأمامية بأعلى");
DEFINE('_JW_FRONTEND_COUNTRIES_FLAGS_FIRST', "أعلام دول البيانات الأمامية تأتي أولاً ");
DEFINE('_JW_FRONTEND_COUNTRIES_NUM', "إقفال لوحة الأرقام لدول البيانات الأمامية");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_COLUMNS', "أقصى عدد عواميد لدول البيانات الأمامية");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_ROWS', "أقصى عدد صفوف لدول البيانات الأمامية");
DEFINE('_JW_FRONTEND_VISITORS_TODAY', "زوار البيانات الأمامية اليوم ");
DEFINE('_JW_FRONTEND_VISITORS_YESTERDAY', "زوار البيانات الأمامية أمس ");
DEFINE('_JW_FRONTEND_VISITORS_THIS_WEEK', "زوار البيانات الأمامية هذا الأسبوع ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_WEEK', "زوار البيانات الأمامية الأسبوع الماضي ");

DEFINE('_JW_FRONTEND_VISITORS_THIS_MONTH', "زوار البيانات الأمامية هذا الشهر ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_MONTH', "وار البيانات الأمامية الشهر الماضي");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL', "إخفاء عدد زوار البيانات الأمامية الكلي");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL	', "واجهة أمامية وكلية");
DEFINE('_JW_HISTORY_MAX_VALUES', "أقصى قوائم للمحفوظات");
DEFINE('_JW_HISTORY_MAX_DB_RECORDS', "أقصى عدد لسجلات المحفوظات");
DEFINE('_JW_UPDATE_TIME_VISITS', "زيارات تحديث الوقت");
DEFINE('_JW_UPDATE_TIME_STATS', "تحديث وقت البيانات الإحصائية");
DEFINE('_JW_STATS_MAX_ROWS', "أقصى عدد لصفوف البيانات الإحصائية");
DEFINE('_JW_STATS_IP_HITS', "عدد زيارات العنوان الرقمي بالبيانات الإحصائية");
DEFINE('_JW_MAXID_BOTS', "أقصى عدد للروبوتات ذوي التعريفات");
DEFINE('_JW_MAXID_VISITORS', "أقصى عدد للزائرين ذوي التعريفات");
DEFINE('_JW_STATS_KEEP_DAYS', "أيام الاحتفاظ بالبيانات الإحصائية ");
DEFINE('_JW_CACHE_FRONTEND_COUNTRIES', "ذاكرة تخزين مؤقت لدول البيانات الأمامية ");
DEFINE('_JW_CACHE_FRONTEND_VISITORS', "ذاكرة تخزين مؤقت لزوار البيانات الأمامية ");

DEFINE('_JW_UNINSTALL_KEEP_DATA	', "إلغاء تثبيت خفظ البيانات ");
DEFINE('_JW_IGNORE_IP', "تجاهل العنوان الرقمي");
DEFINE('_JW_IGNORE_URI', " URIتجاهل الـ");
DEFINE('_JW_IGNORE_USER', "تجاهل المستخدم");
DEFINE('_JW_BLOCKING_MESSAGE', "رسالة منع");
DEFINE('_JW_SERVER_URI_KEY', "للملقم URI مفتاح");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL', "التمهيد الكلي لزوار البيانات الأمامية");
DEFINE('_JW_SIZEDATABASE_RECORDS', "سجلات");
/***********EDITs******************/
DEFINE('_JW_ANTISPAM_BLOCKING_TEXT'," قبل أي محتوى أو صيخة وعلى سبيل المثال على يسار القالب الخاص بك JoomlaWatch لتفعيل هذا المنع عليك أن تنشر وكيل 
                    <br/>
                    الذهاب إلى إدارة الوحدة النمطية -> JoomlaWatch وكيل -> اختيار المكان على اليسار");

DEFINE('_JW_EMAIL_SEO_REPORTS', "تقارير رئيس مجلي الإدارة");
DEFINE('_JW_DESC_EMAIL_SEO_REPORTS_ENABLED',"تم تفعيل بريد التقارير المرسلة لرئيس مجلي الإدارة ليلياً");
DEFINE('_JW_WATCH_INSTALLATION_DEMO',"مشاهدة العرض التوضيحي للتثبيت");

?>