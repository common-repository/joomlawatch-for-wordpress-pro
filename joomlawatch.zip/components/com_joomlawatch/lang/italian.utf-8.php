<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version @VERSION@
 * @revision @REVISION@
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) @YEAR@ by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/
defined( '_JEXEC' ) or die( 'Restricted access' );

#JoomlaWatch language file - to create a new language file, just copy the english.php to eg. german.php and place into /components/com_joomlawatch/lang/

# Main Menu
DEFINE('_JW_MENU_STATS', "Statistiche");
DEFINE('_JW_MENU_GOALS', "Obiettivi");
DEFINE('_JW_MENU_SETTINGS', "Opzioni");
DEFINE('_JW_MENU_CREDITS', "Riconoscimenti");
DEFINE('_JW_MENU_FAQ', "FAQ");
DEFINE('_JW_MENU_DOCUMENTATION', "Documentazione");
DEFINE('_JW_MENU_LICENSE', "Licenza PRO");
DEFINE('_JW_MENU_DONATORS', "Donazioni");
DEFINE('_JW_MENU_SUPPORT', "Supporta JoomlaWatch per eliminare le pubblicit&agrave;  nel Backend.");

# Left visitors real-time window
DEFINE('_JW_VISITS_VISITORS', "Ultimi visitatori");
DEFINE('_JW_VISITS_BOTS', "Bot");
DEFINE('_JW_VISITS_CAME_FROM', "Provenienza");
DEFINE('_JW_VISITS_MODULE_NOT_PUBLISHED', "Non hai pubblicato il modulo JoomlaWatch, quindi non viene registrata alcuna statistica! Vai nella sezione Moduli e pubblicalo su tutte le pagine");
DEFINE('_JW_VISITS_PANE_LOADING', "Carico le visite...");

# Right stats window
DEFINE('_JW_STATS_TITLE', "Statistiche della settimana");
DEFINE('_JW_STATS_WEEK', "Settimana");
DEFINE('_JW_STATS_THIS_WEEK', "questa settimana");
DEFINE('_JW_STATS_UNIQUE', "visitatori");
DEFINE('_JW_STATS_LOADS', "accessi");
DEFINE('_JW_STATS_HITS', "clic");
DEFINE('_JW_STATS_TODAY', "oggi");
DEFINE('_JW_STATS_FOR', "del");
DEFINE('_JW_STATS_ALL_TIME', "Statistiche globali");
DEFINE('_JW_STATS_EXPAND', "espandi");
DEFINE('_JW_STATS_COLLAPSE', "restringi");
DEFINE('_JW_STATS_URI', "Pagine");
DEFINE('_JW_STATS_COUNTRY', "Nazioni");
DEFINE('_JW_STATS_USERS', "Visitatori");
DEFINE('_JW_STATS_REFERERS', "Provenienza");
DEFINE('_JW_STATS_IP', "IP");
DEFINE('_JW_STATS_BROWSER', "Browser");
DEFINE('_JW_STATS_OS', "S.O.");
DEFINE('_JW_STATS_KEYWORDS', "Parole chiave");
DEFINE('_JW_STATS_GOALS', "Obiettivi");
DEFINE('_JW_STATS_TOTAL', "Totali");
DEFINE('_JW_STATS_DAILY', "Statistiche di oggi");
DEFINE('_JW_STATS_DAILY_TITLE', "Statistiche del");
DEFINE('_JW_STATS_ALL_TIME_TITLE', "Statistiche globali");
DEFINE('_JW_STATS_LOADING', "Carico...");
DEFINE('_JW_STATS_LOADING_WAIT', "carico... attendi");
DEFINE('_JW_STATS_IP_BLOCKING_TITLE', "Blocco IP");
DEFINE('_JW_STATS_IP_BLOCKING_ENTER', "Inserisci IP manualmente");
DEFINE('_JW_STATS_IP_BLOCKING_MANUALLY', "Inserisci l'IP che vuoi bloccare. (es. 217.242.11.54 o 217.* o 217.242.* per bloccare tutti gli IP con il carattere jolly)");
DEFINE('_JW_STATS_IP_BLOCKING_TOGGLE', "Vuoi davvero bloccare/sbloccare ");
DEFINE('_JW_STATS_PANE_LOADING', "Carico le statistiche...");

# Settings
DEFINE('_JW_SETTINGS_TITLE', "Opzioni");
DEFINE('_JW_SETTINGS_DEFAULT', "Impostazione predefinita");
DEFINE('_JW_SETTINGS_SAVE', "Salva");
DEFINE('_JW_SETTINGS_APPEARANCE', "Aspetto");
DEFINE('_JW_SETTINGS_FRONTEND', "Frontend");
DEFINE('_JW_SETTINGS_HISTORY_PERFORMANCE', "Storia &amp; prestazioni");
DEFINE('_JW_SETTINGS_ADVANCED', "Avanzate");
DEFINE('_JW_SETTINGS_IGNORE', "Ignora");
DEFINE('_JW_SETTINGS_BLOCKING', "Blocca");
DEFINE('_JW_SETTINGS_EXPERT', "Modalit&agrave;  Esperto");
DEFINE('_JW_SETTINGS_RESET_CONFIRM', "Vuoi davvero azzerare tutte le statistiche e i dati dei visitatori?");
DEFINE('_JW_SETTINGS_RESET_ALL', "Azzera tutto");
DEFINE('_JW_SETTINGS_RESET_ALL_LINK', "Azzera tutte le statistiche e i dati dei visitatori");
DEFINE('_JW_SETTINGS_LANGUAGE', "Lingua");
DEFINE('_JW_SETTINGS_SAVED', "Impostazioni salvate");
DEFINE('_JW_SETTINGS_ADD_YOUR_IP', "Aggiungi il tuo IP");
DEFINE('_JW_SETTINGS_TO_THE_LIST', "all'elenco.");

# Other / mostly general
DEFINE('_JW_TITLE', "Monitor AJAX in tempo reale per Joomla");
DEFINE('_JW_BACK', "Indietro");
DEFINE('_JW_ACCESS_DENIED', "Non hai i permessi per visualizzare!");
DEFINE('_JW_LICENSE_AGREE', "Accetto i termini e le &amp; condizioni");
DEFINE('_JW_LICENSE_CONTINUE', "Continua");
DEFINE('_JW_SUCCESS', "Operazione compiuta");
DEFINE('_JW_RESET_SUCCESS', "Tutte le statistiche e i dati sui visitatori sono state cancellate");
DEFINE('_JW_RESET_ERROR', "Si &egrave; verificato un problema e i dati NON sono stati cancellati.");
DEFINE('_JW_CREDITS_TITLE', "Riconoscimenti");
DEFINE('_JW_TRENDS_DAILY_WEEKLY', "Statistiche giornaliere e settimanali di");
DEFINE('_JW_AJAX_PERMISSION_DENIED_1', "Permesso AJAX negato: visualizza le statistiche nel dominio specificato nel file configuration.php di Joomla - ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_2', "Forse hai dimenticato di digitare www. prima del nome di dominio. Javascript sta tentando di accedere ");
DEFINE('_JW_AJAX_PERMISSION_DENIED_3', "da");
DEFINE('_JW_AJAX_PERMISSION_DENIED_4', "ci&ograve; che gli fa pensare che si tratti di un dominio differente.");

# Header
DEFINE('_JW_HEADER_DOWNLOAD', "Scarica l'ultima versione da");
DEFINE('_JW_HEADER_CAST_YOUR', "Invia il tuo");
DEFINE('_JW_HEADER_VOTE', "Voto");

# Tooltips
DEFINE('_JW_TOOLTIP_CLICK', "Clicca per visualizzare il messaggio");
DEFINE('_JW_TOOLTIP_MOUSE_OVER', "Passa sopra con il mouse per visualizzare il messaggio");
DEFINE('_JW_TOOLTIP_YESTERDAY_INCREASE', "rispetto a ieri");
DEFINE('_JW_TOOLTIP_HELP', "Accede alla guida online per");
DEFINE('_JW_TOOLTIP_WINDOW_CLOSE', "Chiudi");
DEFINE('_JW_TOOLTIP_PRINT', "Stampa");

# Goals
DEFINE('_JW_GOALS_INSERT', "Nuovo obiettivo");
DEFINE('_JW_GOALS_UPDATE', "Aggiorna l'obiettivo ");
DEFINE('_JW_GOALS_ACTION', "Azione");
DEFINE('_JW_GOALS_TITLE', "Nuovo obiettivo");
DEFINE('_JW_GOALS_NEW', "Nuovo obiettivo");
DEFINE('_JW_GOALS_RELOAD', "Ricarica");
DEFINE('_JW_GOALS_ADVANCED', "Avanzato");
DEFINE('_JW_GOALS_NAME', "Nome");
DEFINE('_JW_GOALS_ID', "id");
DEFINE('_JW_GOALS_URI_CONDITION', "Condizione URI");
DEFINE('_JW_GOALS_GET_VAR', "Variabile GET");
DEFINE('_JW_GOALS_GET_CONDITION', "Condizione GET");
DEFINE('_JW_GOALS_POST_VAR', "Variabile POST");
DEFINE('_JW_GOALS_POST_CONDITION', "Condizione POST");
DEFINE('_JW_GOALS_TITLE_CONDITION', "Condizione TITLE");
DEFINE('_JW_GOALS_USERNAME_CONDITION', "Condizione USERNAME");
DEFINE('_JW_GOALS_IP_CONDITION', "Condizione IP");
DEFINE('_JW_GOALS_CAME_FROM_CONDITION', "Condizione FROM");
DEFINE('_JW_GOALS_BLOCK', "Blocca");
DEFINE('_JW_GOALS_REDIRECT', "Reindirizza all'URL");
DEFINE('_JW_GOALS_HITS', "Clic");
DEFINE('_JW_GOALS_ENABLED', "Attivo");
DEFINE('_JW_GOALS_EDIT', "Modifica");
DEFINE('_JW_GOALS_DELETE', "Cancella");
DEFINE('_JW_GOALS_DELETE_CONFIRM', "Perderai tutte le statistiche recenti per questo obiettivo. Vuoi eliminarlo davvero?");

# Frontend
DEFINE('_JW_FRONTEND_COUNTRIES', "Nazione di provenienza");
DEFINE('_JW_FRONTEND_VISITORS', "Numero di visitatori");
DEFINE('_JW_FRONTEND_TODAY', "Oggi");
DEFINE('_JW_FRONTEND_YESTERDAY', "Ieri");
DEFINE('_JW_FRONTEND_THIS_WEEK', "Questa settimana");
DEFINE('_JW_FRONTEND_LAST_WEEK', "Scorsa settimana");
DEFINE('_JW_FRONTEND_THIS_MONTH', "Questo mese");
DEFINE('_JW_FRONTEND_LAST_MONTH', "Scorso mese");
DEFINE('_JW_FRONTEND_TOTAL', "Totale");

# Settings description - quite long
DEFINE('_JW_DESC_DEBUG', "JoomlaWatch &egrave; in modalit&agrave;  debug. In questo modo puoi scoprire le cause degli errori. Per disattivarla, modifica la voce JOOMLAWATCH_DEBUG in /components/com_joomlawatch/config.php da 1 a 0");
DEFINE('_JW_DESC_STATS_MAX_ROWS', "Numero massimo di righe da mostrare quando espandi le statistiche.");
DEFINE('_JW_DESC_STATS_IP_HITS', "Tutti gli indirizzi IP che nei giorni passati hanno effettuato un numero di clic minore di questo numero saranno cancellati dalla cronologia degli IP.");
DEFINE('_JW_DESC_STATS_URL_HITS', "Tutti gli URL che nei giorni passati hanno effettuato un numero di clic minore di questo numero saranno cancellati dalla cronologia degli IP.");
DEFINE('_JW_DESC_IGNORE_IP', "Escludi alcuni indirizzi IP dalle statistiche, separandoli andando a capo. Puoi usare i caratteri jolly. <br/>Es. 192.* ignorer&agrave;  192.168.51.31, 192.168.16.2, ecc..");
DEFINE('_JW_DESC_UPDATE_TIME_VISITS', "Tempo di aggiornamento dei visitatori (in millisecondi). L'impostazione predefinita &egrave; 2000. Si raccomanda particolare cautela nel modificare questo valore. Al termine, ricarica il Backend di JoomlaWatch.");
DEFINE('_JW_DESC_UPDATE_TIME_STATS', "Tempo di aggiornamento delle statistiche (in millisecondi). L'impostazione predefinita &egrave; 4000. Si raccomanda particolare cautela nel modificare questo valore. Al termine, ricarica il Backend di JoomlaWatch.");
DEFINE('_JW_DESC_MAXID_BOTS', "Quante visite dei bot vuoi mantenere nel database.");
DEFINE('_JW_DESC_MAXID_VISITORS', "Quante visite reali vuoi mantenere nel database.");
DEFINE('_JW_DESC_LIMIT_BOTS', "Quanti bot vuoi visualizzare nel Backend.");
DEFINE('_JW_DESC_LIMIT_VISITORS', "Quanti visitatori reali vuoi visualizzare nel Backend.");
DEFINE('_JW_DESC_TRUNCATE_VISITS', "Numero massimo di caratteri da visualizzare nei titoli e negli URI lunghi.");
DEFINE('_JW_DESC_TRUNCATE_STATS', "Numero massimo di caratteri da visualizzare nel pannello delle statistiche a destra.");
DEFINE('_JW_DESC_STATS_KEEP_DAYS', "Per quanti giorni vuoi mantenere le statistiche nel database. 0 = per sempre.");
DEFINE('_JW_DESC_TIMEZONE_OFFSET', "Se il tuo fuso orario &egrave; diverso da quello del server che ospita il sito (imposta un valore positivo o negativo in ore).");
DEFINE('_JW_DESC_WEEK_OFFSET', "Compensazione della settimana. Il calendario/(3600*24*7) parte dal 1.1.1970. Con questa compensazione, puoi far partire la settimana dal lunedÃ¬.");
DEFINE('_JW_DESC_DAY_OFFSET', "Compensazione del giorno. Il calendario/(3600*24) parte dal 1.1.1970. Con questa compensazione, puoi far partire la giornata alle 00:00.");
DEFINE('_JW_DESC_FRONTEND_HIDE_LOGO', "Usa un'icona vuota (1x1 px) nel Frontend");
DEFINE('_JW_DESC_IP_STATS', "Abilita le statistiche sugli indirizzi IP. In alcune nazioni, la legge proibisce di mantenere gli IP in un database per un tempo maggiore di quello consentito. Utilizza questa opzione a tuo rischio e pericolo.");
DEFINE('_JW_DESC_HIDE_ADS', "Questa opzione nasconde le pubblicit&agrave;  nel Backend, nel caso ti infastidiscano. Mantenendole, supporti il futuro sviluppo di questo componente. Grazie.");
DEFINE('_JW_DESC_TOOLTIP_ONCLICK', "Togli il segno di spunta se vuoi visualizzare i messaggi quando passi il mouse sopra un'opzione, invece di cliccarci.");
DEFINE('_JW_DESC_SERVER_URI_KEY', "L'impostazione predefinita &egrave; 'REDIRECT_URL', che &egrave; consigliabile se utilizzi la riscrittura delle URL. Se &egrave; collegata esclusivamente alla pagina index.php, puoi usare 'SCRIPT_URL'.");
DEFINE('_JW_DESC_BLOCKING_MESSAGE', "Messaggio visualizzato per bloccare un utente o per fornire ulteriori informazioni sul blocco.");
DEFINE('_JW_DESC_TOOLTIP_WIDTH', "Larghezza messaggi");
DEFINE('_JW_DESC_TOOLTIP_HEIGHT', "Altezza messaggi");
DEFINE('_JW_DESC_TOOLTIP_URL', "Qui puoi inserire una URL qualsiasi per visualizzare l'indirizzo IP del visitatore. {ip} sar&agrave; sostituito dall'indirizzo IP del visitatore. Es. http://somewebsite.com/query?iplookup={ip}");
DEFINE('_JW_DESC_IGNORE_URI', "Qui puoi inserire una URL qualsiasi da ignorare nelle statistiche. Puoi usare i caratteri jolly * e ?. Es.: /freel?n* ");
DEFINE('_JW_DESC_GOALS_NAME', "Specifica un nome per visualizzare l'obiettivo nelle statistiche.");
DEFINE('_JW_DESC_GOALS_URI_CONDITION', "Tutto ci&ograve; che viene dopo il tuo nome di dominio. Per http://www.codegravity.com/projects/ l'URI &egrave;: /projects/ (Esempio: <b>/projects*</b>)");
DEFINE('_JW_DESC_GOALS_GET_VAR', "Puoi trovare la variabile GET nell'indirizzo URL, solitamente dopo un ? o &amp;. Es. http://www.codegravity.com/index.php?<u>name</u>=peter&amp;<u>surname</u>=smith. Puoi usare <u>*</u> in questo capo per esaminare tutti i valori della variabile GET. (Esempio: <b>n*me</b>)");
DEFINE('_JW_DESC_GOALS_GET_CONDITION', "Il valore per il campo precedente. (Esempio: <b>p?t*r</b>) ");
DEFINE('_JW_DESC_GOALS_POST_VAR', "Molto simile al precedente, ma qui cerchiamo i valori inseriti nei form. Quindi, se hai un form sul tuo sito, ha un campo &lt;input type='text' name='<u>experiences</u>' /&gt;. (Esempio: <b>exper*ces</b>)");
DEFINE('_JW_DESC_GOALS_POST_CONDITION', "Il valore per il campo POST. Per esempio se vuoi controllare se l'utente ha usato java. (Esempio: <b>*java*</b>)");
DEFINE('_JW_DESC_GOALS_TITLE_CONDITION', "Il titolo di una pagina. (Esempio: <b>*freelance programmers*</b>)");
DEFINE('_JW_DESC_GOALS_USERNAME_CONDITION', "Il nome di un utente che ha effettuato l'accesso. (Esempio: <b>psmith*</b>)");
DEFINE('_JW_DESC_GOALS_IP_CONDITION', "L'indirizzo IP di un utente. (Esempio: <b>201.9?.*.*</b>)");
DEFINE('_JW_DESC_GOALS_CAME_FROM_CONDITION', "L'URL da cui proviene l'utente. (Esempio: <b>*www.google.*</b>)");
DEFINE('_JW_DESC_GOALS_REDIRECT', "L'utente viene reindirizzato su un URL specificata da te. Questa funzione ha una priorit&agrave; maggiore rispetto al blocco. (Esempio: <b>http://www.codegravity.com/goaway.html</b>)");
DEFINE('_JW_DESC_TRUNCATE_GOALS', "Quanti caratteri visualizzare nella tabella degli obiettivi.");
DEFINE('_JW_DESC_FRONTEND_NO_BACKLINK', "Collegamento a codegravity.com. Puoi disattivarlo, ma ti saremmo grati se lo lasciassi attivo. Grazie.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES', "Mostra le statistiche globali per le nazioni nel modulo del Frontend. Se cambi questa impostazione, sar&agrave; visibile nel Frontend dopo aver impostato il tempo in CACHE_FRONTEND_ ");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FIRST', "Inverti l'ordine di visualizzazione Visitatori/Nazioni nel Frontend. Se togli il segno di spunta, i Visitatori appariranno per primi.");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NUM', "Numero di nazioni da visualizzare nel Frontend");
DEFINE('_JW_DESC_FRONTEND_VISITORS', "Mostra il numero di visitatori per ogni nazione nel modulo del Frontend. Se cambi questa impostazione, sar&agrave; visibile nel Frontend dopo aver impostato il tempo in CACHE_FRONTEND_");
DEFINE('_JW_DESC_CACHE_FRONTEND_COUNTRIES', "Tempo in secondi per il fetching della cache del numero di visitatori per nazione nel modulo del Frontend");
DEFINE('_JW_DESC_CACHE_FRONTEND_VISITORS', "Tempo in secondi per il fetching della cache del numero di visitatori nel modulo del Frontend");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TODAY', "Mostra i visitatori di oggi nel Frontend. Se cambi questa impostazione, sar&agrave; visibile nel Frontend dopo aver impostato il tempo in CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_YESTERDAY', "Mostra i visitatori di ieri nel Frontend. Se cambi questa impostazione, sar&agrave; visibile nel Frontend dopo aver impostato il tempo in CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_WEEK', "Mostra i visitatori della settimana in corso nel Frontend. Se cambi questa impostazione, sar&agrave; visibile nel Frontend dopo aver impostato il tempo in CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_WEEK', "Mostra i visitatori della settimana scorsa nel Frontend. Se cambi questa impostazione, sar&agrave; visibile nel Frontend dopo aver impostato il tempo in CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_THIS_MONTH', "Mostra i visitatori del mese in corso nel Frontend. Se cambi questa impostazione, sar&agrave; visibile nel Frontend dopo aver impostato il tempo in CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_LAST_MONTH', "Mostra i visitatori del mese scorso nel Frontend. Se cambi questa impostazione, sar&agrave; visibile nel Frontend dopo aver impostato il tempo in CACHE_FRONTEND_...");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL', "Visualizza il numero totale di visitatori da quando hai installato JoomlaWatch. Se cambi questa impostazione, sar&agrave; visibile nel Frontend dopo aver impostato il tempo in CACHE_FRONTEND_...");
DEFINE('_JW_DESC_LANGUAGE', "File della lingua da utilizzare. I file della lingua si trovano in /components/com_joomlawatch/lang/. Se vuoi crearne uno nuovo, copia quello predefinito (english.php), rinominalo (per es. italian.php) e posizionalo in questa directory. Quindi, traduci tutti i valori chiave sulla destra.");
DEFINE('_JW_DESC_GOALS', "Gli obiettivi ti permettono di impostare dei parametri specifici. Quando questi parametri si verificano, il contatore degli obiettivi aumenta. In questo modo, puoi verificare se un utente ha visitato un'URL specifica, se ha inviato un determinato valore, se &egrave; associato a un nome utente particolare o proviene da un certo indirizzo. Puoi anche bloccare alcuni utenti o reindirizzarli verso altre URL.");
DEFINE('_JW_DESC_GOALS_INSERT', "Puoi usare i caratteri jolly * e ? in tutti i campi, tranne quello del nome. Per esempio: ?ear per near, tear, ecc. oppure p*r per pr, peer, pear, ecc.");
DEFINE('_JW_DESC_GOALS_BLOCK', "Impostalo su 1 se vuoi bloccare il visitatore e impedirgli di visualizzare il resto del sito a parte un avviso del blocco (senza reindirizzamento). Il suo IP verr&agrave; aggiunto alle statistiche degli IP bloccati. (Esempio: <b>1</b>)");

/* new translations */
DEFINE('_JW_GOALS_COUNTRY_CONDITION', "Condizione COUNTRY");
DEFINE('_JW_DESC_GOALS_COUNTRY_CONDITION', "Codice maiuscolo di 2 lettere per la nazione (Es: <b>IT</b>)");
DEFINE('_JW_STATS_INTERNAL',"Collegamenti interni");
DEFINE('_JW_STATS_FROM',"Da");
DEFINE('_JW_STATS_TO',"A");
DEFINE('_JW_STATS_ADD_TO_GOALS',"Aggiungi agli obiettivi");
DEFINE('_JW_VISITS_ADD_GOAL_COUNTRY',"Aggiungi un obiettivo per questa nazione");
DEFINE('_JW_MENU_REPORT_BUG',"Segnala bug");
DEFINE('_JW_GOALS_COUNTRY',"Nazione");


/* translations 1.2.8b_12 */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_UPPERCASE',"Se vuoi i nomi delle nazioni in maiuscolo nel Frontend (Es: GERMANY, UNITED KINGDOM invece di Germany, United Kingdom)");
DEFINE('_JW_DESC_CACHE_FRONTEND_USERS',"Tempo in secondi per il fetching della cache degli utenti nel Frontend");
DEFINE('_JW_DESC_FRONTEND_VISITORS_TOTAL_INITIAL', "Valore iniziale del contatore Totale del Frontend. Utile se stai effettuando una migrazione da un altro strumento per le statistiche. (Es.: 20000). Se non vuoi sfruttare questa funzione, reimposta il valore a 0.");
DEFINE('_JW_DESC_IGNORE_USER', "Ignora gli utenti elencati in questa casella di testo. Inseriscili uno per linea. (Es.: io {line break} mark_*) ");
DEFINE('_JW_FRONTEND_USERS_MOST', "Gli utenti pi&ugrave; attivi di oggi su un totale di");
DEFINE('_JW_DESC_SPAMWORD_BANS_ENABLED',"Abilitare il ban in base alle parole elencate qui sotto?");
DEFINE('_JW_DESC_SPAMWORD_LIST',"Le parole chiave pi&ugrave; comuni utilizzate dagli spambot. Puoi usare i caratteri jolly (Es.: ph?rmac*). Se l'opzione qui sopra &egrave; attivata, JoomlaWatch monitorer&agrave; ogni inserimento di queste parole in un form sul tuo sito (la richiesta HTTP POST). Progettato per i form creati con Joomla: forum, commenti, ecc. In ogni caso, &egrave; molto efficace contro gli spambot che tentino di inviare messaggi in qualsiasi tipo di form)");
DEFINE('_JW_SETTINGS_ANTI_SPAM',"Anti-Spam");
DEFINE('_JW_DESC_FRONTEND_USER_LINK',"Un collegamento nel modulo Utenti del Frontend. Ti permette di specificare un'URL, che si apre quando l'utente clicca sul suo nome. Deve contenere il valore {user}, che sar&agrave; sostituito dal vero nome utente. (Es. index.php?option=com_comprofiler&task=userProfile&user={user}) ");

/* translations 1.2.11b */
DEFINE('_JW_STATS_KEYPHRASE', "Frasi chiave");
DEFINE('_JW_DESC_HISTORY_MAX_VALUES', "Valore massimo nella cronologia (Esempio: <i>100</i>)");

DEFINE('_JW_DESC_ONLY_LAST_URI', "In Visite mostra solo l'ultima pagina visitata, non tutte");
DEFINE('_JW_DESC_HIDE_REPETITIVE_TITLE', "In Visite nascondi il nome del sito, se ripetuto nel titolo delle pagine visitate");
DEFINE('_JW_DESC_HISTORY_MAX_DB_RECORDS', "Numero massimo di visitatori da mantenere nel database per la Cronologia Visite. Prestare attenzione con questa impostazione, se hai un sito con molto traffico il database pu&ograve; ingrandirsi molto in fretta. Verificare sempre la dimensione dei dati contenuti nelle tabelle della cronologia (history) nello Status");
DEFINE('_JW_DESC_UNINSTALL_KEEP_DATA', "Mantenere le tabelle del database in caso di disinstallazione. Selezionare questa opzione prima della disinstallazione se si sta effettuando un aggiornamento e si desidera mantenere i dati.");

/* email reports */
DEFINE('_JW_DESC_EMAIL_REPORTS_ENABLED', "Riceverai una mail nella notte contenente i report del giorno precedente. Potrai leggerla la mattina");
DEFINE('_JW_DESC_EMAIL_REPORTS_ADDRESS', "Indirizzo E-Mail al quale si desidera ricevere questi reports");
DEFINE('_JW_DESC_EMAIL_PERCENT_HIGHER_THAN', "Inserire nel report via mail solo righe dove la percentuale &egrave; maggiore di {value}. Impostare a 0 se non si desidera utilizzare questa funzione <i>(esempio: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_POSITIVE', "Inserire nel report via mail solo valori cambiati <b>positivamente in 1 giorno</b> maggiori di {value}%. Impostare a 0 se non si desidera utilizzare questa funzione <i>(esempio: 5)</i>");
DEFINE('_JW_DESC_EMAIL_ONE_DAY_CHANGE_NEGATIVE', "Inserire nel report via mail solo valori cambiati <b>negativamente in 1 giorno</b> minori di {value}%. Impostare a 0 se non si desidera utilizzare questa funzione <i>(esempio: -10)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_POSITIVE', "Inserire nel report via mail solo valori cambiati <b>positivamente in 7 giorni</b> maggiori di {value}%. Impostare a 0 se non si desidera utilizzare questa funzione <i>(esempio: 2)</i>");
DEFINE('_JW_DESC_EMAIL_SEVEN_DAY_CHANGE_NEGATIVE', "Inserire nel report via mail solo valori cambiati <b>negativamente in 7 giorni</b> minori di {value}%. Impostare a 0 se non si desidera utilizzare questa funzione <i>(esempio: -13)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_POSITIVE', "Inserire nel report via mail solo valori cambiati <b>positivamente in 30 giorni</b> maggiori di {value}%. Impostare a 0 se non si desidera utilizzare questa funzione <i>(esempio: 2)</i>");
DEFINE('_JW_DESC_EMAIL_TWENTY_EIGHT_DAY_CHANGE_NEGATIVE', "Inserire nel report via mail solo valori cambiati <b>negativamente in 30 giorni</b> minori di {value}%. Impostare a 0 se non si desidera utilizzare questa funzione <i>(esempio: -13)</i>");

DEFINE('_JW_DESC_FRONTEND_NOFOLLOW', "<b>(attivo nella versione PRO)</b> Attivare questa impostazione se si desidera impostare l'attributo rel='nofollow' al collegamento del logo ");
DEFINE('_JW_DESC_EMAIL_NAME_TRUNCATE', "Max. caratteri della riga del nome mail. Modificarlo se la finestra del mesagio email &egrave; troppo piccola");

DEFINE('_JW_MENU_HISTORY', "Cronologia");
DEFINE('_JW_MENU_EMAILS', "Emails");
DEFINE('_JW_MENU_STATUS', "Status");
DEFINE('_JW_DESC_BLOCKED',"Questi IP sono stati bloccati dall'anti-spam");


DEFINE('_JW_HISTORY_VISITORS',"Cronologia visitatori");
DEFINE('_JW_HISTORY_SHOWING_ONLY', "Mostra solo i %d ultimi dati.
                Per modificare questa impostazione vai a Impostazioni -&gt; Cronologia &amp; Prestazioni -&gt; HISTORY_MAX_DB_RECORDS . Attenzione, questa impostazione pu&ograve; influenzare i tempi di caricamento dei dati sottostanti.  ");
DEFINE('_JW_MENU_BUG', "Segnala un malfunzionamento");
DEFINE('_JW_MENU_FEATURE', "Richiedi altre funzioni");

DEFINE('_JW_VISITS_CAME_FROM_KEYWORDS',"Parole chiave");

DEFINE('_JW_BLOCKING_UNBLOCK',"sblocca");
DEFINE('_JW_STATS_KEYPHRASE ',"Frasi chiave");
DEFINE('_JW_STATUS_DATABASE',"Status del database");

DEFINE('_JW_STATUS_DATABASE_TABLE_NAME',"nome tabella");
DEFINE('_JW_STATUS_DATABASE_ROWS',"righe");
DEFINE('_JW_STATUS_DATABASE_DATA',"dati");
DEFINE('_JW_STATUS_DATABASE_TOTAL',"totale");

DEFINE('_JW_EMAIL_REPORTS',"Report via mail");
DEFINE('_JW_EMAIL_REPORT_GENERATED',"Generato un report via mail da ieri, filtrato");
DEFINE('_JW_EMAIL_REPORTS_VALUE_FILTERS',"Valori dei filtri mail");
DEFINE('_JW_EMAIL_REPORTS_VALUE',"valore");
DEFINE('_JW_EMAIL_REPORTS_PERCENT',"percentuale");
DEFINE('_JW_EMAIL_REPORTS_1DAY_CHANGE',"modifica a 1 giorno");
DEFINE('_JW_EMAIL_REPORTS_7DAY_CHANGE',"modifica a 7 giorni");
DEFINE('_JW_EMAIL_REPORTS_28DAY_CHANGE',"modifica a 28 giorni");
DEFINE('_JW_ANTISPAM_BLOCKED',"JoomlaWatch ha bloccato %d contatti da spammer oggi, totale: %d");
DEFINE('_JW_ANTISPAM_ADDRESSES',"Indirizzi IP bloccati");
DEFINE('_JW_ANTISPAM_SETTINGS',"Impostazioni Anti-Spam");
DEFINE('_JW_TRAFFIC_AJAX',"Aggiornamenti traffico AJAX");


DEFINE('_JW_HISTORY_PREVIOUS',"precedente");
DEFINE('_JW_HISTORY_NEXT',"successivo");

/** additional translation for 1.2.11 for countries in more rows */
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_COLUMNS',"Numero di colonne di paesi");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_MAX_ROWS',"Numero di righe di paesi");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_NAMES',"Mostra/Non Mostrare il nome del paese");
DEFINE('_JW_DESC_FRONTEND_COUNTRIES_FLAGS_FIRST',"Mostra prima le bandiere, poi le percentuali");

/* JoomlaWatch 1.2.14 translations */

DEFINE('_JW_GOALS_GET_INVERSED', "Condizione GET inversa");
DEFINE('_JW_GOALS_POST_INVERSED', "Condizione POST inversa");
DEFINE('_JW_GOALS_TITLE_INVERSED', "Condizione del Titolo inversa");
DEFINE('_JW_GOALS_USERNAME_INVERSED', "Condizione Nome Utente inversa");
DEFINE('_JW_GOALS_CAME_FROM_INVERSED', "Condizone Proviene da inversa");

DEFINE('_JW_STATS_MAP', "Mappa delle ultime visite");
DEFINE('_JW_STATS_MAP_ENTER_KEY',"Inserire la chiave d'accesso di <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a> per visualizzare la mappa delle ultime visite:");
DEFINE('_JW_STATS_MAP_STORE_KEY',"salva la chiave d'accesso");
DEFINE('_JW_STATS_MAP_INVALID_KEY',"Inserire una chiave d'accesso valida per favore. &Egrave; possibile ottenerle a: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");

DEFINE('_JW_SIZEQUERY_BAD_REQUEST',"BAD REQUEST: ");

DEFINE('_JW_VISIT_SUBMITED_FIELDS',"Dati del modulo spediti:");
DEFINE('_JW_VISIT_URL_PARAMETERS',"Parametri URL:");
DEFINE('_JW_VISIT_ADD_PAGE'," Aggiungere pagina come obiettivo");
DEFINE('_JW_VISIT_BLOCK_IP'," Bloccare questo indirizzo IP");
DEFINE('_JW_VISIT_SUBMITED_FROM_VARIABLE'," Aggiungere questa variabile del form come condizione da raggiungere");
DEFINE('_JW_VISIT_URL_PARAMETER_GOAL'," Aggiungere questo parametro URL come condizione da raggiungere");

DEFINE('_JW_TREND_EMPTY',"Vuoto");

DEFINE('_JW_NOT_NUMBER'," ATTENZIONE: Il valore inserito non &egrave; un numero. JoomlaWatch potrebbe non funzionare correttamente!");
DEFINE('_JW_EVALUATION_LEFT',"&nbsp; Questa &egrave; una versione di prova della durata di 15 giorni. Giorni restanti: <b>%d</b>. &Egrave; possibile acquistare la licenza <a href='http://www.codegravity.com/donate/joomlawatch/' target='_blank'>licenza di JoomlaWatch per il vostro domminio</a> che ha durata illimitata per questa versione e per i tutti gli aggiornamenti successivi.");
DEFINE('_JW_TRIAL_VERSION_EXPIRED'," La vostra versione di prova &egrave; scaduta. Per favore acquistate JoomlaWatch");

DEFINE('_JW_CONFIG_LICENSE_ACTIVATED',"La licenza &egrave; stata attivata. Grazie");
DEFINE('_JW_CONFIG_LICENCE_DONT_MATCH',"<b>Errore: la chiave per la licenza e il vostro dominio non combaciano.</b><br/>Nel form di attivazione avete inserito lo stesso dominio indicato in basso? In caso affermativo contattare: info@codegravity.com");

DEFINE('_JW_VIEW_ADMINBODY_LONG_MESSAGE',"Se visualizzate il messaggio riportato pi&ugrave; sopra per tanto tempo potrebbe essersi verifcato un errore nel vostro sito.
                    Aprire components/com_joomlawatch/config.php
                    decommentare ed impostare il vostro sito. Per es..:
                    define('JOOMLAWATCH_LIVE_SITE', 'http://www.codegravity.com');");

DEFINE('_JW_ADMINBODY_LIVE_SITE',"Attenzione: il sito del vostro browser e il sito nella configurazione: %s e %s non combaciano.");
DEFINE('_JW_ADMINBODY_SET_LIVE_SITE',"Impostare il sito a: %s e continuare...");

DEFINE('_JW_ADMINHEADER_JW',"JoomlaWatch ");
DEFINE('_JW_ADMINHEADER_REMOVE_BACKLINK',"Rimuovere il Backlink");
DEFINE('_JW_ADMINHEADER_KNOWLEDGE_BASE',"Knowledge Base");
DEFINE('_JW_ADMINHEADER_FLOW',"Flusso");
DEFINE('_JW_ADMINHEADER_GRAPHS',"Grafici");
DEFINE('_JW_ADMINHEADER_COMPONENTS',"Componenti");
DEFINE('_JW_ADMINHEADER_REVIEW',"Review");
DEFINE('_JW_ADMINHEADER_WRITE',"Scrivi ");

DEFINE('_JW_FLOW_TRAFFIC',"Flusso di traffico");
DEFINE('_JW_FLOW_SELECT_PAGE',"Pagina selezionata:");
DEFINE('_JW_FLOW_OUTG_LINKS',"Links in uscita dalla root:");
DEFINE('_JW_FLOW_NESTING',"Livello di nidificazione:");
DEFINE('_JW_FLOW_SCALE',"Scala:");

DEFINE('_JW_COMERCIAL_AD_FREE',"Versione Ad-free");
DEFINE('_JW_COMERCIAL_THANK_DONATION',"Grazie mille per la vostra donazione!");
DEFINE('_JW_COMERCIAL_REGISTRATION_KEY',"La chiave di registrazione per il vostro dominio %s &egrave;: ");
DEFINE('_JW_COMERCIAL_BACKLINKS_REMOVE',"Ora &egrave; possibile rimuovere il backlink o nascondere il logo JoomlaWatch nel frontend dalle Impostazioni ");


DEFINE('_JW_SIZES_LAST_CHECK',"Ultimo controllo effettuato:");
DEFINE('_JW_SIZES_ADMINISTRATOR',"BLUE = Dimensione di componente/modulo nella directory /administrator");

DEFINE('_JW_SIZECOMPONENTS_COMPONENT',"Componente");
DEFINE('_JW_SIZECOMPONENTS_TOTAL',"Totale:");
DEFINE('_JW_SIZECOMPONENTS_SIZE',"Dimensione");
DEFINE('_JW_SIZECOMPONENTS_REFRESH_ALL',"Aggiorna tutto");

DEFINE('_JW_SIZEDATABASE_TABLE',"Tabella");
DEFINE('_JW_SIZEDATABASE_SIZE',"Dimensione");
DEFINE('_JW_SIZEDATABASE_1DAY',"Modifica a 1 giorno");
DEFINE('_JW_SIZEDATABASE_7DAY',"Modifica a 7 giorni");
DEFINE('_JW_SIZEDATABASE_28DAY',"Modifica a 28 giorni");
DEFINE('_JW_SIZEDATABASE_NO_DATA',"nessun dato");
DEFINE('_JW_SIZEDATABASE_TOTAL',"Totale:");

DEFINE('_JW_SIZEMODULES_REFRESH_ALL',"Aggiorna tutto");
DEFINE('_JW_SIZEMODULES_TOTAL',"Totale:");
DEFINE('_JW_SIZEMODULES_MODULE',"Modulo");
DEFINE('_JW_SIZEMODULES_SIZE',"Dimensione");

DEFINE('_JW_SIZES_FILES',"Files &amp; Directories");
DEFINE('_JW_SIZES_BYTES',"bytes");
DEFINE('_JW_SIZES_KB',"KB");
DEFINE('_JW_SIZES_MB',"MB");
DEFINE('_JW_SIZES_GB',"GB");
DEFINE('_JW_SIZES_REFRESH',"Aggiorna");

DEFINE('_JW_STATS_FOOTER',"JoomlaWatch &copy;2006-@YEAR@ by Matej Koval");

DEFINE('_JW_STATUS_MB',"MB");

DEFINE('_JW_DESC_IPINFODB_KEY',"Chiave per la mappa degli ultimi visitatori ipinfodb.com fornita da: <a href='http://www.ipinfodb.com/register.php' target='_blank'>ipinfodb.com</a>");
DEFINE('_JW_SETTINGS_FORCE_TIMEZONE_OFFSET',"Forza la differenza di orario");


/* JoomlaWatch 1.2.17 translations */
DEFINE('_JW_MENU_UPDATE', "Aggiornamento");
DEFINE('_JW_MENU_UPDATE_TITLE', "Backup & Aggiornamento");
DEFINE('_JW_ADMINHEADER_NA_IN_THIS_VERSION',"Non disponibile nella versione free, verificare la licenza");
DEFINE('_JW_SPAMWORD_BANS_ENABLED', "Attiva il blocco di parole indesiderate");
DEFINE('_JW_SPAMWORD_LIST', "Lista parole indesiderate");
DEFINE('_JW_HIDE_REPETITIVE_TITLE', "Nascondi titolo se ripetuto");
DEFINE('_JW_TRUNCATE_VISITS', "Limita Visite");
DEFINE('_JW_TRUNCATE_STATS', "Limita Statistiche");
DEFINE('_JW_TRUNCATE_GOALS', "Limita Obiettivi");
DEFINE('_JW_LIMIT_BOTS', "Limita Bots");
DEFINE('_JW_LIMIT_VISITORS', "Limita Visitatori");
DEFINE('_JW_TOOLTIP_WIDTH', "Larghezza Popup suggerimenti");
DEFINE('_JW_TOOLTIP_HEIGHT', "Altezza Popup suggerimenti");
DEFINE('_JW_TOOLTIP_URL', "URL Popup suggerimenti");
DEFINE('_JW_TOOLTIP_ONCLICK', "Popup suggerimenti OnClick");
DEFINE('_JW_IP_STATS', "Statistiche IP");
DEFINE('_JW_IPINFODB_KEY', "Informazioni IP Chiave DB ");
DEFINE('_JW_ONLY_LAST_URI', "Solo ultime URI ");

DEFINE('_JW_FRONTEND_HIDE_LOGO', "Nascondi logo nel Front End ");
DEFINE('_JW_FRONTEND_NOFOLLOW', "Imposta No Follow nel Front End");
DEFINE('_JW_FRONTEND_NO_BACKLINK', "Nessun backlink nel Front End");
DEFINE('_JW_FRONTEND_USER_LINK', "Links Front User");
DEFINE('_JW_FRONTEND_COUNTRIES_FIRST', "Imposta prima i paesi nel Front End");
DEFINE('_JW_FRONTEND_COUNTRIES_NAMES', "Imposta i nomi dei paesi nel Front End");
DEFINE('_JW_FRONTEND_COUNTRIES_UPPERCASE', "Imposta i nomi dei paesi nel Front End in miauscolo");
DEFINE('_JW_FRONTEND_COUNTRIES_FLAGS_FIRST', "Imposta prima le bandiere dei paesi nel Front End ");
DEFINE('_JW_FRONTEND_COUNTRIES_NUM', "Numero peasi nel Front End");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_COLUMNS', "Numero max. colonne paesi nel Front End");
DEFINE('_JW_FRONTEND_COUNTRIES_MAX_ROWS', "Numero max. righe paesi nel Front End");
DEFINE('_JW_FRONTEND_VISITORS_TODAY', "Visitatori di oggi nel Front End ");
DEFINE('_JW_FRONTEND_VISITORS_YESTERDAY', "Visitatori di ieri nel Front End ");
DEFINE('_JW_FRONTEND_VISITORS_THIS_WEEK', "Visitatori questa settimana nel Front End ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_WEEK', "Visitatori la scorsa settimana nel Front End ");

DEFINE('_JW_FRONTEND_VISITORS_THIS_MONTH', "Visitatori questo mese nel Front End ");
DEFINE('_JW_FRONTEND_VISITORS_LAST_MONTH', "Visitatori il mese scorso nel Front End");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL', "Nascondere totale visitatori nel Front End");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL	', "Totale iniziale nel Front End");
DEFINE('_JW_HISTORY_MAX_VALUES', "Valore massimo cronologia");
DEFINE('_JW_HISTORY_MAX_DB_RECORDS', "Numero massimo dati nella cronologia");
DEFINE('_JW_UPDATE_TIME_VISITS', "Aggiorna orario visite");
DEFINE('_JW_UPDATE_TIME_STATS', "Aggiorna orario statistiche");
DEFINE('_JW_STATS_MAX_ROWS', "Numero max. righe statistiche");
DEFINE('_JW_STATS_IP_HITS', "Statistiche contatti per indirizzi IP");
DEFINE('_JW_MAXID_BOTS', "Max ID bots");
DEFINE('_JW_MAXID_VISITORS', "Maxid visitatori");
DEFINE('_JW_STATS_KEEP_DAYS', "Mantenere giorni statistiche ");
DEFINE('_JW_CACHE_FRONTEND_COUNTRIES', "Cache paesi nel Front End ");
DEFINE('_JW_CACHE_FRONTEND_VISITORS', "Cache visitatori nel Front End ");

DEFINE('_JW_UNINSTALL_KEEP_DATA	', "Disinstalla mantenedo i dati ");
DEFINE('_JW_IGNORE_IP', "Ignora IP");
DEFINE('_JW_IGNORE_URI', "Ignora URI");
DEFINE('_JW_IGNORE_USER', "Ignora Utente");
DEFINE('_JW_BLOCKING_MESSAGE', "Blocco Messaggi");
DEFINE('_JW_SERVER_URI_KEY', "Chiave del Server URI");
DEFINE('_JW_FRONTEND_VISITORS_TOTAL_INITIAL', "Visitatori totali iniziali nel Front End");
DEFINE('_JW_SIZEDATABASE_RECORDS', "Dati");
/***********EDITs******************/
DEFINE('_JW_ANTISPAM_BLOCKING_TEXT'," Per rendere il blocco effettivo &egrave; necessario pubblicare l'agente JoomlaWatch prima di qualsiasi contenuto o form. Per es. sul lato sinistro del template.
                    <br/>
                    Vai a Gestione Moduli -> JoomlaWatch agent -> selezionare posizione a sinistra");
DEFINE('_JW_EMAIL_SEO_REPORTS', "SEO Reports");
DEFINE('_JW_DESC_EMAIL_SEO_REPORTS_ENABLED',"Email notturna per SEO Reports attivata");
DEFINE('_JW_WATCH_INSTALLATION_DEMO',"Guarda la demo d'installazione");

?>