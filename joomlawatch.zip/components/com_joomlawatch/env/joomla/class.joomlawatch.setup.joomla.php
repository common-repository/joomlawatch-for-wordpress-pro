<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version 1.2.18 BETA
 * @revision 507
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) 2011 by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/

/** ensure this file is being included by a parent file */
if (!defined('_JEXEC') && !defined('_VALID_MOS'))
    die('Restricted access');

class JoomlaWatchSetupJoomla implements JoomlaWatchSetup {

    var $env;
    var $database;

    function JoomlaWatchSetupJoomla() {
        $this->env = JoomlaWatchEnvFactory::getEnvironment();
        $mainframe = & JFactory :: getApplication('site');
        $mainframe->initialise();
        $this->database = & JFactory :: getDBO();
    }

    function install()
    {
        if ("1.5" == "1.5" && !version_compare( JVERSION, '1.6.0', '<' )) {
            echo("<span style='color: red'><h2>Error: You are using joomla " . JVERSION. " but the installation package is for version 1.5 ! Uninstall this version, <a href='http://www.codegravity.com/download'>Go to download section</a>, download the package for Joomla ".JVERSION.", and install again.</h2></span>");
            return -1;
        } else if ("1.5" == "1.6" && !version_compare( JVERSION, '1.6.0', '>=' )) {
            echo("<span style='color: red'><h2>Error: You are using joomla " . JVERSION. " but the installation package is for version 1.5 ! Uninstall this version, <a href='http://www.codegravity.com/download'>Go to download section</a>, download the package for Joomla ".JVERSION.", and install again.</h2></span>");
            return -1;
        }

        $i = 0;
        $numberOfFiles = 64;
        for ($j = 1; $j <= $numberOfFiles; $j++) {
            $fileName = JPATH_SITE . DS . "components" . DS . "com_joomlawatch" . DS . "sql" . DS . "joomlawatch-$j.sql";
            $lines = file($fileName);
            if (!$lines) {
                die("<span style='color: red'>Error reading file: $fileName, your joomla site path is set to: ".JPATH_SITE." what is probably not correct, check configuration.php</span><br/>");
            }
            $query = "";
            foreach ($lines as $line_num => $line) {
                $query .= trim($line);
                if (strstr($line, ");")) {
                    if ($j % 10 == 0)
                        echo ((floor((($j) / $numberOfFiles) * 100)) . "%");
                    else
                        echo (".");
                    $this->database->setQuery(trim($query));
                    $result = $this->database->query();
                    if (!$result)
                        echo ("Error: " + $this->database->getQuery());
                    flush();
                    $query = "";
                    $i++;
                }
                //	@ unlink($fileName); //try to delete
            }
        }
        echo ("100%");
    }

    function uninstall()
    {
        die("install triggered");
    }

    function activate()
    {
        $query = "UPDATE #__components SET admin_menu_img='../components/com_joomlawatch/icons/joomlawatch-logo-16x16.gif' WHERE admin_menu_link='option=com_joomlawatch'";
        $this->database->setQuery(trim($query));
        $this->database->query();

        $query = "DELETE FROM #__joomlawatch_config where name like 'rand' ";
        $this->database->setQuery(trim($query));
        $this->database->query();
        $query = "DELETE FROM #__components where admin_menu_link like '%option=com_joomlawatch%'  and admin_menu_img like '%../components/com_joomlawatch/icons/%' and admin_menu_img<>'../components/com_joomlawatch/icons/joomlawatch-logo-16x16.gif'";
        $this->database->setQuery(trim($query));
        $this->database->query();

        $rand = rand();
        $query = "INSERT INTO #__joomlawatch_config (id, name, value) values ('', 'rand', '$rand') ";
        $this->database->setQuery(trim($query));
        $this->database->query();



        $query = sprintf("select id from #__components where `name` = '%s' limit 1", "JoomlaWatch");
        $this->database->setQuery(trim($query));
        $id = $this->database->loadResult();



        $query = sprintf("INSERT INTO #__components values ('', 'Live Stats', '', 0, %d, 'option=com_joomlawatch', '', '', 0, '../components/com_joomlawatch/icons/map_icon.gif', 0, '', 1)", (int) $id);
        $this->database->setQuery($query);
        $this->database->query();
        $query = sprintf("INSERT INTO #__components values ('', 'SEO', '', 0, %d, 'option=com_joomlawatch&task=seo', '', '', 0, '../components/com_joomlawatch/icons/seo.png', 0, '', 1)", (int) $id);
        $this->database->setQuery($query);
        $this->database->query();
        $query = sprintf("   INSERT INTO #__components values ('', 'Traffic Flow', '', 0, %d, 'option=com_joomlawatch&task=flow', '', '', 1, '../components/com_joomlawatch/icons/flow.png', 0, '', 1)", (int) $id);
        $this->database->setQuery($query);
        $this->database->query();
        $query = sprintf("   INSERT INTO #__components values ('', 'Graphs & Trends', '', 0, %d, 'option=com_joomlawatch&task=graphs', '', '', 2, '../components/com_joomlawatch/icons/trend_icon.gif', 0, '', 1)", (int) $id);
        $this->database->setQuery($query);
        $this->database->query();
        $query = sprintf("   INSERT INTO #__components values ('', 'Goals', '', 0, %d, 'option=com_joomlawatch&task=goals', '', '', 3, '../components/com_joomlawatch/icons/goal.gif', 0, '', 1)", (int) $id);
        $this->database->setQuery($query);
        $this->database->query();
        $query = sprintf("   INSERT INTO #__components values ('', 'Visit History', '', 0, %d, 'option=com_joomlawatch&task=history', '', '', 4, '../components/com_joomlawatch/icons/history.png', 0, '', 1)", (int) $id);
        $this->database->setQuery($query);
        $this->database->query();
        $query = sprintf("   INSERT INTO #__components values ('', 'Anti-spam & Blocking', '', 0, %d, 'option=com_joomlawatch&task=antiSpam', '', '', 5, '../components/com_joomlawatch/icons/antispam.gif', 0, '', 1)", (int) $id);
        $this->database->setQuery($query);
        $this->database->query();
        $query = sprintf("   INSERT INTO #__components values ('', 'Email Reports', '', 0, %d, 'option=com_joomlawatch&task=emails', '', '', 6, '../components/com_joomlawatch/icons/emails.png', 0, '', 1)", (int) $id);
        $this->database->setQuery($query);
        $this->database->query();
        $query = sprintf("   INSERT INTO #__components values ('', 'Your License', '', 0, %d, 'option=com_joomlawatch&task=license', '', '', 7, '../components/com_joomlawatch/icons/license.png', 0, '', 1)", (int) $id);
        $this->database->setQuery($query);
        $this->database->query();
        $query = sprintf("   INSERT INTO #__components values ('', 'Database Status', '', 0, %d, 'option=com_joomlawatch&task=status', '', '', 8, '../components/com_joomlawatch/icons/status.png', 0, '', 1)", (int) $id);
        $this->database->setQuery($query);
        $this->database->query();
        $query = sprintf("   INSERT INTO #__components values ('', 'Modules / Components Sizes', '', 0, %d, 'option=com_joomlawatch&task=sizes', '', '', 9, '../components/com_joomlawatch/icons/sizes.png', 0, '', 1)", (int) $id);
        $this->database->setQuery($query);
        $this->database->query();
        $query = sprintf("   INSERT INTO #__components values ('', 'Settings', '', 0, %d, 'option=com_joomlawatch&task=settings', '', '', 10, '../components/com_joomlawatch/icons/settings.gif', 0, '', 1)", (int) $id);
        $this->database->setQuery($query);
        $this->database->query();
        $query = sprintf("   INSERT INTO #__components values ('', 'Update', '', 0, %d, 'option=com_joomlawatch&task=update', '', '', 11, '../components/com_joomlawatch/icons/update.png', 0, '', 1)", (int) $id);
        $this->database->setQuery($query);
        $this->database->query();
        $query = sprintf("   INSERT INTO #__components values ('', 'Credits', '', 0, %d, 'option=com_joomlawatch&task=credits', '', '', 11, '../components/com_joomlawatch/icons/credits.png', 0, '', 1)", (int) $id);
        $this->database->setQuery($query);
        $this->database->query();
    }
}

?>