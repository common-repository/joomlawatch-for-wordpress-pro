<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version 1.2.18 BETA
 * @revision 507
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) 2011 by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/

/** ensure this file is being included by a parent file */
if (!defined('_JEXEC') && !defined('_VALID_MOS'))
    die('Restricted access');

class JoomlaWatchSetupWordpress implements JoomlaWatchSetup {

    function install()
    {
       $env = JoomlaWatchEnvFactory::getEnvironment();
       $database = $env->getDatabase();
       JoomlaWatchSetupWordpress::create_tables($database);
       JoomlaWatchSetupWordpress::install_geolocation($database);

    }

    function uninstall()
    {
        $env = JoomlaWatchEnvFactory::getEnvironment();
        $database = $env->getDatabase();
        JoomlaWatchSetupWordpress::drop_tables($database);
    }

    function activate()
    {
    }

    function create_tables($database) {
        $sqlFile = JPATH_BASE2 . DS . "administrator".DS."components" . DS . "com_joomlawatch" . DS . "sql" . DS . "install.mysql.utf8.sql";
        $sql = file_get_contents($sqlFile);
        $sql = $database->replaceDbPrefix($sql);
        $sqlSplitted = split(";",$sql);
        foreach ($sqlSplitted as $sql) {
            $sql .=";";
            $database->executeQuery($sql);
            echo($sql."<br/><br/>");
        }
    }

    function install_geolocation($database) {

        $i = 0;
        $numberOfFiles = 64;
        for ($j = 1; $j <= $numberOfFiles; $j++) {
            $fileName = JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "sql" . DS . "joomlawatch-$j.sql";
            $lines = file($fileName);
            if (!$lines) {
                die("<span style='color: red'>Error reading file: $fileName, your joomla site path is set to: ".JPATH_SITE." what is probably not correct, check configuration.php</span><br/>");
            }

            $query = "";
            foreach ($lines as $line_num => $line) {
                $query .= trim($line);
                if (strstr($line, ");")) {
//                    if ($j % 10 == 0)
                       // echo ((floor((($j) / $numberOfFiles) * 100)) . "%");
//                    else
//                        echo (".");

                    $result = $database->executeQuery(trim($query));
                    if (!$result)
                        echo ("Error: " + $database->getQuery());
                    flush();

                    $query = "";
                    $i++;
                }
                //	@ unlink($fileName); //try to delete
            }
        }
        echo ("100%");
    }

    function drop_tables($database) {
        $query = "DROP TABLE #__joomlawatch";
        $database->setQuery(trim($database->replaceDbPrefix($query)));

        $query = "DROP TABLE #__joomlawatch_info";
        $database->executeQuery(trim($database->replaceDbPrefix($query)));        $database->query();

        $query = "DROP TABLE #__joomlawatch_config";
        $database->executeQuery(trim($database->replaceDbPrefix($query)));

        $query = "DROP TABLE #__joomlawatch_blocked";
        $database->executeQuery(trim($database->replaceDbPrefix($query)));        $database->query();

        $query = "DROP TABLE #__joomlawatch_ip2c";
        $database->executeQuery(trim($database->replaceDbPrefix($query)));        $database->query();

        $query = "DROP TABLE #__joomlawatch_cc2c";
        $database->executeQuery(trim($database->replaceDbPrefix($query)));        $database->query();

        $query = "DROP TABLE #__joomlawatch_uri";
        $database->executeQuery(trim($database->replaceDbPrefix($query)));        $database->query();

        $query = "DROP TABLE #__joomlawatch_cache";
        $database->executeQuery(trim($database->replaceDbPrefix($query)));        $database->query();

        $query = "DROP TABLE #__joomlawatch_goals";
        $database->executeQuery(trim($database->replaceDbPrefix($query)));        $database->query();

        $query = "DROP TABLE #__joomlawatch_internal";
        $database->executeQuery(trim($database->replaceDbPrefix($query)));        $database->query();

        $query = "DROP TABLE #__joomlawatch_uri2title";
        $database->executeQuery(trim($database->replaceDbPrefix($query)));        $database->query();

        $query = "DROP TABLE #__joomlawatch_history";
        $database->executeQuery(trim($database->replaceDbPrefix($query)));        $database->query();

        $query = "DROP TABLE #__joomlawatch_uri_history";
        $database->executeQuery(trim($database->replaceDbPrefix($query)));        $database->query();

        $query = "DROP TABLE #__joomlawatch_flow";
        $database->executeQuery(trim($database->replaceDbPrefix($query)));        $database->query();

        $query = "DROP TABLE #__joomlawatch_uri_post";
        $database->executeQuery(trim($database->replaceDbPrefix($query)));        $database->query();

        $query = "DROP TABLE #__joomlawatch_keyphrase";
        $database->executeQuery(trim($database->replaceDbPrefix($query)));        $database->query();

        $query = "DROP TABLE #__joomlawatch_uri2keyphrase";
        $database->executeQuery(trim($database->replaceDbPrefix($query)));        $database->query();

        echo("JoomlaWatch tables deleted successfully");

        //delete file from upload
        @unlink(JPATH_BASE2 . DS . "..". DS."..".DS."uploads".DS."joomlawatch.zip");

    }
}

?>