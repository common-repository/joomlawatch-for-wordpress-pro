<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version 1.2.18 BETA
 * @revision 507
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) 2011 by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/

/** ensure this file is being included by a parent file */
if (!defined('_JEXEC') && !defined('_VALID_MOS'))
    die('Restricted access');

class JoomlaWatchWordpressEnv implements JoomlaWatchEnv {


    function getDatabase()
    {
        return new JoomlaWatchDBWrapWordpress();
    }

    function getRequest()
    {
        return new EnvRequest();
    }

    function & getURI()
    {
        global $post;
        return get_permalink( $post->ID );
    }

    function isSSL()
    {
        //TODO change
        return false;
    }

    function getRootSite()
    {
        return "http://".$_SERVER['HTTP_HOST']."/";
    }

    function getAdminDir()
    {
        return "administrator";
    }


    function getCurrentUser()
    {
        return $this->getUsername();
    }

    function getTimezoneOffset()
    {
        return 0;
    }

    function getEnvironmentSuffix()
    {
        // as install dir
        return "wordpress/wp-content/plugins/joomlawatch/";
    }

    function renderLink($task, $otherParams)
    {
        return $this->getRootSite()."wordpress/wp-admin/admin.php?page=joomlawatch&task=".$task."&".$otherParams;
    }

    function getUser()
    {
        global $current_user;
        return $current_user->user_login;
    }

    function getTitle()
    {
        return get_the_title();
    }

    function getUsername()
    {
        global $current_user;
        return $current_user->user_login;
    }

    function sendMail($recipient, $sender, $recipient, $subject, $body, $true, $cc, $bcc, $attachment, $replyto, $replytoname)
    {
        mail($recipient, $subject, $body, null, $sender);
    }

    function getDbPrefix()
    {
        global $wpdb;
        return $wpdb->base_prefix;
    }
}

?>