<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version 1.2.18 BETA
 * @revision 507
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) 2011 by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/

/** ensure this file is being included by a parent file */
if (!defined('_JEXEC') && !defined('_VALID_MOS'))
    die('Restricted access');

class JoomlaWatchNoCMSEnv implements JoomlaWatchEnv {


    function getDatabase()
    {
      return new JoomlaWatchDBWrapNoCMS();
    }

    function getRequest()
    {
        return new EnvRequest();
    }

    function & getURI()
    {
        return "fakeURL";
    }

    function isSSL()
    {
        //TODO change
        return false;
    }

    function getRootSite()
    {
      return "http://localhost:88/";
    }

    function getAdminDir()
    {
       return "jw";
    }


    function getCurrentUser()
    {
        return $this->getUsername();
    }

    function getTimezoneOffset()
    {
        return 0;
    }

    function getEnvironmentSuffix()
    {
        return "";
    }

    function renderLink($task, $otherParams)
    {
        return "?task=$task&action=$otherParams";
    }

    function getUser()
    {
       return "matto";
    }

    function getTitle()
    {
       return "title";
    }

    function getUsername()
    {
        return "matto";
    }

    function sendMail($recipient, $sender, $recipient, $subject, $body, $true, $cc, $bcc, $attachment, $replyto, $replytoname)
    {
        //TODO send mail
    }

    function getDbPrefix()
    {
        return "jos_";
    }
}
?>