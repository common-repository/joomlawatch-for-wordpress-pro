<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version 1.2.18 BETA
 * @revision 507
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) 2011 by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/

/** ensure this file is being included by a parent file */
if (!defined('_JEXEC') && !defined('_VALID_MOS'))
    die('Restricted access');

class JoomlaWatchVisitHistoryHTML extends JoomlaWatchVisitHTML {

    var $joomlaWatch;

    function JoomlaWatchVisitHistoryHTML($joomlaWatch) {
        parent::JoomlaWatchVisitHTML($joomlaWatch);
        $this->joomlaWatch = $joomlaWatch;
        $this->visitHistory = new JoomlaWatchVisitHistory($joomlaWatch);
    }

    /* visits */
    function renderVisitors() {
        //$rows = $this->visitHistory->getVisitors();
        $this->lastDate = "";
        $output = $this->renderTable(false);

        return $output;
    }

    function getJoinedURIRows($ip) {
        return $this->visitHistory->getJoinedURIRows($ip);
    }

    function renderPageLink($pageNum, $name, $actualpageNum, $disabled = false) {
        $output = "";
        if (!isset($pageNum) || $disabled == true || (isset($actualpageNum) && $actualpageNum == $pageNum)) {
            $output .= " ".$name." ";
        } else {
            $output .= "<a href='".$this->joomlaWatch->config->renderLink("history","pageNum=$pageNum")."'/>".$name."</a> ";
        }
        return $output;
    }

    function renderHistoryNavigation() {
        $pageNumFromRequest = (int) @JoomlaWatchHelper::requestGet('pageNum');
        $increment = $this->joomlaWatch->config->getConfigValue('JOOMLAWATCH_HISTORY_MAX_VALUES');
        $count = $this->visitHistory->getHistoryCount();
        $maxPageCount = floor($count / $increment);
        $maxPages = 20;
        
        if (!$pageNumFromRequest) {
            $pageNumFromRequest = 0;
        }
        $output = "";
        $output .= "<table width='100%'><tr><td>";

        if (isset($pageNumFromRequest) && $pageNumFromRequest > 0) {
            $pageNumPrev = $pageNumFromRequest -1;
        }
        $output .= $this->renderPageLink(@$pageNumPrev,"&lt;&lt;"._JW_HISTORY_PREVIOUS,@$pageNumFromRequest);

        $output .= $this->renderPageLink(0,0, $pageNumFromRequest)." ... ";


        $j = 0;
        for ($i=$pageNumFromRequest-floor($maxPages/2); $i<$maxPageCount; $i++) {
            if ($i>0 && $i<$maxPageCount) {
                $pageNum = $i;
                $output .= $this->renderPageLink($pageNum,$pageNum, $pageNumFromRequest);
                if ($j > $maxPages) {
                    break;
                }
                $j++;
            }
        }
        $output .= "... ".$this->renderPageLink($maxPageCount, $maxPageCount, $pageNumFromRequest);

        if (isset($pageNumFromRequest) && $pageNumFromRequest < $maxPageCount) {
            $pageNumNext = $pageNumFromRequest +1;
        }
        $output .= $this->renderPageLink(@$pageNumNext,_JW_HISTORY_NEXT."&gt;&gt;", $pageNumFromRequest);

        $output .= "</td></tr></table>";

        echo($output);
    }


}
