<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version 1.2.18 BETA
 * @revision 507
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) 2011 by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/

include_once("includes.php");

$joomlaWatch = new JoomlaWatch();
$joomlaWatch->block->checkPermissions();

require_once ("lang" . DS . $joomlaWatch->config->getLanguage().".php");

$uriId = JoomlaWatchHelper::requestGet('uriId');
$ip = JoomlaWatchHelper::requestGet('ip');

$joomlaWatchVisitsHTML = new JoomlaWatchVisitHTML($joomlaWatch);

$output = ("
        <a href='javascript:blockIpToggle(\"$ip\");'><img src='".$joomlaWatch->config->getLiveSite()."components/com_joomlawatch/icons/block.png' />"._JW_VISIT_BLOCK_IP."</a><br/>
        <a href='".$joomlaWatch->config->renderLink("goals","action=insert&id=".$uriId)."' 'Add page as goal'><img src='".$joomlaWatch->config->getLiveSite()."components/com_joomlawatch/icons/goal.gif' />"._JW_VISIT_ADD_PAGE."</a>");

$getData = $joomlaWatchVisitsHTML->renderGetVars($uriId);
$postData = $joomlaWatchVisitsHTML->renderPostVars($uriId);

$output .= "<table>";
if ($getData) {
    $output .= "<tr><td><br/><u>"._JW_VISIT_URL_PARAMETERS."</u></td>".$getData;
}
if ($postData) {
    $output .= "<tr><td><br/><u>"._JW_VISIT_SUBMITED_FIELDS."</u></td>".$postData;
}
$output .= "</table></div></div>";

echo($output);

?>