<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version 1.2.18 BETA
 * @revision 507
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) 2011 by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/
defined( '_JEXEC' ) or die( 'Restricted access' );

?>
<a href='<?php echo $this->joomlaWatch->config->renderLink();?>' ><img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/map_icon.gif'/>&nbsp;<?php echo _JW_MENU_STATS;?></a> |
<a href='<?php echo $this->joomlaWatch->config->renderLink('graphs');?>'><img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/trend_icon.gif'/>&nbsp;<?php echo _JW_ADMINHEADER_GRAPHS;?></a> |
<a href='<?php echo $this->joomlaWatch->config->renderLink('goals');?>'><img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/goal.gif'/>&nbsp;<?php echo _JW_MENU_GOALS;?></a> |
<a href='<?php echo $this->joomlaWatch->config->renderLink('history');?>'><img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/history.png'/>&nbsp;<?php echo _JW_MENU_HISTORY;?></a> |
<a href='<?php echo $this->joomlaWatch->config->renderLink('antiSpam');?>'><img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/antispam.gif'/>&nbsp;<?php echo _JW_SETTINGS_ANTI_SPAM;?></a> |
<a href='<?php echo $this->joomlaWatch->config->renderLink('emails');?>'><img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/emails.png'/>&nbsp;<?php echo _JW_MENU_EMAILS;?></a> |
<a href='<?php echo $this->joomlaWatch->config->renderLink('license');?>'><img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/license.png'/>&nbsp;<?php echo _JW_MENU_LICENSE;?></a> |
<a href='<?php echo $this->joomlaWatch->config->renderLink('settings');?>'><img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/settings.gif'/>&nbsp;<?php echo _JW_MENU_SETTINGS;?></a> |
<a href='<?php echo $this->joomlaWatch->config->renderLink('credits');?>'><img src='<?php echo($this->joomlaWatch->config->getLiveSiteWithSuffix());?>components/com_joomlawatch/icons/credits.png'/>&nbsp;<?php echo _JW_MENU_CREDITS;?></a> |


 
