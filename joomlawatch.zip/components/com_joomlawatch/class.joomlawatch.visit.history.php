<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version 1.2.18 BETA
 * @revision 507
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) 2011 by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/

/** ensure this file is being included by a parent file */
if (!defined('_JEXEC') && !defined('_VALID_MOS'))
    die('Restricted access');

class JoomlaWatchVisitHistory extends JoomlaWatchVisit {

    var $database;
    var $config;
    var $helper;
    var $stat;
    var $block;
    var $goal;
    var $visitHistory;
    var $lastDate;

    function JoomlaWatchVisitHistory($joomlaWatch) {
        parent::JoomlaWatchVisit($joomlaWatch);
    }

    /**
     * visitor
     */
    function getVisitors() {
        $limit = $this->config->getConfigValue('JOOMLAWATCH_LIMIT_VISITORS');
        $query = sprintf("select ip, referer, username from #__joomlawatch where (browser is not NULL and browser != '') order by id desc limit %d", (int) $limit);
        $rows = $this->database->objectListQuery($query);
        return $rows;
    }

    /**
     * visitor
     */
    function getJoinedURIRows($bots) {
        if ($bots) {
            $browserCondition = "is NULL";
            $limit = $this->config->getConfigValue("JOOMLAWATCH_LIMIT_BOTS");
        } else {
            $browserCondition = "is not NULL";
            $limit = $this->config->getConfigValue("JOOMLAWATCH_LIMIT_VISITORS");
        }
        $count = $this->config->getConfigValue('JOOMLAWATCH_HISTORY_MAX_VALUES');
        $actualPage = (int) JoomlaWatchHelper::requestGet('pageNum');
        $actualRecord = $actualPage * $count;
        $limit = $actualRecord.",".$count;
        $query = sprintf("SELECT * FROM #__joomlawatch_history LEFT JOIN #__joomlawatch_uri_history ON #__joomlawatch_history.id = #__joomlawatch_uri_history.fk WHERE #__joomlawatch_history.browser %s order by #__joomlawatch_history.id desc, #__joomlawatch_uri_history.timestamp desc limit %s", $this->database->getEscaped($browserCondition), $this->database->getEscaped($limit));
        $rows = $this->database->objectListQuery($query);
        return $rows;
    }

    function getHistoryCount() {
        $query = sprintf("SELECT count(id) FROM #__joomlawatch_history");
        $rows = $this->database->resultQuery($query);
        return $rows;
    }

     /**
     * visitor
     */
    function getJoinedURIRowById($id) {
        $query = sprintf("SELECT * FROM #__joomlawatch_history LEFT JOIN #__joomlawatch_uri_history ON #__joomlawatch_history.id = #__joomlawatch_uri_history.fk where #__joomlawatch_uri_history.id = '%d' ORDER BY #__joomlawatch_uri_history.timestamp desc", (int) $id);
        $rows = $this->database->objectListQuery($query);
        return $rows;
    }


}

?>