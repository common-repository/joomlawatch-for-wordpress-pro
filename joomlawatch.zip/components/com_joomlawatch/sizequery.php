<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version 1.2.18 BETA
 * @revision 507
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) 2011 by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/

include_once("includes.php");

$joomlaWatch = new JoomlaWatch();
$joomlaWatch->block->checkPermissions();

require_once ("lang" . DS . $joomlaWatch->config->getLanguage().".php");

$dir = JoomlaWatchHelper::requestPost('dir');
$group = JoomlaWatchHelper::requestPost('mod');

if (!$joomlaWatch->sizes->isAllowed($dir)) {
    die(_JW_SIZEQUERY_BAD_REQUEST);
}
if (is_dir($dir))
{
    $sizeNow = $joomlaWatch->sizes->getDirectorySize($dir, $group, true, $joomlaWatch->helper->jwDateToday());
    $sizePrev = $joomlaWatch->sizes->getDirectorySize($dir, $group, false, $joomlaWatch->sizes->findLatestCheckDayByComOrModGroup());

    if ($sizePrev == $sizeNow)
        $size = "<span style='color: gray;'>".$joomlaWatch->sizes->sizeFormat($sizeNow)."</span>";
    elseif ($sizeNow <= $sizePrev)
        $size = "<span style='color: green;'>".$joomlaWatch->sizes->sizeFormat($sizeNow)." (-".round(($sizePrev - $sizeNow) / $sizeNow * 100)."%)</span>";
    else
        $size = "<span style='color: red;'>".$joomlaWatch->sizes->sizeFormat($sizeNow)." (+".round(($sizeNow - $sizePrev) / $sizeNow * 100)."%)</span>";

    echo $size;
} else {
    die(_JW_SIZEQUERY_BAD_REQUEST);
}

?>