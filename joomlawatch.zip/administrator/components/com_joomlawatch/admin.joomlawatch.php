<?php

/**
 * JoomlaWatch - A real-time ajax joomla monitor and live stats
 * @package JoomlaWatch
 * @version 1.2.18 BETA
 * @revision 507
 * @license http://www.gnu.org/licenses/gpl-3.0.txt 	GNU General Public License v3
 * @copyright (C) 2011 by Matej Koval - All rights reserved!
 * @website http://www.codegravity.com
 **/

/** ensure this file is being included by a parent file */
if( !defined( '_JEXEC' ) && !defined( '_VALID_MOS' ) ) die( 'Restricted access' );

if (!defined('_JEXEC')) define('_JEXEC', 1);
if (!defined('DS')) define('DS', DIRECTORY_SEPARATOR);

//Fix by el_oskaros
$jPathBase2 = str_replace(DIRECTORY_SEPARATOR.'administrator'.DIRECTORY_SEPARATOR.'index.php','',$_SERVER['SCRIPT_FILENAME']);
$jPathBase2 = str_replace(DIRECTORY_SEPARATOR.'administrator'.DIRECTORY_SEPARATOR.'index2.php','',$jPathBase2);

/* replace all possible combinations */
$jPathBase2 = str_ireplace('/administrator/index.php','',$jPathBase2);
$jPathBase2 = str_ireplace('\administrator\index.php','',$jPathBase2);
$jPathBase2 = str_ireplace('/administrator/index2.php','',$jPathBase2);
$jPathBase2 = str_ireplace('\administrator\index2.php','',$jPathBase2);


if (!defined('JPATH_BASE2'))
    define('JPATH_BASE2',$jPathBase2);

/*    if (defined('JPATH_BASE') && !defined('JPATH_BASE2')) {
        define('JPATH_BASE2', JPATH_BASE);
    }*/

if (!defined('ENV')) {

    if (!defined('JPATH_ROOT'))
        require_once (JPATH_BASE2 . DS . 'includes' . DS . 'defines.php');

    if (!defined('JDEBUG'))
        @ require_once (JPATH_BASE2 . DS . 'includes' . DS . 'framework.php');

    $mainframe = & JFactory :: getApplication('site');
    $mainframe->initialise();
}

require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "config.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "inc.joomlawatch.env.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "class.ip2country.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "class.joomlawatch.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "class.joomlawatch.block.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "class.joomlawatch.block.html.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "class.joomlawatch.cache.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "class.joomlawatch.config.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "class.joomlawatch.goal.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "class.joomlawatch.goal.html.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "class.joomlawatch.helper.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "class.joomlawatch.stat.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "class.joomlawatch.stat.html.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "class.joomlawatch.visit.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "class.joomlawatch.visit.html.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "class.joomlawatch.visit.history.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "class.joomlawatch.visit.history.html.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "class.joomlawatch.trend.html.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "class.joomlawatch.db.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "class.joomlawatch.html.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "class.joomlawatch.log.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "admin.joomlawatch.html.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "class.joomlawatch.sizes.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "class.joomlawatch.flow.php");
require_once (JPATH_BASE2 . DS . "components" . DS . "com_joomlawatch" . DS . "class.joomlawatch.flow.html.php");

$joomlaWatch = new JoomlaWatch();
$joomlaWatchHTML = new JoomlaWatchHTML();
$joomlaWatchGoalHTML = new JoomlaWatchGoalHTML($joomlaWatch);
$joomlaWatchTrendHTML = new JoomlaWatchTrendHTML($joomlaWatch);
$env = JoomlaWatchEnvFactory::getEnvironment();

$action = @ JoomlaWatchHelper::requestGet('action');
$task = @ JoomlaWatchHelper::requestGet('task');
$option = @ JoomlaWatchHelper::requestGet('option');

switch ($task) {

    /*
     * disabled trial
     *
     *     case "useTrial" :
            {
                $joomlaWatchHTML->renderAdminStyles();
                $joomlaWatch->config->useTrial();
                $joomlaWatch->config->saveVersionIntoDatabase();
                $joomlaWatch->config->setLiveSite($env->getRootSite());
                break;
            }
    */
    case "useFreeVersion" :
        {
        $joomlaWatchHTML->renderAdminStyles();
        $joomlaWatch->config->useFreeVersion();
        $joomlaWatch->config->saveVersionIntoDatabase();
        $joomlaWatch->config->setLiveSite($env->getRootSite());
        break;
        }


    case "activate" :
        {
        $joomlaWatchHTML->renderAdminStyles();
        $joomlaWatch->config->activate(JoomlaWatchHelper::requestGet('key'));
        $joomlaWatch->config->saveVersionIntoDatabase();
        $joomlaWatch->config->setLiveSite($env->getRootSite());
        break;
        }

    case "licenseAccepted" :
        {
        $joomlaWatch->config->setLiveSite($env->getRootSite());
        $joomlaWatch->config->setLicenseAccepted();
        $joomlaWatch->config->saveVersionIntoDatabase();
        break;
        }

    case "resetLiveSite" :
        {
        $joomlaWatch->block->checkPermissions();
        $joomlaWatch->config->setLiveSite($env->getRootSite());
        break;
        }
}
if (!$joomlaWatch->config->checkLicenseAccepted()) {
    $joomlaWatchHTML->renderAdminStyles();
    echo $joomlaWatchHTML->renderAcceptLicense();
} else
    if (!$joomlaWatch->config->isFree() && !$joomlaWatch->config->isAdFree()  /* disabled trial || ($joomlaWatch->config->isTrial() && !$joomlaWatch->config->isTrialTimeOver())*/) {
        $joomlaWatchHTML->renderAdminStyles();
        echo $joomlaWatchHTML->renderAdFreeLicense();
    } else {
        switch ($task) {

            case "storeIpInfoDbKey": {
            $joomlaWatchHTML->renderAdminStyles();
            $joomlaWatchHTML->renderHeader();
            $keyValue = $_POST['storeIpInfoDbKey'];
            if ($keyValue) {
                $joomlaWatch->config->saveConfigValue("JOOMLAWATCH_IPINFODB_KEY", $keyValue);
            } else {
                echo("<br/><div style='border: 1px solid red; width: 50%; padding: 10px;'>"._JW_STATS_MAP_INVALID_KEY."</div>");
            }
            $joomlaWatchHTML->renderBody($option);
            break;
            }

            case "update" :
                {
                $joomlaWatchHTML->renderAdminStyles();
                $joomlaWatchHTML->renderHeader();
                echo $joomlaWatchHTML->renderUpdate();
                break;
                }

            case "sizes" :
                {
                if (!$joomlaWatch->config->isFree()) {
                    $joomlaWatchHTML->renderAdminStyles();
                    $joomlaWatchHTML->renderHeader();
                    echo $joomlaWatchHTML->renderSizes();
                }

                break;
                }

            case "seo" :
                {
                $joomlaWatchHTML->renderAdminStyles();
                $joomlaWatchHTML->renderHeader();
                $joomlaWatchHTML->renderSEO();
                break;
                }

            case "graphs" :
                {
                $joomlaWatchHTML->renderAdminStyles();
                $joomlaWatchHTML->renderHeader();
                echo $joomlaWatchTrendHTML->renderGraphsForGroup(JoomlaWatchHelper::requestGet('group'));

                break;
                }

            case "trends" :
                {
                $joomlaWatchHTML->renderAdminStyles();
                $joomlaWatchHTML->renderHeader();
                echo $joomlaWatchTrendHTML->renderTrends();

                break;
                }

            case "credits" :
                {
                $joomlaWatchHTML->renderAdminStyles();
                $joomlaWatchHTML->renderHeader();
                echo $joomlaWatchHTML->renderCredits();

                break;
                }
            case "goals" :
                {
                switch($action) {

                    case "insert":
                        {
                        $joomlaWatchHTML->renderAdminStyles();
                        $joomlaWatchHTML->renderHeader();
                        echo $joomlaWatchGoalHTML->renderBackToGoals();
                        $joomlaWatchGoalHTML->renderGoalsInsert(@ JoomlaWatchHelper::requestGet('id'), @ JoomlaWatchHelper::requestGet('postid'));

                        break;
                        }
                    case "save":
                        {
                        $joomlaWatchHTML->renderAdminStyles();
                        $joomlaWatchHTML->renderHeader();
                        $joomlaWatch->goal->saveGoal($_POST);
                        $joomlaWatchGoalHTML->renderGoals(@ $result);

                        break;
                        }
                    case "edit":
                        {
                        $joomlaWatchHTML->renderAdminStyles();
                        $joomlaWatchHTML->renderHeader();
                        echo $joomlaWatchGoalHTML->renderBackToGoals();
                        $joomlaWatchGoalHTML->renderGoalEdit(@ JoomlaWatchHelper::requestGet('goalId'));

                        break;
                        }
                    case "delete":
                        {
                        $joomlaWatchHTML->renderAdminStyles();
                        $joomlaWatchHTML->renderHeader();
                        $result = $joomlaWatch->goal->deleteGoal(@ JoomlaWatchHelper::requestGet('goalId'));
                        $joomlaWatchGoalHTML->renderGoals(@ $result);

                        break;
                        }
                    case "enable":
                        {
                        $joomlaWatchHTML->renderAdminStyles();
                        $joomlaWatchHTML->renderHeader();
                        $result = $joomlaWatch->goal->enableGoal(@ JoomlaWatchHelper::requestGet('goalId'));
                        $joomlaWatchGoalHTML->renderGoals(@ $result);

                        break;
                        }
                    case "disable":
                        {
                        $joomlaWatchHTML->renderAdminStyles();
                        $joomlaWatchHTML->renderHeader();
                        $result = $joomlaWatch->goal->disableGoal(@ JoomlaWatchHelper::requestGet('goalId'));
                        $joomlaWatchGoalHTML->renderGoals(@ $result);

                        break;
                        }
                    default:
                        {
                        $joomlaWatchHTML->renderAdminStyles();
                        $joomlaWatchHTML->renderHeader();
                        $joomlaWatchGoalHTML->renderGoals(@ $result);

                        break;
                        }

                }

                break;
                }
            case "settings" :
                {
                $joomlaWatchHTML->renderAdminStyles();
                $joomlaWatchHTML->renderHeader();
                $joomlaWatchHTML->renderSettings(@ $result);

                break;
                }
            case "settingsSave" :
                {
                $result = $joomlaWatch->helper->saveSettings($_POST);
                $joomlaWatchHTML->renderAdminStyles();
                $joomlaWatchHTML->renderHeader();
                $joomlaWatchHTML->renderSettings(@ $result);

                break;
                }
            case "resetData" :
                {
                $joomlaWatchHTML->renderAdminStyles();
                $joomlaWatchHTML->renderHeader();
                $result = $joomlaWatch->helper->resetData($_POST);
                $joomlaWatchHTML->renderResetData($result);
                break;
                }

            case "antiSpam" :
                {

                switch($action) {

                    case "toggleBlocking": {
                    $joomlaWatchHTML->renderAdminStyles();
                    $joomlaWatchHTML->renderHeader();
                    $ip = @ JoomlaWatchHelper::requestGet('ip');
                    $joomlaWatch->block->blockIpToggle($ip);
                    $joomlaWatchHTML->renderAntiSpam();
                    break;

                    }

                    case "save" :
                        {
                        $result = $joomlaWatch->helper->saveAntiSpamSettings($_POST);
                        $joomlaWatchHTML->renderAdminStyles();
                        $joomlaWatchHTML->renderHeader();
                        $joomlaWatchHTML->renderAntiSpam();
                        break;
                        }


                    default:  {
                    $joomlaWatchHTML->renderAdminStyles();
                    $joomlaWatchHTML->renderHeader();
                    $joomlaWatchHTML->renderAntiSpam();
                    break;
                    }
                }

                break;
                }



            case "status" :
                {
                if (!$joomlaWatch->config->isFree()) {
                    $joomlaWatchHTML->renderAdminStyles();
                    $joomlaWatchHTML->renderHeader();
                    $joomlaWatchHTML->renderStatus();
                }
                break;
                }

            /*			case "upgrade" :
            {
                $joomlaWatchHTML->renderAdminStyles();
                $joomlaWatchHTML->renderHeader();
                $joomlaWatchHTML->renderUpgrade();
                break;
            }*/


            case "license" :
                {
                $joomlaWatchHTML->renderAdminStyles();
                $joomlaWatchHTML->renderHeader();
                $joomlaWatchHTML->renderAdFreeLicense();
                break;
                }


            case "history" :
                {
                $joomlaWatchHTML->renderAdminStyles();
                $joomlaWatchHTML->renderHeader();
                $joomlaWatchHTML->renderVisitsHistory();
                break;
                }

            case "flow" :
                {
                if (!$joomlaWatch->config->isFree()) {
                    $joomlaWatchHTML->renderAdminStyles();
                    $joomlaWatchHTML->renderHeader();
                    $joomlaWatchHTML->renderFlow();
                }
                break;
                }

            case "emails" :
                {

                switch($action) {

                    case "save": {
                    $joomlaWatchHTML->renderAdminStyles();
                    $joomlaWatchHTML->renderHeader();
                    $result = $joomlaWatch->helper->saveEmailSettings($_POST);
                    $joomlaWatchHTML->renderEmails();
                    break;

                    }
                    default: {
                    $joomlaWatchHTML->renderAdminStyles();
                    $joomlaWatchHTML->renderHeader();
                    $joomlaWatchHTML->renderEmails();
                    break;
                    }
                }
                break;
                }


            default :
                if ($joomlaWatch->config->checkLicenseAccepted()) {
                    $joomlaWatchHTML->renderAdminStyles();
                    $joomlaWatchHTML->renderHeader();
                    $joomlaWatchHTML->renderBody($option);
                } else {
                    $joomlaWatchHTML->renderAdminStyles();
                    echo $joomlaWatchHTML->renderAcceptLicense();
                }
                break;
        }
        /*
            } else {
                $joomlaWatchHTML->renderAdminStyles();
                $joomlaWatchHTML->renderHeader();
                $joomlaWatchHTML->renderTrialVersionInfo();
            }
        */
    }
?>